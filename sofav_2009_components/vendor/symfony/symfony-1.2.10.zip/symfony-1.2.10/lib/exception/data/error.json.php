<?php echo json_encode(array(
  'error'       => array(
    'code'      => $code,
    'message'   => $message,
))) ?>
