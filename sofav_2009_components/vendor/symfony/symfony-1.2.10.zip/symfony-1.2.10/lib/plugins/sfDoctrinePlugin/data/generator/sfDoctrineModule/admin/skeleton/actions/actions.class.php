<?php

require_once dirname(__FILE__).'/../lib/##MODULE_NAME##GeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/##MODULE_NAME##GeneratorHelper.class.php';

/**
 * ##MODULE_NAME## actions.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage ##MODULE_NAME##
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class ##MODULE_NAME##Actions extends auto##UC_MODULE_NAME##Actions
{
}
