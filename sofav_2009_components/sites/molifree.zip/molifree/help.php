<?php
require_once 'inc/functions.php';
include 'header_min.php';
?>
<link rel="stylesheet" type="text/css" media="screen" href="css/about.css"/>
<script type="text/javascript">
document.title = "<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> / 用户帮助";
</script>
<div class="columns">
<div class="inner_columns">
<div class="left">
	<div id="content">
		<div id="about_help_title" class="title">
			<h2>用户帮助</h2>
		</div>
		<div id="about_help_content" class="content">
			<ol id=faq>
				<li>
					<h3><?php echo $_SESSION['session_Setting_SITE_NAME']; ?>是什么？</h3>
	
					<p><?php echo $_SESSION['session_Setting_SITE_NAME']; ?>可以为您方便地提供您周边外卖菜单，并且可以直接通过网络来订餐(beta)。在简单的定制之后，您每次只需要访问首页即可看到自己定制的餐厅信息。<br/>更多信息请点击<a href="about_us.php">关于我们</a></p>
				</li>
				<li>
					<h3>如何定制属于自己的餐厅首页？</h3>
					<p>您只需要访问<a href="map.php" target="_blank">地图页</a>，输入您的地理位置，我们为您搜集的该区域附近提供外卖菜单的餐厅便会列在右边。您可以根据个人的喜好来添加到首页。</p>
	
				</li>
				<li>
					<h3>搜索不到我的地理位置怎么办？</h3>
					<p>地图搜索由Google提供，为了确保得到更准确的结果，建议输入完整区县。与此同时也建议您搜索详细区域（比如“望京”，“亚运村”等）。</p>
				</li>
				<li>
					<h3>不登录可以使用吗？</h3>
	
					<p>当然可以，但您的定制菜单只在cookie不被清除的情况下在本机使用。我们建议您用30秒的时间<a href="signup.php">免费注册</a>来享受更多服务。</p>
				</li>
				<li>
					<h3>信息有出入怎么办？</h3>
					<p>如果信息不准确，或者缺乏时效性，或者别的问题。请您在百忙之中抽出一点点时间来<a href="about_feedback.php">这里</a>提交您的反馈，便于我们为您提供更准确到位的服务，谢谢！</p>
	
				</li>
				<li>
					<h3>我为什么不能订餐？</h3>
					<p>原因可能有两个：<br/>1、您尚未<a href="login.php">登录</a><br/>2、您在服务时间之外订餐（服务时间为10:00-23:00）<br/></p>
				</li>
			</ol>
		</div>
	</div>
</div>
<div class="right">
	<div id="side">
		<div id="about_help_side" class="side_content">
			<p>在这里列出了您在使用<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>时的一些常见问题。<br/>也欢迎您在<a style="text-decoration:underline" href="about_feedback.php"><b>这里</b></a>和客服人员交流，并且提出宝贵意见。<br/></p>
		</div>
	</div>
</div>
</div>
</div>
<?php include 'footer.php' ?>
