<?php include 'header_min.php' ?>
<script type="text/javascript">
document.title = "<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> / 注册";
</script>
<div class="columns">
<div class="inner_columns">
<div class="left">
	<div id="content">
		<div id="signup">
			<h1 id="page_title">注册<span>或者<a href="login.php">登录</a></span></h1>
			<form action="account_create.php" method="post" class="account_form">
				<table>
				<!--
					<tr id="email-field">
						<th><label for="email">Email</label></th>
						<td>
							<input type="text" name="email" id="email" class="text" value="<?php echo $_POST['email'];?>"/>
							<div class="hint">登录及找回密码用，不会公开</div>
						</td>
					</tr>
				-->
					<tr id="username-field">
						<th><label for="username">用户名</label></th>
						<td>
							<input type="text" name="username" id="username" class="text" value="<?php echo $_POST['username'];?>" />
							<div class="hint">2-16 个字母，数字，汉字或下划线</div>
						</td>
					</tr>
					<tr id="password-field">
						<th><label for="password">密码</label></th>
						<td>
							<input type="password" name="password" id="password" class="text" value="<?php echo $_POST['password'];?>" />
							<br/>
							<span class="hint">最少 4 个字符</span>
						</td>
					</tr>
					<tr id="signin-field">
						<th></th>
						<td><input type="submit" id="signin" class="btn" value="注册" /></td>
					</tr>
				</table>
			</form>
		</div>
	</div>
</div>
<div class="right">
	<div id="side">
		<h2>注册有哪些好处？</h2>
		<p>无论是否注册，你都可以把常吃的餐厅定制到首页，但是注册以后你辛辛苦苦的定制就不会随cookie一起容易丢失。</p>
	</div>
</div>
</div>
</div>
<?php include 'footer.php' ?>