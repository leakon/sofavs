<?php
require_once 'inc/functions.php';
$pass = verify_mobile();
switch ( $_REQUEST['from'] ) {
	case "orders":
		if($pass)
			header('Location: orders_myactive.php');
		else
			header('Location: orders_verifymobile.php');
		break;

	case "setting":
		header('Location: custom_mobile.php');
		break;
		
	case "login": //TODO
		header('Location: login_mobile.php');
		break;
			
	default:
		header('Location: custom_mobile.php');
		break;
}
?>
