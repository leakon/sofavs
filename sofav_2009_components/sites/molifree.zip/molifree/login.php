<?php include 'header_min.php' ?>
<script type="text/javascript">
document.title = "<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> / 登录";
</script>
<div class="columns">
<div class="inner_columns">
<div class="left">
	<div id="content">
		<div>
			<h1 id="page_title">登录<span>或者<a href="signup.php">注册</a></span></h1>
			<form action="authenticate.php" method="post" class="account_form">
				<table>
					<tr id="username-field">
						<th><label for="username">用户名</label></th>
						<td>
							<input tabindex="1" type="text" name="username" id="username" class="text" value="<?php echo $_POST['username'];?>" />
							<div class="hint">&nbsp;</div>
						</td>
					</tr>
					<tr id="password-field">
						<th><label for="password">密码</label></th>
						<td>
							<input tabindex="2" type="password" name="password" id="password" class="text" value="<?php echo $_POST['password'];?>" />
							<div class="hint">
								<a href="forgotpassword.php" id="forgot_password">忘记密码？</a>
								/<a href="mobilelogin.php" id="send_temp_password">短信给我一个临时密码</div>
						</td>
					</tr>
					<tr id="signin-field">
						<th></th>
						<td>
						<input tabindex="3" type="submit" id="signin" class="btn" value="登录" />
						</td>
					</tr>
				</table>
				<input type="hidden" name="remember" id="remember" value="true" />
			</form>
		</div>
	</div>
</div>
<div class="right">
	<div id="side">
		<h2>还没有<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>帐号？</h2>
		<p>&raquo; <a href="signup.php">立即注册，仅需30秒</a></p>
	</div>
</div>
</div>
</div>
<?php include 'footer.php' ?>