<?php
include_once 'inc/config.php';
include_once 'inc/functions.php';
// 得到请求参数
$v =getRestarauntById($_POST['resId']);

if (empty ( $v )) { // 如果是空的话
	echo '{"success":"false"}';
	return;
}
$json = '{"success":"true","list":[';
	/*循环封装 热门餐品**/
	$hotDishes = getTop3DishesByRestaurentId ($v['ID']);
	$theHotDish="";
	$j=0;
	foreach ( $hotDishes as $key => $value ) {
		if($j==0){
			$theHotDish.="{'dishName':'".$value['Name']."'}";
		}else{
			$theHotDish.=",{'dishName':'".$value['Name']."'}";
		}
		$j++;
	}
	
	//封装餐馆信息
//	if ($i == 0) {
		$json .= "{'id':$v[ID],'UUID':'$v[UUID]','businessHour':'$v[BusinessHour]','rating':'$v[Rating]','memo':'$v[BusinessMemo]','name':'$v[Name]','scope':'$v[Scope]','lat':'$v[Latitude]','lng':'$v[Longitude]','hotDishes':[$theHotDish]}";
//	} else {
//		$json .= ",{'id':$v[ID],'UUID':'$v[UUID]','businessHour':'$v[BusinessHour]','rating':'$v[Rating]','memo':'$v[BusinessMemo]','name':'$v[Name]','scope':'$v[Scope]','lat':'$v[Latitude]','lng':'$v[Longitude]','hotDishes':[$theHotDish]}";
//	}
$json .= ']}';
echo $json;
?>