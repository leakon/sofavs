<?php
require_once("inc/functions.php");
if(empty($_SESSION['admin_is_login'])){
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>后台登陆</title>
</head>
<body>
<div id="loading-mask" style="">
	<div id="loading">
		<div style="text-align: center; padding-top: 26%">
			<img src="extjs/resources/themes/images/default/shared/blue-loading.gif"
				width="32" height="32" style="margin-right: 8px;" align="middle" />
			加载中...
		</div>
	</div>
</div>
</body>

<link href="extjs/resources/css/ext-all.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="css/login.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="css/app.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="extjs/ux/css/CheckHeader.css"  rel="stylesheet" type="text/css"/>

<script src="extjs/bootstrap.js" type="text/javascript" charset="utf-8"></script>
<script src="extjs/locale/ext-lang-zh_CN.js" type="text/javascript" charset="utf-8"></script>


<script type="text/javascript" src="http://ditu.google.cn/maps/api/js?libraries=places&sensor=false&language=zh&region=CN"></script>

<script src="js/Login.js" type="text/javascript" charset="utf-8"></script>
<script src="js/md5.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AnimationEffectMsg.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MakeMap.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MainWin.js" type="text/javascript" charset="utf-8"></script>
<script src="js/ChangePasswordWindow.js" type="text/javascript" charset="utf-8"></script>
<script src="js/model.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MenuPanel.js" type="text/javascript" charset="utf-8"></script>
<script src="js/CurrentOrderList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/CustomList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/RestaurantList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AddRestaurant.js" type="text/javascript" charset="utf-8"></script>
<script src="js/EditRestaurant.js" type="text/javascript" charset="utf-8"></script>
<script src="js/HomePageSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/HelpPageSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/ContactPageSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AboutPageSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/RightSideSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/SmsServerSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/SmsList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/SmsGroupSend.js" type="text/javascript" charset="utf-8"></script>
<script src="js/SmsSingleSend.js" type="text/javascript" charset="utf-8"></script>
<script src="js/QAList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/CityList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AddCity.js" type="text/javascript" charset="utf-8"></script>
<script src="js/EditCity.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AddRegionWindow.js" type="text/javascript" charset="utf-8"></script>
<script src="js/EditRegionWindow.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AgentList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AddAgent.js" type="text/javascript" charset="utf-8"></script>
<script src="js/EditAgent.js" type="text/javascript" charset="utf-8"></script>
<script src="js/SystemSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/CustomLog.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AgentLog.js" type="text/javascript" charset="utf-8"></script>
<script src="js/PublicFunctions.js" type="text/javascript" charset="utf-8"></script>
<script src="js/OrderDetailWindow.js" type="text/javascript" charset="utf-8"></script>
<script src="js/HistoryOrderList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/DropOrder.js" type="text/javascript" charset="utf-8"></script>
<script src="js/CustomReport.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MonthlyReport.js" type="text/javascript" charset="utf-8"></script>
<script src="js/DailyReport.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MyCustomReport.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MyMonthlyReport.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MyDailyReport.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MyRestaurant.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AddStreet.js" type="text/javascript" charset="utf-8"></script>
<script src="js/GiftConvert.js" type="text/javascript" charset="utf-8"></script>
<script src="js/GiftSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/ScoreSet.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
var serverTime = <?php date_default_timezone_set('PRC'); echo time()*1000; ?>;
var timeDiff = (new Date()).getTime()-serverTime;
var baseUrl = 'http://<?php $self = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; echo substr($self,0,strrpos($self, "admin"));?>';     
</script>
</html>
<?php
}
else {
?>
<!--   <!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
-->
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>后台管理系统</title>

<link href="extjs/resources/css/ext-all.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="css/app.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="extjs/ux/css/CheckHeader.css"  rel="stylesheet" type="text/css"/>

<script src="extjs/bootstrap.js" type="text/javascript" charset="utf-8"></script>
<script src="extjs/locale/ext-lang-zh_CN.js" type="text/javascript" charset="utf-8"></script>


<script type="text/javascript" src="http://ditu.google.cn/maps/api/js?libraries=places&sensor=false&language=zh&region=CN"></script>
<script src="js/md5.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AnimationEffectMsg.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MakeMap.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MainWin.js" type="text/javascript" charset="utf-8"></script>
<script src="js/ChangePasswordWindow.js" type="text/javascript" charset="utf-8"></script>
<script src="js/model.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MenuPanel.js" type="text/javascript" charset="utf-8"></script>
<script src="js/CurrentOrderList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/CustomList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/RestaurantList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AddRestaurant.js" type="text/javascript" charset="utf-8"></script>
<script src="js/EditRestaurant.js" type="text/javascript" charset="utf-8"></script>
<script src="js/HomePageSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/HelpPageSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/ContactPageSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AboutPageSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/RightSideSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/SmsServerSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/SmsList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/SmsGroupSend.js" type="text/javascript" charset="utf-8"></script>
<script src="js/SmsSingleSend.js" type="text/javascript" charset="utf-8"></script>
<script src="js/QAList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/CityList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AddCity.js" type="text/javascript" charset="utf-8"></script>
<script src="js/EditCity.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AddRegionWindow.js" type="text/javascript" charset="utf-8"></script>
<script src="js/EditRegionWindow.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AgentList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AddAgent.js" type="text/javascript" charset="utf-8"></script>
<script src="js/EditAgent.js" type="text/javascript" charset="utf-8"></script>
<script src="js/SystemSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/CustomLog.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AgentLog.js" type="text/javascript" charset="utf-8"></script>
<script src="js/PublicFunctions.js" type="text/javascript" charset="utf-8"></script>
<script src="js/OrderDetailWindow.js" type="text/javascript" charset="utf-8"></script>
<script src="js/HistoryOrderList.js" type="text/javascript" charset="utf-8"></script>
<script src="js/DropOrder.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MyCustomReport.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MyMonthlyReport.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MyDailyReport.js" type="text/javascript" charset="utf-8"></script>
<script src="js/CustomReport.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MonthlyReport.js" type="text/javascript" charset="utf-8"></script>
<script src="js/DailyReport.js" type="text/javascript" charset="utf-8"></script>
<script src="js/MyRestaurant.js" type="text/javascript" charset="utf-8"></script>
<script src="js/AddStreet.js" type="text/javascript" charset="utf-8"></script>
<script src="js/GiftConvert.js" type="text/javascript" charset="utf-8"></script>
<script src="js/GiftSetting.js" type="text/javascript" charset="utf-8"></script>
<script src="js/ScoreSet.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
Ext.Loader.setConfig({enabled: true});

Ext.Loader.setPath('Ext.ux', 'extjs/ux');

Ext.require([
	'Ext.window.*',
	'Ext.tip.*',
	'Ext.tab.*',
	'Ext.form.*',
	'Ext.toolbar.*',
    'Ext.grid.*',
    'Ext.selection.*',
	'Ext.data.*',
	'Ext.container.*',
	'Ext.util.*',
	'Ext.LoadMask',
    'Ext.ux.CheckColumn',
    'Ext.ux.RowExpander',
    'Ext.ux.grid.plugin.RowEditing'
]);

var realname='<?php echo $_SESSION['admin_real_name'];?>';
var isrestaurant='<?php echo $_SESSION['admin_is_restaurant'];?>';
var displayname='<?php echo $_SESSION['admin_display_name'];?>';
var privileges='<?php echo $_SESSION['admin_privileges'];?>';
var serverTime = <?php date_default_timezone_set('PRC'); echo time()*1000; ?>;
var timeDiff = (new Date()).getTime()-serverTime;
var baseUrl = 'http://<?php $self = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; echo substr($self,0,strrpos($self, "admin"));?>';     

var thisrestaurant = <?php echo isset($_SESSION['admin_thisrestaurant']) ? $_SESSION['admin_thisrestaurant'] : '{}'?>;



var mainWin = null;

Ext.onReady(function(){	
	Ext.QuickTips.init();
	mainWin = new MainWin({isrestaurant: isrestaurant, realname: realname, displayname: displayname, privileges: privileges});
	mainWin.show();
});

</script>

</head>
<body>
</body>
</html>
<?php
}
?>