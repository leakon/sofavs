<?php
/**
 * 此文件用于餐品图像文件上传，
 */
require "../inc/config.php";
header("Content-Type:text/html;charset=utf-8");
//上传限制
if ((($_FILES["my_dish_img"]["type"] == "image/gif")
|| ($_FILES["my_dish_img"]["type"] == "image/jpeg")
|| ($_FILES["my_dish_img"]["type"] == "image/png")))
{
	if(($_FILES["my_dish_img"]["size"] < 2000000)){
		if ($_FILES["my_dish_img"]["error"] > 0){
			$json="{success: false,errors:'文件上传失败，请重试'}";
			echo $json;
		}else{
			//保存上传文件
			if (file_exists("dishimg/" . $_FILES["my_dish_img"]["name"]))
			{
				$json="{success: false,errors:'该文件已经存在!'}";
				echo $json;
			}else{
				//得到对应的餐品的ID
				$id=$_POST['dishId'];//得到该餐品的ID
				$dishImgPath=$_POST['dishImgPath'];//得到该餐品的图片地址
				if($dishImgPath && !empty($dishImgPath)){
					$absolutImgPath=substr(dirname(__FILE__),0,-5).$dishImgPath;//得到该图片在本地硬盘上面的绝度路径
					$absolutImgPath=str_replace ('\\','/',$absolutImgPath);
				}
				//获得上传文件的扩展名文件的扩展名
				$extenName=substr(strrchr($_FILES["my_dish_img"]["name"], '.'), 1);

				$tempImgName=uuid().'.'.$extenName;//获得文件名，xxxxxxx.png 例如
				//组装完全路径
				$depath=substr(dirname(__FILE__),0,-5).'dishimg/'.$tempImgName;//绝度路径
				//相对路径
				$relPath='dishimg/'.$tempImgName;
				//更改路径中的反斜线
				$relPath=str_replace ('\\','/',$relPath);
				$depath=str_replace ('\\','/',$depath);

				//获得图片的长和宽
				$options=getimagesize($_FILES["my_dish_img"]["tmp_name"]);
				$width=$options[0];
				$height=$options[1];

//				--------调试-----
//									$json="{success: false,path:'".$absolutImgPath."</pre>'}";
//									echo $json;
//									return;
//					
//				-----------------



				//查询数据库看看这个餐品是不是存在 对应的图片
				$mysql=mysql_connect($dbhost,$dbuser,$dbpass) or die('网络不畅通');
				mysql_select_db($dbname);
				$sql="select count(*) from dishimg  where dishid =".$id." and imgPath like 'dishimg/%'";
				$result = mysql_query($sql) or die("Query failed : " . mysql_error()/*"数据库查询失败，请重试！"*/);
				$n=mysql_fetch_row($result);
				if($n[0]>0){
					//数据库中有这个文件，那么接下来开始修改数据库中该文件的路径
					$sql="update dishimg set imgPath='".$relPath."',width=".$width.",height=".$height." where dishid=".$id;
					$result = mysql_query($sql) or die("Query failed : " . mysql_error()/*"数据库查询失败，请重试！"*/);
					if(mysql_affected_rows()>0){//更新成功
						//开始移动文件
						//移动图片文件到指定的文件夹中
						if(@move_uploaded_file($_FILES["my_dish_img"]["tmp_name"],$depath)){//移动文件成功
							//删除旧的图片
							if(file_exists($absolutImgPath)){
								if(unlink($absolutImgPath)){
									$json="{success: true,path:'".'删除了'."'}";
									echo $json;
								}else{
									$json="{success: true,path:'".'没有删除'."'}";
									echo $json;
								}
							}else{
								$json="{success: true,path:'".$absolutImgPath."'}";
									echo $json;
							}
								
								
						}else{
							//移动文件失败,那么重新 修改 数据库中的该文件记录
							$sql="update dishimg set imgPath='dishimg/nopic.gif',width=150,height=177 where dishid=".$id;
							$result = mysql_query($sql) or die("Query failed : " . mysql_error()/*"数据库查询失败，请重试！"*/);
							$n=mysql_fetch_row($result);
							if($n[0]>0){
								$json="{success: false,errors:'上传文件失败，请重试'";
								echo $json;
							}
						}
					}else{//更新失败
						$json="{success: false,errors:'上传文件失败，请重试'}";
						echo $json;
					}

				}else{
					//数据库中没有这个文件
				
					$sql="insert into dishimg (imgPath,dishid,width,height) values('".$relPath."',".$id.",".$width.",".$height.")";
					$result = mysql_query($sql) or die("Query failed : " . mysql_error()/*"数据库查询失败，请重试！"*/);
					$n=mysql_affected_rows();
					if($n>0){
						//插入成功
						//开始移动文件
						//移动图片文件到指定的文件夹中
						if(@move_uploaded_file($_FILES["my_dish_img"]["tmp_name"],$depath)){
							//移动文件成功
							$json="{success: true,path:'".$depath."'}";
							echo $json;
						}else{
							//移动文件失败,那么重新 修改 数据库中的该文件记录
							$sql="update dishimg set imgPath='dishimg/defaultDishImg.png',width=200,height=180 where dishid=".$id;
							$result = mysql_query($sql) or die("Query failed : " . mysql_error()/*"数据库查询失败，请重试！"*/);
							$n=mysql_fetch_row($result);
							if($n[0]>0){
								$json="{success: false,errors:'上传文件失败，请重试'";
								echo $json;
							}
						}
					}else{// 插入失败
						$json="{success: false,errors:'上传文件失败，请重试'}";
						echo $json;
					}
				}
			}
		}
	}else{
		$json="{success: false,errors:'文件不能大于2M!'}";
		echo $json;
	}
}
else
{
	$json="{success: false,errors:'文件只能是jpg、gif、png格式!'}";
	echo $json;
}
/*
 * 获得UUID
 */
function uuid($prefix = '')
{
	$chars = md5(uniqid(mt_rand(), true));
	$uuid  = substr($chars,0,8) . '-';
	$uuid .= substr($chars,8,4) . '-';
	$uuid .= substr($chars,12,4) . '-';
	$uuid .= substr($chars,16,4) . '-';
	$uuid .= substr($chars,20,12);
	return $prefix . $uuid;
}
?>