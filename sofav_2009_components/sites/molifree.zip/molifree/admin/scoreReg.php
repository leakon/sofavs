<?php
include_once 'inc/functions.php';
$sql="select * from scorereg";
$db=dao();
$result= $db->query($sql);
$json="{'scoreReg':[]}";
if($row=$result->fetch_assoc()){
	$tip1=str_replace("\n", "", $row['tip1']);
	$tip2=str_replace("\n", "", $row['tip2']);
	$json="{'scoreReg':[{'dingcanscore':".$row['dingcanscore'].",'pinglunscore':".$row['pinglunscore'].",'tip1':'".$tip1."','tip2':'".$tip2."'}]}";
}
$db->close();
echo $json;
?>