<?php
include_once 'inc/functions.php';
if($_POST['action']=="xiajia"){
	$sql="update dish set DenyOrder=1 where ID=".$_POST['dishId'];
	$db=dao();
	$db->query($sql);
	if($db->affected_rows>0){
		echo "{'success':'true'}";
	}else{
		echo "{'success':'failed'}";
	}
	$db->close();
}
?>