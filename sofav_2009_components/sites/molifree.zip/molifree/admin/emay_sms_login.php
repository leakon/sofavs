<?php
header('Content-type: application/json;charset=utf-8');
header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
header('Pragma: no-cache');

require_once("inc/functions.php");

echo emay_sms_login();
?>
