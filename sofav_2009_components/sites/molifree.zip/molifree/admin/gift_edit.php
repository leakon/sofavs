<?php
include_once 'inc/functions.php';
if ($_POST ['m'] == 'edit') { // 编辑 礼品
	if (empty ( $_POST ['giftId'] )) { // 没有ID，添加
		$db = dao ();
		$sql = "insert into lipin (name,score,lipinCount,description) values ('{$_POST['name']}',{$_POST['score']},{$_POST['count']},'{$_POST['des']}')";
		$db->query ( $sql );
		if ($db->affected_rows > 0) {
			echo '{success:true}';
		} else {
			echo '{success:false}';
		}
		$db->close ();
	} else {
		$db = dao ();
		$sql = "update lipin set name='{$_POST['name']}',score= {$_POST['score']}, lipinCount= {$_POST['count']},description='{$_POST['des']}' where lipinId=" . $_POST ['giftId'];
		$db->query ( $sql );
		if ($db->affected_rows > 0) {
			echo '{success:true}';
		} else {
			echo '{success:false}';
		}
		$db->close ();
	}
} else if ($_POST ['m'] == 'del') {
	$db=dao();
	$sql = "delete from  lipin where lipinId=" . $_POST ['giftId'];
	$db->query ($sql);
	if ($db->affected_rows > 0) {
		echo '{success:true}';
	} else {
		echo '{success:false}';
	}
	$db->close ();
}