<?php
/**
 * 此文件用于礼品图像文件上传，2013-2-1
 */
require "inc/functions.php";
header("Content-Type:text/html;charset=utf-8");
//上传限制
if ((($_FILES["my_gift_img"]["type"] == "image/gif")
|| ($_FILES["my_gift_img"]["type"] == "image/jpeg")
|| ($_FILES["my_gift_img"]["type"] == "image/png")))
{
	if(($_FILES["my_gift_img"]["size"] < 2000000)){
		if ($_FILES["my_gift_img"]["error"] > 0){
			$json="{success: false,errors:'文件上传失败，请重试'}";
			echo $json;
		}else{
			//保存上传文件
			if (file_exists("lipinimg/" . $_FILES["my_gift_img"]["name"]))
			{
				$json="{success: false,errors:'该文件已经存在!'}";
				echo $json;
			}else{
				//得到对应的餐品的ID
				$id=$_POST['giftId'];//得到该礼品的ID
				$dishImgPath=$_POST['giftImagePath'];//得到该礼的图片地址
				if($dishImgPath && !empty($dishImgPath)){
					$absolutImgPath=substr(dirname(__FILE__),0,-5).$dishImgPath;//得到该图片在本地硬盘上面的绝度路径
					$absolutImgPath=str_replace ('\\','/',$absolutImgPath);
				}
				//获得上传文件的扩展名文件的扩展名
				$extenName=substr(strrchr($_FILES["my_gift_img"]["name"], '.'), 1);

				$tempImgName=uuid().'.'.$extenName;//获得文件名，xxxxxxx.png 例如
				//组装完全路径
				$depath=substr(dirname(__FILE__),0,-5).'lipinimg/'.$tempImgName;//绝度路径
				//相对路径
				$relPath='lipinimg/'.$tempImgName;
				//更改路径中的反斜线
				$relPath=str_replace ('\\','/',$relPath);
				$depath=str_replace ('\\','/',$depath);

				//获得图片的长和宽
// 				$options=getimagesize($_FILES["my_gift_img"]["tmp_name"]);
// 				$width=$options[0];
// 				$height=$options[1];

//				--------调试-----
//									$json="{success: false,path:'".$absolutImgPath."</pre>'}";
//									echo $json;
//									return;
//					
//				-----------------

					$db=dao();
					//数据库中有这个文件，那么接下来开始修改数据库中该文件的路径
// 					$sql="update dishimg set imgPath='".$relPath."',width=".$width.",height=".$height." where dishid=".$id;
					$sql="update lipin set imgPath='".$relPath."' where lipinId=".$id;
					$db->autocommit(0);
					$flag=true;
					$db->query($sql);
					if($db->affected_rows>0){//更新成功
						//开始移动文件
						//移动图片文件到指定的文件夹中
						if(@move_uploaded_file($_FILES["my_gift_img"]["tmp_name"],$depath)){//移动文件成功
							//删除旧的图片
							if($dishImgPath!='lipinimg/default.jpg' &&  file_exists($absolutImgPath)){
								if(unlink($absolutImgPath)){
									$json="{success: true,path:''}";
									echo $json;
								}else{
									$falg=false;//原来的图片没有删除掉
									$json="{success: false,errors:'上传文件失败'}";
									echo $json;
								}
							}else{//不存在原来的图片，那么就直接成功
									$json="{success: true,path:'".$absolutImgPath."'}";
									echo $json;
							}
						}else{
							
							//移动文件失败,那么重新 修改 数据库中的该文件记录
								$falg=false;
								$json="{success: false,errors:'上传文件失败，请重试'";
								echo $json;
							
						}
					}else{//更新失败
						$falg=false;
						$json="{success: false,errors:'上传文件失败，请重试'}";
						echo $json;
					}
					if($flag){
						$db->commit();
					}else{
						$db->rollback();
					}
					$db->close();
			}
		}
	}else{
		$json="{success: false,errors:'文件不能大于2M!'}";
		echo $json;
	}
}
else
{
	$json="{success: false,errors:'文件只能是jpg、gif、png格式!'}";
	echo $json;
}
/*
 * 获得UUID
*/
function uuid($prefix = '')
{
	$chars = md5(uniqid(mt_rand(), true));
	$uuid  = substr($chars,0,8) . '-';
	$uuid .= substr($chars,8,4) . '-';
	$uuid .= substr($chars,12,4) . '-';
	$uuid .= substr($chars,16,4) . '-';
	$uuid .= substr($chars,20,12);
	return $prefix . $uuid;
}
?>