<?php
include_once 'inc/functions.php';
if(empty($_POST['streetId'])){//添加
	$cityName=$_POST['cityName'];
	$cityId=$_POST['cityId'];
	$regionName=$_POST['regionName'];
	$regionId=$_POST['regionId'];
	$streetName=$_POST['streetName'];
	$lat=$_POST['lat'];
	$lng=$_POST['lng'];
	$hide=$_POST['hide']=='on'?'1':'0';
	$zoomLeave=$_POST['zoomLeave'];
	$first=getfirstchar(utf8Substr($streetName,0,1));
	$sql="insert into `street`(`Name`,`regionId`,`regionName`,`cityId`,`cityName`,`zoomLeave`,`hide`,`lat`,`lng`,`sequence`)".
	"values('{$streetName}',{$regionId},'{$regionName}',{$cityId},'{$cityName}','{$zoomLeave}',{$hide},'{$lat}','{$lng}','{$first}')";
	$db=dao();
	$db->query($sql);
	if($db->affected_rows>0){
		echo "{success:true}";
	}else{
		echo "{success:false,errors:'网络失败，请重试！'}";
	}
}else{//更新
	$cityId=$_POST['cityId'];
	$id=$_POST['streetId'];
	$regionName=$_POST['regionName'];
	$regionId=$_POST['regionId'];
	$streetName=$_POST['streetName'];
	$lat=$_POST['lat'];
	$lng=$_POST['lng'];
	$theHide=$_POST['hide']=='on'?'1':'0';
	$zoomLeave=$_POST['zoomLeave'];
	$cityName=$_POST['cityName'];
	$first=getfirstchar(utf8Substr($streetName,0,1));

//	$sql="insert into `street`(`Name`,`regionId`,`regionName`,`cityId`,`cityName`,`zoomLeave`,`hide`,`lat`,`lng`,`sequence`)".
//	"values('{$streetName}',{$regionId},'{$regionName}',{$cityId},'{$cityName}','{$zoomLeave}','{$hide}','{$lat}','{$lng}','{$first}')";
	$sql="update `street` set `Name`='{$streetName}',`regionId`='{$regionId}',`regionName`='{$regionName}',`cityId`='{$cityId}',`cityName`='{$cityName}',`zoomLeave`='$zoomLeave',`hide`={$theHide},`lat`='{$lat}',`lng`='{$lng}',`sequence`='{$first}' where id=".$id;
	file_put_contents("c:/2.txt", $sql);
	$db=dao();
	$db->query($sql);
	if($db->affected_rows>-1){
		echo "{success:true}";
	}else{
		echo "{success:false,errors:'网络失败，请重试！'}";
	}
}