<?php
header('Content-type: application/json;charset=utf-8');
header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
header('Pragma: no-cache');

require_once("inc/functions.php");
if(getRestarautCount()>1){
	echo error_json( "免费版只能添加一个餐馆！如需商业版，请联系我们（www.molicun.com）" );
}else {
	echo add_restaurant() ;
}


?>
