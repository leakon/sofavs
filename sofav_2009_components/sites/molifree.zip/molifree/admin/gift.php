<?php
include_once 'inc/functions.php';
$sql = "select * from lipin where 1=1 ";
$count=0;
$db = dao ();

if ($_GET ['action'] == 'init') {//初始化
	$re=$db->query("select count(*) as c from lipin ");
	if($row=$re->fetch_assoc()){
		$count=$row['c'];
	}
} else if ($_GET ['action'] == 'query') {
	$re=$db->query("select count(*) as c from lipin where name like '%{$_GET['query']}%'");
	if($row=$re->fetch_assoc()){
		$count=$row['c'];
	}
	$sql.=" and name like '%{$_GET['query']}%'";
}
$sql .= ' limit ' . $_GET ['start'] . ',' . $_GET ['limit'];

//$sql=$db->escape_string($sql);
$result = $db->query ( $sql );
$json = '{"total":'.$count.',"gifts":[';
$i = 0;
while ( $row = $result->fetch_assoc () ) {
	if ($i == 0) {
		$json .= "{'id':{$row['lipinId']},'lpName':'{$row['name']}','lpImgPath':'{$row['imgPath']}','lpScore':{$row['score']},'lpCount':{$row['lipinCount']},'lpDes':'{$row['description']}'}";
	} else {
		$json .= ",{'id':{$row['lipinId']},'lpName':'{$row['name']}','lpImgPath':'{$row['imgPath']}','lpScore':{$row['score']},'lpCount':{$row['lipinCount']},'lpDes':'{$row['description']}'}";
	}
	$i ++;
}
$json .= ']}';
$db->close ();
echo $json;