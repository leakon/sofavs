<?php
require_once("inc/functions.php");

logout();

header("Location: index.php");
?>