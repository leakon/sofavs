<?php
header('Content-type: application/json;charset=utf-8');
header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
header('Pragma: no-cache');

require_once("inc/functions.php");

$loginResult = login();

if($loginResult===true){
	echo '{"success": true, ' .
			'"isrestaurant": "'.$_SESSION['admin_is_restaurant'].'", ' .
			'"realname": "'.$_SESSION['admin_real_name'].'", ' .
			'"displayname": "'.$_SESSION['admin_display_name'].'", ' .
			'"privileges": "'.$_SESSION['admin_privileges'].'", ' .
			'"thisrestaurant": '.(isset($_SESSION['admin_thisrestaurant']) ? $_SESSION['admin_thisrestaurant'] : '{}').'}';
}
else {
	echo '{"success": false, "msg": "'.nl2br($loginResult).'"}';
}
?>
