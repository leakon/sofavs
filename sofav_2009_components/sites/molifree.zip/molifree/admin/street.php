<?php
include_once 'inc/functions.php';
$sql="select * from street limit ".$_GET['start']." , ".$_GET['limit'] ;
$db= dao();
$total=0;//总记录数
$re=$db->query("select count(*) as c from street");
if($row=$re->fetch_assoc()){
	$total= $row['c'];
}

$result=$db->query($sql);
/*
 * 		{name: 'id', type: 'int'},
		{name: 'name', type: 'string'},
		{name: 'cityid', type: 'int'},
		{name: 'city', type: 'string'},
		{name: 'regionId', type: 'int'},
		{name: 'regionName', type: 'string'},
		{name: 'zoomlevel', type: 'int'},
		{name: 'hide', type: 'int'},
		{name: 'sequence', type: 'int'},
		{name: 'lat', type: 'string'},
		{name: 'lng', type: 'string'}
*/
$i=0;
$json="{total:{$total},streets:[";
while($row=$result->fetch_assoc()){
	if($i==0){
		$json.="{'id':{$row['id']},'name':'{$row['Name']}','cityId':{$row['cityId']},'cityName':'{$row['cityName']}','regionId':{$row['regionId']},'regionName':'{$row['regionName']}','zoomleave':{$row['zoomLeave']},'hide':{$row['hide']},'sequence':'{$row['sequence']}','lat':'{$row['lat']}','lng':'{$row['lng']}'}";
	}else{
		$json.=",{'id':{$row['id']},'name':'{$row['Name']}','cityId':{$row['cityId']},'cityName':'{$row['cityName']}','regionId':{$row['regionId']},'regionName':'{$row['regionName']}','zoomleave':{$row['zoomLeave']},'hide':{$row['hide']},'sequence':'{$row['sequence']}','lat':'{$row['lat']}','lng':'{$row['lng']}'}";
	}
	$i++;
}
$json.="]}";
echo $json;
?>