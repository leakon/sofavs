<?php
ini_set('display_errors', 0);
$dbhost = "127.0.0.1:3312";
$dbuser = "xcart";
$dbpass = "D593_OTm9_CUi8_4Qz5";
$dbname = "mall_xcart";
?>
