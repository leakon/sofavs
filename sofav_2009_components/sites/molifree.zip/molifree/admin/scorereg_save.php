<?php
	include_once 'inc/functions.php';
	echo save_scoreReg();
?>