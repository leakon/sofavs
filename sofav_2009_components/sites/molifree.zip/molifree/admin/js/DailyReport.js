if (!Ext.ModelManager.isRegistered('DailyReport')){
Ext.define('DailyReport', {
	extend : 'Ext.tree.Panel',
	alias  : 'widget.DailyReport',
	
	initComponent : function() {
		this.store = Ext.create('Ext.data.TreeStore',{
			autoDestroy: true,
			model: 'CommissionTreeNode',
			proxy: {
				type: 'ajax',
				url: 'commissions_daily.php',
				extraParams: {
					close : true
				},
				timeout : 30*60*1000
			},
			sorters: [{
				property: 'leaf',
				direction: 'ASC'
//			},{
//				property: 'text',
//				direction: 'ASC'
			}],
			folderSort: true,
			root: {
				text: '根节点',
				id: 0,
				expanded: true
			},
			listeners: {
				load: function(store,node, records, successful, opts) {
					store.getProxy().extraParams.close = false;
				}
			}
		});
		
		
		Ext.apply(this, {
			id : 'widget.DailyReport',
			title : '财务管理-按日查询',
			closable : true,
			autoScroll : true,
			useArrows: true,
			rootVisible: false,
			multiSelect: true,
			
	        columns: [
//	        	{
//	        		xtype	 : 'rownumberer',
//	                width    : 40
//	        	},
	        	{
					xtype: 'treecolumn',
	                text     : '名称',
	                width    : 400,
	                sortable : true,
	                dataIndex: 'text'
	            },
	            {
	                text     : '日期',
	                width    : 150,
	                sortable : true,
	                dataIndex: 'Day',
	                align : 'center'
	            },
	            {
	                text     : '销售额（元）',
	                width    : 100,
	                sortable : true,
	                dataIndex: 'Sale',
	                align : 'right'
	            },
	            {
	                text     : '佣金比率（%）',
	                width    : 100,
	                sortable : true,
	                dataIndex: 'Rate',
	                align : 'right'
	            },
	            {
	                text     : '佣金费（元）',
	                width    : 100,
	                sortable : true,
	                dataIndex: 'Commission',
	                align : 'right'
	            },
	            {
	                text     : '状态',
	                minWidth : 200,
	                sortable : true,
	                dataIndex: 'Status',
	                align	 : 'center',
	                editor: {
						xtype: 'combo',
						store: [
		                    ['已结算','已结算'],
		                    ['未结算','未结算']
		                ],
		                lazyRender: true,
		                listClass: 'x-combo-list-small',
		                listeners: {
						scope: this,
						'select' : function(combobox, value){
							//this.searchOperation = value[0].data.field1;
						}
					}
	                }
	            }
	        ],
	        dockedItems: [{
				xtype: 'toolbar',
				items: ['搜索',{
					xtype: 'textfield',
					name: 'searchText',
					tooltip:{text:'可以在此输入代理名称、电话、姓名、餐馆名称、城市名称等进行模糊查询。',title:'搜索提示'},
					hideLabel: true,
					width: 130,
					listeners: {
						 change: {
						 	fn: function(field, newValue, oldValue) {
						 		this.searchText = newValue;
						 	},
						 	scope: this,
							buffer: 100
						 },
						 afterrender: {
						 	fn: function(field) {
							 		if(field.tooltip.text){   
					                    new Ext.ToolTip({
					                        target:field.id,
					                        trackMouse:false,
					                        draggable:true,
					                        maxWidth:300,
					                        minWidth:100,
					                        title:"<span style='color:green'>" + field.tooltip.title + "</span>",
					                        html:"<span style='color:green'>" + field.tooltip.text + "</span>"
					                    }); 
					                }  
							 	}
						 }
					}
				},'　',{
					xtype: 'numberfield',
					width: 60,
					name: 'searchYear',
					value: new Date().getFullYear(),
					hideLabel: true,
					minValue: 2012,
					maxValue: 2030,
					allowDecimals: false,
	                listeners: {
						scope: this,
						'change' : function(field, newValue, oldValue){
							this.searchYear = newValue;
						}
					}
				},'年　',{
					xtype: 'numberfield',
					width: 40,
					name: 'searchMonth',
					hideLabel: true,
					value: (new Date().getMonth()+1),
					minValue: 1,
					maxValue: 12,
					allowDecimals: false,
	                listeners: {
						scope: this,
						'change' : function(field, newValue, oldValue){
							this.searchMonth = newValue;
						}
					}
				},'月　',{
					xtype: 'numberfield',
					width: 40,
					name: 'searchDay',
					hideLabel: true,
					value: (new Date().getDate()),
					minValue: 1,
					maxValue: 31,
					allowDecimals: false,
	                listeners: {
						scope: this,
						'change' : function(field, newValue, oldValue){
							this.searchDay = newValue;
						}
					}
				},'日','　状态',{
					xtype: 'combo',
					width: 80,
					name: 'searchStatus',
					hideLabel: true,
					store: [
	                    ['','全部'],
	                    ['已结算','已结算'],
						['未结算','未结算']
	                ],
	                lazyRender: true,
	                listClass: 'x-combo-list-small',
	                listeners: {
						scope: this,
						'select' : function(combobox, value){
							this.searchStatus = value[0].data.field1;
						}
					}
				},' ',{
					text:'开始搜索',
					tooltip:'开始搜索',
					iconCls:'search',
					scope: this,
					handler: this.startSearch
				}]
			}]
		});
		this.callParent(arguments);
	},
	
	startSearch : function() {
		var store = this.store;
		var proxy = store.getProxy();
		proxy.extraParams.searchText = this.searchText;
		proxy.extraParams.searchYear = this.searchYear;
		proxy.extraParams.searchMonth = this.searchMonth;
		proxy.extraParams.searchDay = this.searchDay;
		proxy.extraParams.searchStatus = this.searchStatus;
		//解决一个BUG：
		//@see http://blog.csdn.net/fruitsdrink/article/details/7072435
		var delNode;
		while (delNode = this.getRootNode().childNodes[0]) {
			this.getRootNode().removeChild(delNode);
		}
		store.load();
	}
});
}