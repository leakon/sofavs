if (!Ext.ModelManager.isRegistered('MenuPanel')){
Ext.define('MenuPanel', {
	extend : 'Ext.panel.Panel',
	alias  : 'widget.MyMenuPanel',
	
	initComponent : function() {
		Ext.apply(this, {
			region : 'west',
			collapsible : true,
			title : '系统菜单',
			iconCls: 'menu',
			width : 150,
			split : true,
			minWidth : 120,
			maxWidth : 250,
			autoScroll : true,
			layout: {
        		type: 'anchor',
				align: 'center'
			},
			items: []
		});
		this.callParent(arguments);
	}
});
}