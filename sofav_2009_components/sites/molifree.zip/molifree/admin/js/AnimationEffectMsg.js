//var animationMsg = null;
//
//Ext.define("AnimationEffectMsg", {
//	message : null,
//	init : function(){
//		var __AnimationEffectMsg_html_ = '<div id="animation_effect_msg" style="display: none;">test</div>';
//		this.el = new Ext.Element(__AnimationEffectMsg_html_);
//	},
//	setMsg : function(msg) {
//		this.message = msg;
////		this.el.dom.innerHTML = 
//	},
//	show : function() {
//		this.el.show();
//	}
//});
//
//Ext.onReady(function(){
//	animationMsg = new AnimationEffectMsg();
//	animationMsg.init();
//});
