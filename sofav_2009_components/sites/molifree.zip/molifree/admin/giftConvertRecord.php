<?php
include_once 'inc/functions.php';
$totalCountSql="select count(*) as c from lipinexchangerecord where 1=1 ";
$db=dao();//创建数据交换层对象


//首先封装 基本的sql 查询语句
$sql="select lc.id as convertId,c.Username as customName,lp.name as lpName ,lc.address,lc.phone,lc.notice,lc.createTime,lc.endTime,lc.status from lipinexchangerecord as lc ,Custom as c,lipin as lp where lc.customId=c.ID and lc.lipinId=lp.lipinId ";
//是不是点击了查询按钮
if($_GET['action']=='query'){//如果是的话在后面 加上查询条件，
	$lpName=$_GET['query'];
	$sql.=" and lpName like '%{$lpName}%'";//家上查询条件之后形成新的sql
	//得到新的数量查询 sql
	$totalCountSql.=" and name like '%{$lpName}%' ";
}
$sql.=" order by convertId desc";
$sql.=" limit ".$_GET['start'].",".$_GET['limit'];//然后加上 分页调价

$totalCount=0;//总数量
$re= $db->query($totalCountSql);
if($row=$re->fetch_assoc()){
	$totalCount=$row['c'];
}
$result=$db->query($sql);
$json="{total:{$totalCount},records:[";
$j=0;
while($row=$result->fetch_assoc()){
	if($j==0){
		$json.="{'convertId':{$row['convertId']},'customName':'{$row['customName']}','lpName':'{$row['lpName']}','address':'{$row['address']}','phone':'{$row['phone']}','notice':'{$row['notice']}','createTime':'{$row['createTime']}','endTime':'{$row['endTime']}','status':'{$row['status']}'}";
	}else{
		$json.=",{'convertId':{$row['convertId']},'customName':'{$row['customName']}','lpName':'{$row['lpName']}','address':'{$row['address']}','phone':'{$row['phone']}','notice':'{$row['notice']}','createTime':'{$row['createTime']}','endTime':'{$row['endTime']}','status':'{$row['status']}'}";
	}
	$j++;
}
$json.="]}";
echo $json;
?>