<?php
include 'HttpClient.class.php';

function print_msg($text,$member_code,$feyin_key,$device_no){
	//	define('MEMBER_CODE', $member_code);
	//	define('FEYIN_KEY', $feyin_key);
	//	define('DEVICE_NO', $device_no);

	define('FEYIN_HOST','my.feyin.net');
	define('FEYIN_PORT', 80);
	date_default_timezone_set ( 'PRC' );
	$msgNo = time()+1;
	/*
	 自由格式的打印内容
	 */

	$freeMessage = array(
		'memberCode'=>$member_code, 
		'msgDetail'=>$text,
//
//   $_SESSION['session_Setting_SITE_NAME'].'欢迎您订购
//
//
//条目         单价（元）    数量
//------------------------------
//番茄炒粉
//             10.0          1
//客家咸香鸡
//             20.0          1
//
//备注：请快点送货。
//------------------------------
//合计：30.0元 
//
//送货地址：北京中关村科技大厦23楼
//联系电话：1380017****
//订购时间：2011-01-06 19:30:10
//',
		'deviceNo'=>$device_no, 
		'msgNo'=>$msgNo,
	);

	sendFreeMessage($freeMessage,$feyin_key);

	return $msgNo;

}
//----------------------以下是接口定义实现，第三方应用可根据具体情况直接修改----------------------------
function sendFreeMessage($msg,$feyin_key) {
	$msg['reqTime'] = number_format(1000*time(), 0, '', '');
	$content = $msg['memberCode'].$msg['msgDetail'].$msg['deviceNo'].$msg['msgNo'].$msg['reqTime'].$feyin_key;
	$msg['securityCode'] = md5($content);
	$msg['mode']=2;
	return sendMessage($msg);
}
function sendMessage($msgInfo) {
	$client = new HttpClient(FEYIN_HOST,FEYIN_PORT);
	if(!$client->post('/api/sendMsg',$msgInfo)){ //提交失败
		return 'faild';
	}
	else{
		return $client->getContent();
	}
}
?>