<?php
header('Content-Type: text/html; charset=UTF-8');
ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL^E_NOTICE^E_DEPRECATED);
$dbhost = "127.0.0.1:3312";
$dbuser = "xcart";
$dbpass = "D593_OTm9_CUi8_4Qz5";
$dbname = "mall_xcart";
$masteremail = "";
$baseurl = "";
?>
