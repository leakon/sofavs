<?php
require_once("inc/functions.php");
$messages = get_messages();
$from = addslashes(trim($_GET['from'])) + 10;
?>
{"ret":1,"nextPage":"getmoresupportmessage.php?limit=10&from=<?php echo $from; ?>"}

<!--JH-->
<?php foreach($messages as $message) { ?>	
<li class="leihou-dialog">
	<div class="main_msg leihou-message leihou-asker">
		<div class="content"><span class="leihou-author"><?php echo $message['Name']; ?></span>&nbsp;<?php echo $message['Question']; ?></div>
	</div>
	<div class="reply_msgs leihou-message leihou-answerer">
		<div class="content"><span class="leihou-author"><?php echo $_SESSION['session_Setting_SITE_NAME']; ?>答疑</span>&nbsp;<?php echo $message['Answer']; ?></div>
	</div>
</li>
<?php } ?>