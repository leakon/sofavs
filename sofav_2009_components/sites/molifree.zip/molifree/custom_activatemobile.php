<?php
require_once 'inc/functions.php';
verify_mobile();
header('Location: custom_mobile.php');
?>
