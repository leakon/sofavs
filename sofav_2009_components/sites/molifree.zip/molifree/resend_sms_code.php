<?php
require_once 'inc/functions.php';
resend_sms_code(); //重发短信验证码，并会根据来源重定向到正确的页面。
?>
