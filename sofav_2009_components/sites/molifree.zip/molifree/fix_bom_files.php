<?php

define('NEEDLE',        chr('0xEF') . chr('0xBB') . chr('0xBF'));

$file       = isset($argv[1]) ? $argv[1] : '';
$fix        = isset($argv[2]) ? $argv[2] : 0;

if (is_file($file)) {

    $cont       = file_get_contents($file);

    $found      = CheckBOM($cont);

    if ($found && $fix) {
        #var_dump(urlencode($cont));
        $cont       = substr($cont, 3);
        #var_dump(urlencode($cont));
        file_put_contents($file, $cont);
        echo    $file . " [Fixed]";
    }

}


function CheckBOM($content) {

    $found      = false;

    if (0 === strpos($content, NEEDLE)) {

        $found  = true;

    }

    return  $found;

}


