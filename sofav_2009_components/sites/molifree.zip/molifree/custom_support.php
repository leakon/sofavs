<?php
require_once 'inc/functions.php';
$messages = get_custom_messages();
include 'header_account.php';
?>
<link rel="stylesheet" type="text/css" media="screen" href="css/support.index.css"/>
<script type="text/javascript">
document.title = "<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> / 我的答疑";
</script>

<div class="columns">
<div class="inner_columns">
<div class="left">
	<div id="content">
		<div id="settings_nav" class="tab_nav">
			<ul>
				<li>
					<a href="custom_account.php">帐号密码</a>
				</li>
				<li>
					<a href="custom_mobile.php">手机号码</a>
				</li>
				<li>
					<a href="custom_addresses.php">常用地址</a>
				</li>
				<li class="current">
					<a href="custom_support.php">我的答疑</a>
				</li>
				<li>
					<a href="custom_orders_list.php">订单历史</a>
				</li>
				<?php if(!empty($_SESSION['session_hasActiveOrder'])) { ?>
				<li>
					<a href="orders_myactive.php">当前订单</a>
				</li>
				<?php } ?>
			</ul>
		</div>
		<div id="support_board" class="support_board">
			<form class="support_form" action="newsupportmessage.php" method="post">
				<div class="reply_arrow"></div>
				<div>
					<textarea class="text content" name="content"></textarea>
				</div>
				<div class="submit_support_message">
					<input type="submit" value="提交" class="btn submit" />
				</div>
			</form>
			<div class="support_timeline">
				<ol>
				<?php foreach($messages as $message) { ?>
					<li class="message<?php if(empty($message['Answer'])) echo ' not_replied';?>">
						<div class="main_message">
							<div class="content"><?php echo $message['Question'];?></div>
							<div class="timestamp">
								<?php echo $message['QTime'];?>
							</div>
						</div>
						<div class="reply_messages">
							<div class="reply_arrow"></div>
							<div class="reply_content"><?php echo $message['Answer'];?></div>
							<div class="timestamp">
								<?php echo $message['ATime'];?>
							</div>
						</div>
					</li>
				<?php } ?>
				</ol>
			</div>
		</div>
	</div>
</div>
<div class="right">
	<div id="side">
		<div class="section">
			<div class="section-header">
				<h3 class="faq-header">
					我的答疑
				</h3>
			</div>
			<p>
				这是你专属的答疑页面，在这里可以看到你最新提出的十个问题和它们的回复。
			</p><br/>
		</div>
	</div>
</div>
</div>
</div>
<?php include 'footer.php'; ?>