<?php
require_once("inc/functions.php");
if( account_create() ){
	if(!empty($_SESSION['session_login_from_orders'])){
		header("Location: orders_create.php");
		$_SESSION['session_login_from_orders'] = 0;
	}
	else {
		header("Location: index.php");
	}
}
?>
