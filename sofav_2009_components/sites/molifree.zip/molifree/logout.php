<?php
require_once 'inc/functions.php';
logout();
?>
