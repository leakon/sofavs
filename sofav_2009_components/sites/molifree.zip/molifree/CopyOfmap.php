<?php
require_once("inc/functions.php");
?>

<!DOCTYPE html>
<html lang="zh">
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
	<meta content="zh" http-equiv="Content-Language"/>
	<meta content="no" http-equiv="imagetoolbar"/>
	<meta content="width=990" name="viewport"/>
	<meta http-equiv="X-UA-Compatible" content="chrome=1" />
	<meta name="robots" content="index,follow"/>
	<title><?php echo $_SESSION['session_Setting_SITE_NAME']; ?> - 外卖地图</title>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.footer.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.header.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.body.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/notifications.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/application.map.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/application.map.area_list.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/application.map.canvas.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/application.map.sneak.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/restaurant_info.css"/>
<!--	<link rel="stylesheet" type="text/css" media="screen" href="css/map_new_year_2012.css"/>-->
	<script src="js/remove_unicom.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.z.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/header_menu.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/lib.json2.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/settings.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/notifications.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/counter.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" src="http://ditu.google.cn/maps/api/js?libraries=places&sensor=false&language=zh&region=CN"></script>
	<script src="js/jquery.map.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.scrollto-min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.parabola.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/GlassBubble.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/common.map_canvas.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/common.map_search_form.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/application.map.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/application.map.area_selector.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/application.map.resize.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/fav_restaurants.add_delete.js" type="text/javascript" charset="utf-8"></script>
</head>
<body id="map" class="<?php echo get_client_browser_type(); ?>">

	<div id="prototypes" style="display:none">
		<?php include 'map_city_regions.php'; ?>
	</div><!--end of prototypes-->

	<div id="container" class="<?php echo get_client_browser_type(); ?>">
		
		<!--头部-->
		<div id="header-outer">
			<div id="header">
				<h3 class="offscreen">页首</h3>
				<?php include 'top_nav.php'; ?>
				<div class="bookmark"></div>
			</div><!--header-->
		</div><!--header-outer-->
		
		
<?php if( $_SESSION['session_maphint']!='0' ){ ?>
		<!--一个欢迎模式对话框-->
		<div id="welcome_outer" class="dismiss_hint">
			<div id="welcome_mask"></div>
			<div id="welcome">
				<h3>在外卖地图能做什么？</h3>
				<ol>
					<li>发现你身边<strong>每一家</strong>有外卖的餐厅</li>
					<li>把喜欢的<strong>加到首页</strong></li>
					<li>定制完成，可以<strong>回首页订餐</strong>了！</li>
				</ol>
				<div class="dismiss"><a id="welcome_dismiss_btn" class="dismiss_button" href="settings.php?maphint=close">我知道了</a></div>
			</div>
		</div>
<?php } ?>
		
		<!--提示信息-->
		<div id="notifications">
		</div>
		
		<div class="columns wide">
			<div class="inner_columns">
				<div class="left">
					<div id="content">
						<div id="map_outer">
						
							<!-- 地图上方的toolbar -->
							<div id="map_toolbar">
								<div id="back_home_btn" class="back_home_btn">
									<a href="/">
										首页 
										<span id="fav_restaurants_count" class=" badge_for_1"><?php echo city_faver_count($_SESSION['session_city']); ?></span>
									</a>
								</div>
								<form id="map_search" action="map_bounds.php" data-query="">
									<div id="map_search_inner">
										<div id="area_selector">
											<a href="javascript:void(0)" id="area_selector_toggle" class="toggle"><?php echo $_SESSION['session_city'];?></a>
										</div>
										<label>街道:</label>
										<input id="map_area_search_box" class="text" type="text" name="location" placeholder="街道地名、部分小区亦可搜索" value=""/>
										<label id="map_search_box_label">餐厅:</label>
										<input id="map_search_box" class="text" type="text" name="q" placeholder="餐厅名称、电话" value=""/>
										<input id="map_search_restaurant" type="submit" value="搜索" class="btn"/>
										<input id="map_area_search_city" type="hidden" name="city" value="<?php echo $_SESSION['session_city'];?>"/>
									</div>
									<input id="map_bounds" type="hidden" value=""/>
								</form>
							</div><!--map_toolbar-->
							
							<!--地图模块-->
							<div id="map_canvas_outer">
								<!--地图右侧的列表-->
								<div id="map_canvas_left">
									<div id="restaurant">
										<h3>地图上的餐厅：</h3>
										<ul id="restaurant_search_result"></ul>
									</div>
								</div>
								<!--地图上的提示-->
								<div id="map_notification_outer"><table><tr><td id="map_notification"></td></tr></table></div>
								<!--地图-->
								<div id="map_canvas" data-latitude="<?php echo $_SESSION['session_latitude'];?>" data-longitude="<?php echo $_SESSION['session_longitude'];?>"></div>
								<!--地图下方的缩放控件
								<div id="map_controls">
									<a id="map_zoom_out" href="javascript:void(0)"></a>
									<a id="map_zoom_in" href="javascript:void(0)"></a>
								</div>-->
								<div class="add_shadow" style="display:none"></div>
							</div><!--map_canvas_outer-->
						</div><!--map_outer-->
					</div><!--content-->
				</div><!--class="left"-->
			</div><!--inner_columns-->
		</div><!--columns wide-->
		
<?php include 'footer.php' ?>

