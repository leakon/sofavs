<?php
function  isbig5($code)
{
	if  (strlen($code)>=2)
	{
		$code=strtok($code,"");

		if  (ord($code[0])  <  161)
		{
			return  (0);
		}
		else
		{
			if  (((ord($code[1])  >=  64)&&(ord($code[1])  <=  126))  ||((ord($code[1])  >=  161)&&(ord($code[1])  <=  254)))
			{
				return  1;
			}else{
				return 0;
			}
		}
	}
	else
	{
		return  (0);
	}
}

function  big5offset($code)
{
	if  (strlen($code)  >=  2)
	{
		$code=strtok($code,"");
		if  ((ord($code[1])  >=  64)&&(ord($code[1])  <=  126))
		{
			return  ((ord($code[0])  -  161)  *  157  +  (ord($code[1])  -  64));
		}
		if  ((ord($code[1])  >=  161)&&(ord($code[1])  <=  254))
		{
			return  ((ord($code[0])  -  161)  *  157  +  63  +  (ord($code[1])  -  161));
		}
	}
	return  (-1);
}

function  wordtostring($code)
{
	return  (chr(hexdec(substr($code,0,2))).chr(hexdec(substr($code,2,2))));
}

function  big5togb($code)
{
	include  "data_big5.php";
	$output="";
	$length=strlen($code);
	$code=strtok($code,"");
	$idx=0;
	while  ($idx  <  $length)
	{
		$tmpStr=$code[$idx].$code[$idx+1];

		if  (isbig5($tmpStr))
		{
			$offset=big5offset($tmpStr);
			if  (($offset  >=  0) ||($offset  <=  14757))
			{
				$output.=wordtostring($big5order[$offset]);
				$idx++;
			}
			else
			{
				$output.=  $code[$idx];
			}
		}
		else
		{
			$output.=  $code[$idx];
		}
		$idx++;
	}
	return  ($output);
}

echo big5togb("鴨子毛");
?>