<?php
header("Content-Type:text/html;charset=UTF-8");
include_once 'inc/functions.php';

check_login();
if(empty($_POST['lipinIds'])){
	echo '<script type="text/javascript">'.
			'alert("您没有选择礼品");window.location.href="lipinlist.php"'.
			'</script>';
	return ;
}


//获取参数
$address=$_POST['address']; //收货地址
$phone=$_POST['telphone'];	//电话
$notice=$_POST['notice'];	//特殊要求
$customId=$_SESSION['session_customid'];//用户ID
$startTime=get_datetime();		//时间
//首先或的该礼品的ID
	//1==获得该用户的积分
	 
	$myScore=getMyScore();//我的积分
	$lipinIds=$_POST['lipinIds'];// 礼品的IDs
	$lipinNames=$_POST['lipinNames'];//礼品的名称数组
	$lipinScores=$_POST['lipinScores'];//礼品 积分数组
	$lipinCounts=$_POST['lipinCounts'];//礼品 数量数组
	$lipinTotalScore=$_POST['lipinTotalScore'];//礼品的总积分
	if ($myScore['score']<$lipinTotalScore){
		echo '<script type="text/javascript">'.
			'alert("您的积分不足");window.location.href="lipinlist.php"'.
			'</script>';
		return ;
	}
	
	//下面开始 进行数据库操作
	$db=dao();
	$db->autocommit(0);
	$flag=true;
	$names='';
	foreach ($lipinIds as $key=>$lid){//便利礼品的ID
		$name=$lipinNames[$key];//名称
		$score=$lipinScores[$key];
		$count=$lipinCounts[$key];
		if($key==0){
			$names.=$name;	
		}else{
			$names.='、'.$name;
		}
		
		$sql="select lipinCount as c from lipin where lipinId=".$lid;//查询改 数量
		$result=$db->query($sql);
		$tempCount=0;
		if($row=$result->fetch_assoc()){
			$tempCount=$row['c'];
		}
		if($tempCount<$count){//数量不足
			$flag=false;
			echo '<script type="text/javascript">'.
			'alert("礼品'.$name.'的数量已经不足，请重新选择!");window.location.href="lipinlist.php"'.
			'</script>';
			exit();
		}
		//首先插入 礼品兑换记录表中，
		
		$sql="insert into lipinexchangerecord (customId,lipinId,address,phone,notice,createTime,status) values ({$customId},{$lid},'{$address}','{$phone}','{$notice}','{$startTime}','等待发货')";

		$db->query($sql);
		if($db->affected_rows>0){
			//然后更新 礼品表中 礼品的数量，
			$sql2="update lipin set lipinCount=".($tempCount-$count)." where lipinId=".$lid;
		
			$db->query($sql2);
				if($db->affected_rows>0){
					
					
				}else{
					$flag=false;
				}
		}else{
			$flag=false;
		}
		if(!$flag){
			break;
		}
	}
	
	//然后更新用户的积分
	
	if($flag){
		$scoreCha=$myScore['score']-$lipinTotalScore;
		$sql="update customscore set score={$scoreCha} where customId=".$customId;
		$db->query($sql);
		if($db->affected_rows>0){
					//然后 更新用户的 消费积分记录
					date_default_timezone_set ( 'PRC' );
					$recordTime=time();
					$remark='DLLP'.$recordTime;//礼品兑换记录编号
					$costScore=0-$score*$count;//每个 礼品的积分 X 他的数量
					$sql="insert into scorerecord (createTime,customId,lipinId,score,memo,lipinexchangerecordNo) values('{$recordTime}',{$customId},0,{$costScore},'兑换了".$names."','{$remark}')";
					$db->query($sql);
					if($db->affected_rows>0){
							
					}else{
						$flag=false;
					}
	
		}else{
			$flag=false;
		}
	}
	if($flag){
		$db->commit();
			echo '<script type="text/javascript">'.
					'window.location.href="lipinconvertsucess.php?remark='.$remark.'&&names='.$names.'"'.
				'</script>';
			return ;
	}else{
		$db->rollback();
		echo '<script type="text/javascript">'.
					'alert("失败了，请重试！");window.location.href="lipinsubmitList.php"'.
					'</script>';
		return ;
	}
//	
//	
//	
//	
//		
//	//2==获得该礼品的积分
//	//3==//比较一下，如果该用户的积分足以支付那么就可以支付，不行的话跳转
//	if($myScore['score']>=$lipin['score']){
//		//4==//如果可以支付，更改 该礼品的数量，添加记录到 ，礼品的兑换记录表中，同时更改该用户的积分
//		$sql="insert into lipinexchangerecord (customId,lipinId,address,phone,notice,createTime,status) values ({$customId},{$lipinId},'{$address}','{$phone}','{$notice}','{$startTime}','等待发货')";
//		$sql2="update lipin set lipinCount={$lpCount} where lipinId=".$lipinId;
//		//算出剩余积分
//		$scoreCha=$myScore['score']-$lipin['score'];
//		$sql3="update customscore set score={$scoreCha} where customId=".$customId;
//		$sql4=getInserToScoreRecordSql(0-$lipin['score'],' 兑换了'.$lipin['name'],$lipinId);
//		//封装成集合
//		$sqls=array($sql,$sql2,$sql3,$sql4);
//		$flag=dao_execute_tr($sqls);
//		if($flag){//执行成功
//			//5==//成功跳转到提示成功，并转到礼品兑换记录表中，
//			echo '<script type="text/javascript">'.
//					'alert("兑换成功！");window.location.href="lipinConvertRecord.php"'.
//					'</script>';
//			return ;
//		}else{
//			//6==//失败提示失败原因
//			echo '<script type="text/javascript">'.
//				//	'alert("失败了，请重试！");window.location.href="lipinsubmitList.php?id='.$lipinId.'"'.
//					'</script>';
//			return ;
//		}
//	}
//	
	//6==//失败提示失败原因
	//7==
?>