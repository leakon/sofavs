<?php
include_once 'inc/functions.php';
?>


<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8">




<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link href="css/restanrantinfo.css" type="text/css" rel="stylesheet">
<link href="css/restanrantinfo.base.css" type="text/css" rel="stylesheet">

<style type="text/css">
bory{
	font-family:'Microsoft YaHei' ! important;
}

</style>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ordersubmitout.js"></script>
<script type="text/javascript" src="js/jquery.noty.js"></script>
<!-- layouts -->
<script type="text/javascript" src="js/center.js"></script>
<!-- themes -->
<script type="text/javascript" src="js/default.js"></script>
	<script type="text/javascript" src="js/commonTip.js"></script>
	<script type="text/javascript" src="js/index.js"></script>
</head>
<body style="width:1400px;height:766px;background:url('images/index_bg.png')">
<iframe src="lipinlist.php" style="width:1400px;height:766px;"></iframe>
		<div class="modal-backdrop fade in" id="zhezhao" style="display:block;"></div>
		<div id="search_mapshow_" class="modal" style="width:600px;height:auto;display:block;padding-bottom:15px;margin-left:-300px;font-family:微软雅黑;">
			<div><a href="javascript:;" style="float:right;margin-top:5px;margin-right:5px;display:block;width:10px;height:10px;font-size:16px;" id="the_close">X</a></div>
			<div style="height:60px;"></div>
			<div style="height:auto;font-family:微软雅黑;font-size:16px;">
				<div style="margin:0 auto;width:528px;">尊敬的用户<?php echo $_SESSION['session_customUsername'];?>你好,<br><br>&nbsp;&nbsp;&nbsp;您已成功兑换<?php echo $_GET['names'];?>,你的积分兑换单号是<span style="color:red;"><?php echo $_GET['remark'];?></span>,<br><br>我们将尽快为您发货，感谢您对<?php echo $_SESSION['session_Setting_SITE_NAME'];?>的支持!</div>
			</div>
			<div style="width:570px;height:30px;"><a class="btn btn-success" href="lipinlist.php" style="float:right;">确 定</a></div>
		</div>
<script type="text/javascript">
$(function(){
	$('#the_close').click(function(){
//		$('#search_mapshow_').slideUp();
//		$('#zhezhao').hide();
		window.location.href="lipinlist.php";
	});
});
</script>

</body>
</html>