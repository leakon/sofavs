<?php
require_once("inc/functions.php");

orders_cancel();
header('Location: orders_myactive.php');
?>
