<?php
require_once 'inc/functions.php';
if( !isset($_SESSION['session_customid']) ){
	header("Location: login.php");
	exit;
}

//先下单
if(!orders_drop()){
	header("Location: orders_create.php");
	exit;
}

//再看是否需要验证手机号码
if(empty($_SESSION['session_customMobileVerified'])) {
	header("Location: orders_verifymobile.php");
	exit;
}

header('Location: orders_myactive.php');
?>