<?php
require_once 'inc/functions.php';
include 'header_min.php';
?>
<link rel="stylesheet" type="text/css" media="screen" href="css/common.tab_nav.css"/>
<link rel="stylesheet" type="text/css" media="screen" href="css/support.index.css"/>
<style>
	#support_email_outer {
		margin:5px 0;
		line-height:20px;
		vertical-align:middle;
	}
	#support_email_outer input{
		width:404px;
		height:18px;
		border:1px solid #DDD;
	}
	#support_content_outer label {
		margin-bottom:3px;
	}
	label {
		float:left;
	}
</style>
<script type="text/javascript">
document.title = "<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> / 联系<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>";
</script>

<div class="columns">
<div class="inner_columns">
	<div class="left">
		<div id="content">
			<div id="support_board" class="support_board">
				<form class="support_form" action="newsupportmessage.php" method="post">
					<div>
						<div id="support_content_outer">
							<label for="support_content"><?php echo $_SESSION['session_Setting_SITE_NAME']; ?>答疑：</label>
							<textarea id="support_content" class="text content" name="content"></textarea>
						</div>
						<div id="support_email_outer">
							<label for="support_email">Email：</label>
							<input class="text" name="email" id="support_email"/>
						</div>
					</div>
					<div class="submit_support_message">
						<input type="submit" value="提交" class="btn submit" />
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="right">
		<div id="side">
			<div class="section">
				<div class="section-header">
					<h3 class="faq-header">
						答疑
					</h3>
				</div>
				<p>
					您可以在这里留下您的Email和您的疑问，客服人员会尽快回复您。
				</p><br/>
			</div>
		</div>
	</div>
</div>
</div>

<?php include 'footer.php' ?>
