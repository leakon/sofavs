<?php
require_once 'inc/functions.php';
orders_delete();
header("Location: orders_create.php");
?>
