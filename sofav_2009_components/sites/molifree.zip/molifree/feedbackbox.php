<?php
require_once("inc/functions.php");
$messages = get_messages();
?>
<script src="js/common.feedback_box.js" type="text/javascript" charset="utf-8"></script>
<div class="sidebar_menu">
	<div class="leihou-ask-answer-form">
		<form class="support_form leihou-post-form" action="newsupportmessage.php" method="post">
			<div class="leihou-post-content">
				<textarea id="ask_answer_content" class="text content leihou-status-box" name="content"></textarea>
			</div>
			<?php if(!isset($_SESSION['session_customid'])) { ?>
			<div id="email_input">
				<div>
					<label for="ask_answer_email">您的Email：</label>
				</div>
				<div class="ask_answer_email">
					<input id="ask_answer_email" class="text content leihou-status-box" name="email" type="text">
				</div>
			</div>
			<?php } ?>
			<div class="leihou-post-controls">
				<input style="height:22px" value="好了，提交" class="btn" type="submit">
			</div>
		</form>
	</div>
	<ul class="leihou-ask-answer-timeline">
		<?php foreach($messages as $message) { ?>
		<li class="leihou-dialog">
			<div class="main_msg leihou-message leihou-asker">
				<div class="content"><span class="leihou-author"><?php echo $message['Name']; ?></span>&nbsp;<?php echo $message['Question']; ?></div>
			</div>
			<div class="reply_msgs leihou-message leihou-answerer">
				<div class="content"><span class="leihou-author"><?php echo $_SESSION['session_Setting_SITE_NAME']; ?>答疑</span>&nbsp;<?php echo $message['Answer']; ?></div>
			</div>
		</li>
		<?php } ?>
	</ul>
	<div class="leihou-page-controls">
		<a class="more-button" href="getmoresupportmessage.php?limit=10&from=10" rel="nofollow">下10条</a>
	</div>
</div>