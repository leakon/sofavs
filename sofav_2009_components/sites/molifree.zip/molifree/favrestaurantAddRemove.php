<?php
include_once 'inc/config.php';
include_once 'inc/functions.php';
$method=$_POST['m'];
$customId=empty($_SESSION['session_customid'])?-1:$_SESSION['session_customid'];
$guestId=empty($_COOKIE['guestid'])?"":$_COOKIE['guestid'];
if($method=='add'){
	$sql="insert into favrestaurant (CustomID,GuestID,RestaurantID) values($customId,'$guestId','".$_POST['rid']."')";	
	$db=dao();
	$db->query($sql);
	if($db->affected_rows>0){
		echo 'success';
	} else{
		echo 'filed';
	}
}elseif($method=="remove"){
	$sql="delete from favrestaurant where CustomID=$customId or  GuestID='$guestId' and RestaurantID='".$_POST[rid]."'";
	$db=dao();
	$db->query($sql);
	if($db->affected_rows>0){
		echo 'success';
	} else{
		echo 'filed';
	}
}
?>