<?php
include_once 'inc/functions.php';

$pageNo=1;
$pageSize=10;
$linpinList=lipinList($pageNo-1,$pageSize);
$lipinCount=getLipinCount();
$totalPageNo=$lipinCount%$pageSize==0?$lipinCount/$pageSize:(int)($lipinCount/$pageSize)+1;//总页数

$isLogin=true;//是不是登录了
$myScore=null;//我的积分
if(empty($_SESSION['session_customid'])){
	$isLogin=false;
}else{
	$myScore=getMyScore();
}
$tips=getLipinTip();
$theCitys=get_cities();
?>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
	<meta content="zh" http-equiv="Content-Language"/>
	<meta content="no" http-equiv="imagetoolbar"/>
	<meta content="width=990" name="viewport"/>
	<meta http-equiv="X-UA-Compatible" content="chrome=1" />
	<meta name="robots" content="index,follow"/>
	<link rel="shortcut icon" href="favicon.ico"> 
	<title><?php echo $_SESSION['session_Setting_SITE_NAME']; ?> - 附近的外卖详细菜单</title>
	
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.footer.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.header.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.body.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/notifications.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/common.collapsible.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/common.billboard.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/hero_restaurant.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/restaurant_list.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/restaurant_list.dishes.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/hero_dishes.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/cart.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/application.index.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/application.index.toc.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/application.index.welcome.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/ask_answer.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/meican400hint.css"/>
	<style type="text/css">
		html {
			background: <?php echo empty($_SESSION['session_Setting_BG_COLOR']) ? "#F3F3F3" : $_SESSION['session_Setting_BG_COLOR']; ?>;
			<?php if (!empty($_SESSION['session_Setting_BG_IMAGE'])) { ?>
				background-image: url(<?php echo $_SESSION['session_Setting_BG_IMAGE']; ?>);
			<?php }?>
		}
		body {
			background: <?php echo empty($_SESSION['session_Setting_BG_COLOR']) ? "#F3F3F3" : $_SESSION['session_Setting_BG_COLOR']; ?>;
			<?php if (!empty($_SESSION['session_Setting_BG_IMAGE'])) { ?>
				background-image: url(<?php echo $_SESSION['session_Setting_BG_IMAGE']; ?>);
			<?php }?>
		}

		#site_stats strong {
			font-size:16px;		
			line-height:42px;
		}
		.columns .right {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		.columns .right a:hover {
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ievil .columns {
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ievil .columns .right {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ievil .columns .right a:hover {
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		
		#side .cart li.dish .name {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		    background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .name {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		    background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .price {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .cart_count {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		#side .cart li.dish .delete {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .delete:hover{
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		body.ie6 #side .cart li.dish .delete {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ie6 #side .cart li.dish .delete:hover {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		#cart_fix_hint {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#cart_outer.fixed {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#sidebar_search #profile_section.fixed {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		#side .cart li.restaurant .meta {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#DBEFF8" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		}
		.leihou-author {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		}
		.leihou-ask-answer-timeline {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#C3E3F3" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		}

		.flash_notification.error {
			background:<?php echo empty($_SESSION['session_Setting_ERROR_BG_COLOR']) ? "#F23030" : $_SESSION['session_Setting_ERROR_BG_COLOR']; ?>;
			color:<?php echo empty($_SESSION['session_Setting_ERROR_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_ERROR_TEXT_COLOR']; ?>;
		}
		.flash_notification.info {
			background:<?php echo empty($_SESSION['session_Setting_INFO_BG_COLOR']) ? "#FC9C0F" : $_SESSION['session_Setting_INFO_BG_COLOR']; ?>;
			color:<?php echo empty($_SESSION['session_Setting_INFO_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_INFO_TEXT_COLOR']; ?>;
		}
		.flash_notification.success {
			background:<?php echo empty($_SESSION['session_Setting_SUCCESS_BG_COLOR']) ? "#7ED10E" : $_SESSION['session_Setting_SUCCESS_BG_COLOR']; ?>;
			color:<?php echo empty($_SESSION['session_Setting_SUCCESS_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_SUCCESS_TEXT_COLOR']; ?>;
		}
				
	</style>
	<script src="js/remove_unicom.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.z.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/header_menu.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/lib.json2.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/settings.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/notifications.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/counter.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.cookie.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.isCollapsibleMenu.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.scrollto-min.js" type="text/javascript" charset="utf-8"></script>
	
	<script src="js/fav_restaurants.add_delete.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/hero_restaurant.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/application.index.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/application.index.slide.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/application.index.search.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.simplemodal.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/meican400hint.js" type="text/javascript" charset="utf-8"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8">
<title>订乐网</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link href="css/restanrantinfo.css" type="text/css" rel="stylesheet">
<link href="css/restanrantinfo.base.css" type="text/css"
	rel="stylesheet">
	
<script type="text/javascript" src="js/lipinlist.js" >
	
</script>

<style type="text/css">
.nodec {
	text-decoration: none;
}

.nodec:hover {
	text-decoration: none;
}
</style>
</head>
<body>
<div id="bookmark_top"><a href="#" name="top" rel="nofollow">&nbsp;</a></div>
	<div id="prototypes" style="display:none"></div>
	
	<div id="container" class="<?php echo get_client_browser_type(); ?>" >
		<div id="header-outer">
			<div id="header">
				<h3 class="offscreen">页首</h3>
				<h1>
					<a href="index.php" id="logo">
						<img src="<?php echo empty($_SESSION['session_Setting_LOGO_IMAGE']) ? "images/logo.png" : $_SESSION['session_Setting_LOGO_IMAGE'];?>" alt="<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> - 附近的外卖详细菜单"/>
					</a>
				</h1>
				
				<?php include 'city_header.php'; ?>
								
				<?php include 'top_nav.php'; ?>
				
				<div class="bookmark"></div>
			</div>
		</div>
	</div>
<center>
<div class="zong">

<div class="zhong" style="margin-top: 20px;">



<div class="cell bgfb bdc">
<div id="awardtype_20"
	class="res_gray_grad2 res_grad_bar giftGradBar fix" name="20">
<h4 class="cdred f14 l">积分兑换</h4>
<div style="float:right"><?php
// 这里是右上角处，是否显示登录主粗，还是显示欢迎：
if (empty ( $_SESSION ['session_customid'] )) { // 如果session没有用户登录信息，那么就显示登录注册
	?>
<div><a href="login.php">登录</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="register.php">注册</a></div>
	<?php
} else {
	?>
<div style="margin-right: 10px; font-family: SimSun；"><a
	href="javascript:void(0);" style="text-align: right;"></a> <a
	style="color: #018511;" href="javascript:void(0);"><?php 
	echo $_SESSION['session_customUsername']?></a><span
	style="font-family: SimSun；">|</span> 积分：<a href="javascript:void(0)" style="color:red;text-decoration:none;"><?php  echo !$isLogin?'未登录':''.$myScore['score'];?></a> <span style="font-family: SimSun；">|</span>
</div>

	<?php
}
?></div>
</div>

<div class="tj fs p20 bbc btc" style="padding-bottom: 0px;"><!--									<div class="yellow_bar p5 mb10 b">您还没有登录</div>-->
	<div id="list_data">
	<?php foreach ($linpinList as $k=>$v){
	?>
	<span class="res_gift_album inline_any tc mb15"
		style="margin-bottom: 5px; margin-top: 5px;"> <a
		href="javascript:void(0);" class="resGiftInfo" title="<?php echo $v['description'];?>"><img
		src="<?php echo $v['imgPath'];?>"
		class="bdc db p10 jsLazyImage" style="width: 150px; height: 140px;"></a>
	<strong class="ell mt10 mb10 db pct98"><span
		class="resGiftInfo cdred f14 nodec" style="color: green;"><?php echo $v['name'];?></span></strong>
	
	<span class="mt2 db">积分：<strong class="co fa"><?php echo $v['score'];?></strong></span> <span
		class="mt10 db abs_in"> 
	 <a
		class="btn btn-success btn_duihuan"
		style="padding: 0px; width: 70px; height: 20px; background: #2da200;"
		href="javascript:void(0)" onclick="exchangePresent()"   data-id="<?php echo $v['lipinId'];?>" data-name="<?php echo $v['name'];?>" data-score="<?php echo $v['score'];?>" data-count="<?php echo $v['lipinCount'];?>"> 立即兑换 </a> </span> </span> 
	<?php }
	?>
	
	<span
		class="res_gift_album inline_any" style="height:1px;margin:0px;">&nbsp;</span> 
	<span
		class="res_gift_album inline_any" style="height:1px;margin:0px;">&nbsp;</span> 
	<span
		class="res_gift_album inline_any" style="height:1px;margin:0px;">&nbsp;</span> 
	<span
		class="res_gift_album inline_any" style="height:1px;margin:0px;">&nbsp;</span> 

	</div>
</div>

<div class="btn-group"
	style="margin-top: 10px; *margin-top: 8px; *margin-bottom: 8px; font-family: 微软雅黑; margin-left: 200px;">
<a class="btn pull-left"
	style="padding: 0px; width: 55px; height: 20px;" href="javascript:;"
	id="shangye"> <span class="btn-label" style="font-size: 12px;">上一页</span>
</a> <a class="btn pull-left" href="javascript:;" id="xiaye"
	style="margin-left: 10px; margin-right: 10px; padding: 0px; width: 55px; height: 20px;">
<span class="btn-label" style="font-size: 12px;">下一页</span> </a> <span
	class="pull-left" style="font-size: 12px; margin-top: 2px"> 您正在浏览第<a
	href="javascript:void(0);" id="the_page_no"><?php echo $pageNo;?></a>页，共<a
	id="the_total_count" href="javascript:void(0);"><?php echo $totalPageNo;?></a>页 <!--														<a href="javascript:void(0);" id="the_page_no">1</a>/<a id="the_total_count" href="javascript:void(0);"></a><span style="font-size:12px;">页</span>-->
</span> <input type="text" class="input-mini pull-left"
	style="margin-left: 10px; margin-right: 5px; height:22px;width:60px;"
	id="thePageNo"> 

	<span id="go" class="btn btn-label  pull-right"
	style="font-size: 12px; padding: 0px; width: 45px; height: 20px;">转到</span>
	<input type="hidden" name="pageNo" id="pageNo" value="<?php echo $pageNo;?>"/>
	<input type="hidden" name="pageSize" id="pageSize" value="<?php echo $pageSize?>"/>
	<input type="hidden" name="zongshu" id="zongshu" value="<?php echo $lipinCount;?>"/>
	<input type="hidden" name="zongshu" id="myjifen" value="<?php echo empty($_SESSION['session_customid'])?'0':  $myScore['score'];?>"/>
</div>
</div>
<?php include 'footer.php' ?>
</div>
</div>
</center>
</body>
</html>
