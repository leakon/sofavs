<?php
require_once 'inc/functions.php';
?>
		<!-- footer-outer START -->
		<div id="footer-outer">
			<div id="footer" class="round">
				<h3 class="offscreen">页尾</h3> <div id="copyright"><span>&copy;&nbsp;2013 <?php echo $_SESSION['session_Setting_SITE_NAME']; ?></span></div>
				<ul>
					<li><a href="help.php">用户帮助</a></li>
					<li><a href="contact.php">联系<?php echo $_SESSION['session_Setting_SITE_NAME']; ?></a></li>
					<li><a href="corps/about.php">企业订餐</a></li>
					<li><a href="about_us.php">关于我们</a></li><br /><br />
                    
                  
				</ul>
			</div>
		</div>
		<!-- footer-outer END -->
	</div>
	<!-- container END -->
	
	<div id="map_scripts" data-src=""></div>
</body>
</html>
