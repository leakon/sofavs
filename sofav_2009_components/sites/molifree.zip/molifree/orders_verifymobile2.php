<?php
require_once 'inc/functions.php';
if( !isset($_SESSION['customid']) ){
	header("Location: login.php");
	exit;
}

if(verify_mobile()){
	header("Location: orders_myactive.php");
	exit;
}
include 'header_account.php';
?>
<link rel="stylesheet" type="text/css" media="screen" href="css/order.css"/>
<link rel="stylesheet" type="text/css" media="screen" href="css/common.steps_nav.css"/>	
<link rel="stylesheet" type="text/css" media="screen" href="css/order.verify_mobile.css"/>
<script type="text/javascript">
document.title = "美餐网 / 创建订单";
</script>
<div class="columns">
<div class="inner_columns">
<div class="left">
	<div id="content">
		<div id="order_steps_nav" class="steps_nav">
			<ol class="nav">
				<li class="step_1 previous"><a href="orders_create.php"><span></span>创建订单</a></li>
				<li class="step_2 current"><i></i><a href="custom_mobile.php"><span></span>验证手机</a></li>
				<li class="arrow next"><i></i><span></span>完成</li>
			</ol>
		</div>
		<form id="verify_mobile" action="orders_verifymobile.php" method="post">
			<table>
				<tr>
					<th>
						我的手机号：
					</th>
					<td>
						<?php echo $_SESSION['customMobile']?>
					</td>
				</tr>
				<tr>
					<th>
						<label for="mobile_number">手机验证码：</label>
					</th>
					<td>
						<input type="text" name="activationCode" class="text" id="activation_code" value="" />
						<br/>
						<p id="confirmation_tips" class="form_hint">美餐网发了一条短信给你，请把短信里的验证码填在上面。</p>
					</td>
				</tr>
				<tr>
					<th></th>
					<td>
						<div id="activate_submit">
							<input class="btn" type="submit" value="完成验证" />
						</div>
						<div id="resend_activationcode">
							<input class="btn" type="button" onclick="window.location.href='resend_sms_code.php?from=orders'" value="重发验证码" />
						</div>
					</td>
				</tr>
			</table>
		</form>
	</div>
</div>
<div class="right">
	<div id="side">
	</div>
</div>
</div>
</div>
<?php include 'footer.php' ?>