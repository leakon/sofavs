<?php
	if($_POST[m]=='addtosession'){
		$data=array();
		$data[cityId]=$_POST['cityId'];
		$data[cityName]=$_POST['cityName'];
		$data[regionId]=$_POST['regionId'];
		$data[regionName]=$_POST['regionName'];
		if(empty($_SESSION['lastview'])){
			$_SESSION['lastview']=array($data);
		}else{
			$rs=$_SESSION['lastview'];
			array_push($rs,$data);
			$_SESSION['lastview']=$rs;
		}
		echo 'ok';
	}else if($_POST[m]=="clearAll"){
		unset($_SESSION['lastview']);
		echo 'yes';
	}
?>