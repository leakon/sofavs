<?php
require_once 'inc/functions.php';
$updated = custom_mobile_update();
include 'header_account.php';
?>
<style type="text/css">
#confirmation_tips {
	font-size:12px;
}
#confirmation_tips strong {
	color:#f30;
	font-weight:normal;
}
#confirmed_tips {
	color:#0a6;
	font-size:12px;
}
</style>

<script type="text/javascript">
document.title = "<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> / 手机号码";
</script>
<div class="columns">
<div class="inner_columns">
<div class="left">
	<div id="content">
		<div id="settings_nav" class="tab_nav">
			<ul>
				<li>
					<a href="custom_account.php">帐号密码</a>
				</li>
				<li class="current">
					<a href="custom_mobile.php">手机号码</a>
				</li>
				<li>
					<a href="custom_addresses.php">常用地址</a>
				</li>
				<li>
					<a href="custom_support.php">我的答疑</a>
				</li>
				<li>
					<a href="custom_orders_list.php">订单历史</a>
				</li>
				<?php if(!empty($_SESSION['session_hasActiveOrder'])) { ?>
				<li>
					<a href="orders_myactive.php">当前订单</a>
				</li>
				<?php } ?>
			</ul>
		</div>
		<?php if(empty($_SESSION['session_customMobileVerified']) && empty($_SESSION['session_customMobileVerifying'])) { ?>
		<form action="custom_mobile.php" method="post" class="account_form">
			<table class="mobile_setting_table">
				<tr>
					<th>
						<label for="mobile_number">你的手机号码</label>
					</th>
					<td>
						<input type="text" class="text" name="mobile_number" id="mobile_number" value="<?php echo $_SESSION['session_customMobile']; ?>" />
						<div class="hint">示例：13800138000</div>
					</td>
				</tr>
				<tr>
					<th></th>
					<td>
						<input class="btn" type="submit" value="发送验证码" />
					</td>
				</tr>
			</table>
			<input type="hidden" value="true" name="fromsetting"/>
		</form>
		<?php } else { ?>
		<form action="custom_activatemobile.php" method="post" class="account_form">
			<table class="mobile_setting_table">
				<tr>
					<th>
						<label for="mobile_number">你的手机号码</label>
					</th>
					<td>
						<input disabled="disabled" type="text" class="text disabled" name="mobile_number" id="mobile_number" value="<?php echo $_SESSION['session_customMobile']; ?>" />
						<a href="custom_mobile.php?reset=true">重设手机号</a>
					</td>
				</tr>
				<?php if(!empty($_SESSION['session_customMobileVerifying'])) { ?>
				<tr>
					<th>
						<label for="activationCode">你收到的验证码</label>
					</th>
					<td>	
						<input type="text" class="text" name="activationCode" value="" />
						<div class="hint">等了5分钟还没收到验证码？<a href="resend_sms_code.php">重发验证码</a></div>
					</td>
				</tr>
				<tr>
					<th></th>
					<td>
						<input type="submit" value="完成验证" class="btn" />
					</td>
				</tr>
				<?php } ?>
			</table>
		</form>
		<?php } ?>
	</div>
</div>
<div class="right">
	<div id="side">
		<div class="section">
			<div class="section-header">
				<h3 class="faq-header">手机号码确认</h3>
			</div>
			<p>
				从网站订餐前，您需要设置手机号码，这是为了餐厅送餐人员与你取得联系。
			</p><br/>
		</div>
	</div>
</div>
</div>
</div>
<?php include 'footer.php'; ?>