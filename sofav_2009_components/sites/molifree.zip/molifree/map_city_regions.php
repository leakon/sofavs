<?php
/**
 * 本文件获取城市列表以及区域列表（用于地图上点击城市选择之后的弹出窗口）
 */
require_once("inc/functions.php");
$cities = get_cities();
$regions = get_regions();
$first = true;
?>
<div id="area_list_prototype" style="display:none;">
	<div class="popover area_list">
		<div class="popover_header">
			<span class="popover_header_title has_current_city">
			<?php echo $_SESSION['session_city'] ?>
			</span>
			<a href="javascript:void(0)" class="popover_back_button has_current_city"></a>
		</div><!--popover_header-->
		<div class="popover_body_outer">
			<div class="popover_body show_col2" style="height:10px;">
				<ul class="col1 col">
					<?php foreach($cities as $city1) { ?>
					<li class="<?php if($city1['ID']==$_SESSION['session_cityid']) echo 'current_city '; ?> <?php if($first){echo 'first '; $first=false; } ?> <?php echo 'city_'.$city1['ID'];?>" data-url="<?php echo 'city_'.$city1['ID'];?>">
						<a href="<?php echo merge_request_uri( array( "changecity" => $city1['ID'] ) ); ?>" data-url="<?php echo 'city_'.$city1['ID'];?>" data-latitude="<?php echo $city1['Latitude'];?>" data-longitude="<?php echo $city1['Longitude'];?>"><?php echo $city1['Name']?></a>
					</li>
					<?php } ?>
				</ul><!--col1 col-->
				
				<?php foreach($regions as $cityid1 => $city_regions) { $first_region=true; ?>
				<div class="col2_outer <?php echo 'city_'.$cityid1;?> <?php if($cityid1==$_SESSION['session_cityid']) echo ' current_city_col2';?> ">
					<ul class="col2 col" data-city="<?php echo 'city_'.$cityid1;?>">
					<?php foreach($city_regions as $region) { ?>
						<li class="<?php if($first_region) {echo 'first'; $first_region= false; }?>">
							<a href="javascript:void(0)" data-latitude="<?php echo $region['Latitude'];?>" data-longitude="<?php echo $region['Longitude'];?>"><?php echo $region['Name'];?></a>
						</li>
					<?php } ?>
					</ul>
				</div>
				<?php } ?>
			</div>
		</div><!--popover_body_outer-->
	</div><!--popover area_list"-->
</div><!--end of area_list_prototype-->