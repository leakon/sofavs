<?php
require_once("inc/functions.php");
$re = get_restaurant();
$restaurant = $re['restaurant'];
$added = $re['added'];
$dishes = $re['dishes'];
?>
{"ret":1,"id":<?php echo $restaurant['ID'];?>,"uuid":"<?php echo $restaurant['UUID'];?>","rating":<?php echo $restaurant['Rating'];?>,"deliveryRangeMeter":<?php echo $restaurant['Scope'];?>,"latLng":[<?php echo $restaurant['Latitude'];?>,<?php echo $restaurant['Longitude'];?>]}

<!--JH-->
<div class="sneak_basic">
	<div class="meta<?php echo ($added ? ' added added_'.$restaurant['ID'] : ''); ?>">
	<h4><a href="restaurant.php?uuid=<?php echo $restaurant['UUID'];?>" target="_blank"><?php echo $restaurant['Name'];?></a></h4>
	<div class="actions">
		<a href="favrestaurants_add.php?id=<?php echo $restaurant['ID'];?>" id="add_id_<?php echo $restaurant['ID'];?>" class="fav-add">加到首页</a>
		<a href="favrestaurants_remove.php?id=<?php echo $restaurant['ID'];?>" id="rm_id_<?php echo $restaurant['ID'];?>" class="fav-remove">移出首页</a>
		<span class="fav-info-added">已经加到首页</span>
	</div>
</div>
<div class="restaurant_rate rate<?php echo $restaurant['Rating'];?>" title="餐馆评级：<?php echo $restaurant['Rating'];?>"></div>
	<div id="restaurant_basic_info">
		<table class="restaurant_info_all">
			<tr class="restaurant_info_item<?php echo (isset($restaurant['BusinessHour']) ? ' unknown' : '' );?>">
				<th>外卖时间</th>
				<td><?php echo (isset($restaurant['BusinessHour']) ? $restaurant['BusinessHour'] : '-' );?></td>
			</tr>
			<tr class="restaurant_info_item<?php echo (isset($restaurant['Fee']) ? ' unknown' : '' );?>">
				<th>送餐费用</th>
				<td><?php echo (isset($restaurant['Fee']) ? ($restaurant['Fee']+0) : '-' );?></td>
			</tr>
			<tr class="restaurant_info_item<?php echo (isset($restaurant['MinMoney']) ? ' unknown' : '' );?>">
				<th>起送金额</th>
				<td><?php echo (isset($restaurant['MinMoney']) ? ($restaurant['MinMoney']+0) : '-' );?></td>
			</tr>
			<tr class="restaurant_info_item">
				<th>送餐范围</th>
				<td>正常周边(<?php echo (isset($restaurant['Scope']) ? $restaurant['Scope'] : '500' );?>米)</td>
			</tr>
			<?php if(isset($restaurant['Notice'])) { ?>
			<tr class="restaurant_info_item">
				<th>餐馆公告</th>
				<td><?php echo $restaurant['Notice'];?></td>
			</tr>
			<?php } ?>
		</table>
	</div>
</div>
<div class="sneak_menu">
	<ul class="restaurant_sneak_<?php echo $restaurant['ID'];?>">
		<?php
		$current_section = '';
		foreach($dishes as $dish) {
			 if($dish['Section']!=$current_section) {
			 	$current_section = $dish['Section'];
		?>
			<li class="dish is-section">
				<span class="name"><?php echo $dish['Section']; ?></span>
			</li>
		<?php } ?>
			<li class="dish">
				<span class="name"><?php echo $dish['Name']; ?><?php echo $dish['Annotation']; ?></span>
		 		- <span class="price"><?php echo ($dish['Price']+0); ?></span>
			</li>
		<?php } ?>
	</ul>
</div>