<?php
require_once 'inc/functions.php';
include 'header.php';
//dump($_SESSION);
$total = get_total_count();
?>
<?php if( $_SESSION['session_welcomehint']!='0' ){ ?>
		<div id="welcome" class="box billboard dismiss_hint">
			<div class="inner">
				<div id="site_stats"><strong>常订外卖？看看<span><?php echo $total["restaurantTotal"];?></span>家餐厅的<span><?php echo $total["dishTotal"];?></span>道外卖美食。</strong></div>
				<div id="intro">
					<img id="welcome_intro" src="<?php echo empty($_SESSION['session_Setting_HOME_WELCOME_IMAGE']) ? "images/welcome_intro.png" : $_SESSION['session_Setting_HOME_WELCOME_IMAGE'];?>" alt="打开外卖地图，定制你最喜爱的餐厅在首页；每天打开网站就可以查看它们的外卖菜单；直接在线订餐等候外卖自动上门。"/>
					<a class="start_btn" title="去外卖地图查看" href="map.php"></a>
					<a class="dismiss_button" href="settings.php?welcomehint=close" rel="nofollow">x</a>
				</div>
			</div>
		</div>
<?php } ?>		
		<div id="notifications">
		<?php echo last_notification(); ?>
		</div>
		
		<!-- columns START -->
		<script type="text/javascript" src="js/index.js"></script>
		<div class="columns">
			<!-- inner_columns START -->
			<div class="inner_columns">
			
				<!-- left START -->
				<div class="left">
					<!-- left  content START -->
					<div id="content">
					
						<!-- hero_outer 即左侧顶部广告图 -->
						<div id="hero_outer">
						<?php 
						$first = true;
						for ($i = 1; $i <= 6; $i++) {
							if(empty($_SESSION['session_Setting_HOME_HELLO_IMAGE'.$i])) continue; 
						?>
							<div id="hero<?php echo $i;?>" class="hero hero_show" style="opacity: <?php echo $first? 1:0 ?>;background-image:url('<?php echo $_SESSION['session_Setting_HOME_HELLO_IMAGE'.$i];?>')"></div>
						<?php
							$first = false;
						}
						?>
						</div>
						
						<!-- 左侧提示 -->
						<div id="toc_hint">
							<div>
							<?php 
							echo empty($_SESSION['session_Setting_HOME_LEFT_HINT']) 
							? "小提示：以下餐厅仅为示例，可能无法为您提供外卖，您可以删除它们，定制您附近的外卖餐厅。" 
							: $_SESSION['session_Setting_HOME_LEFT_HINT'];
							?>
							</div>
						</div>
						
						<!-- 定制的餐厅  START-->
						<?php get_faver_restaurants(); ?>
						<!-- 定制的餐厅 END-->
						<div class="clear"></div>
					</div>
					<!-- left  content END -->
				</div>
				<!-- left END -->
				
				<!-- right START -->
				<div class="right">
					<!-- side START -->
					<div id="side">
						
						<!--外卖搜索form-->
						<form action="javascript:void(0)" method="get" id="sidebar_search">
						<div id="profile_section">
							<input type="text" placeholder="<?php echo empty($_SESSION['session_customUsername']) ? '': $_SESSION['session_customUsername']."，"; ?>今天想吃什么外卖？" id="sidebar_search_box" name="q" autocomplete="off" tabindex="1" /><a id="sidebar_search_box_clear" class="search_box_clear" style="visibility:hidden"></a>
						</div>
						</form>
						
						<!-- 虚线 -->
						<a name="cart" class="bm">&nbsp;</a>
						
						<!--订单-->
						<!--	cart_inflater START -->
						<div id="cart_inflater">
							<!--	cart_outer START -->
							<div id="cart_outer" class="noncollapsible empty denied<?php echo empty($_SESSION['session_hasActiveOrder']) ? " noorder": "";?>">
								<h2 class="sidebar_title">
									<span>在线订餐</span>
								</h2>
								
								<!--订单项-->
								<ul class="cart" id="cart_unique"><li></li></ul>
								<div id="cart_empty_hint">
									<?php 
									echo empty($_SESSION['session_Setting_HOME_CART_HINT']) 
									? "(点击左侧的餐品，然后这里下单，外卖自动上门啦)" 
									: $_SESSION['session_Setting_HOME_CART_HINT'];
									?>
								</div>
								
								<!-- 订单操作按钮 -->
								<div id="order_controls">
									<a id="cart_clear" class="btn" href="javascript:void(0)" rel="nofollow">清空</a>
									<a id="cart_submit" class="btn" href="orders_create.php" rel="nofollow">送餐上门</a>
									<a id="in_submit" class="btn" href="orders_in.php" rel="nofollow">到店消费</a>
									<a id="cart_view" class="btn" href="orders_myactive.php" rel="nofollow">查看订单</a>
								</div>
								
								<div style="display:none" id="cart_json"><?php echo get_cart_json() ?></div>
								
							</div>
							<!--	cart_outer END -->
							
							
							<!--	cart_fix_hint START 用于浮动？-->
							<div id="cart_fix_hint" style="display:none;">
								<a href="#cart" rel="nofollow">&uarr; 查看您的点餐单</a>
							</div>
							<!--	cart_fix_hint END -->
							
						</div>
						<!--	cart_inflater END -->

						<!--一个提示-->
						<!--	cart_encourage START -->
						<div class="cart_encourage">
							<h3>
							<?php 
							echo empty($_SESSION['session_Setting_HOME_ENCOURAGE_TITLE']) 
							? "还是不太敢在线订餐？" 
							: $_SESSION['session_Setting_HOME_ENCOURAGE_TITLE'];
							?>
							</h3>
							<p>
							<?php 
							echo empty($_SESSION['session_Setting_HOME_ENCOURAGE']) 
							? "别担心，你的订单会立刻得到处理，外卖进度还会实时反馈给你。很多人已经用上瘾了，你也试一次吧。" 
							: $_SESSION['session_Setting_HOME_ENCOURAGE'];
							?>
							</p>
						</div>
						<!--	cart_encourage END -->

						<!-- 答疑 -->
						<!--	feedback_box START -->
						<div id="feedback_box" class="collapsible last collapsed">
							<h2 id="askanswer_menu" class="sidebar_title"><span><?php echo $_SESSION['session_Setting_SITE_NAME']; ?>答疑</span></h2>
							<a href="feedbackbox.php" class="fetch_contents" rel="nofollow"></a>
						</div>
						<!--	feedback_box END -->

						<div id="meican_400_hint" style="display:none;">
							<h2>对 4006-166-555 有疑问？</h2>
							<h3>Q: 谁会接听电话？</h3>
							<p>A: 您的电话将由餐厅直接接听，和您以往电话订餐的体验完全一致。</p>
							<h3>Q: 电话费如何计算？</h3>
							<p>A: 无论你在北京还是广州，电话均为正常市话，请放心。</p>
						</div>
					</div>
					<!-- side END -->
				</div>
				<!-- right END -->
			</div>
			<!-- inner_columns END -->
		</div>
		<!-- columns END -->
		  
		<div id="show_img" style="top:1px;left:1px;position:absolute;display:none;"><div id="zhanwei_shang"></div><div id="zhanwei_left"></div><img src=""></div>
		
<?php include 'footer.php' ?>