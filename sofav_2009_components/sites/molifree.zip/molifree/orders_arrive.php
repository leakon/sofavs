<?php
require_once("inc/functions.php");
orders_arrive();
$activeOrders = get_my_active_orders();
if(empty($activeOrders)){
	header('Location: custom_orders_list.php');
}
else {
	header('Location: orders_myactive.php');
}
?>
