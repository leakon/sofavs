<?php
require_once("inc/functions.php");
?>
<ul class="top-nav round-bottom">
<?php if(!empty($_SESSION['session_hasActiveOrder'])) { $timer = get_last_order_timer(); ?>
	<li class="<?php echo empty($_SESSION['session_hasFailedOrder']) ? '' : 'caution' ?>" id="timer">
		<a href="orders_myactive.php">
			<span style="font-size:12px;" title="您有自动删除的订单" id="order_counter"><?php echo $timer;?></span>
		</a>
	</li>
<?php }?>
<?php if(isset($_SESSION['session_customid'])) { //用户已登陆 ?>
	<li> <a href="index.php">首页</a> </li>
	<li> <a href="map.php">外卖地图</a> </li>
	<li> <a href="lipinlist.php">礼品中心</a></li>
	<li class="header_menu_outer">
		<a href="javascript:void(0)">我的帐号</a>
		<ul style="display: none;" class="header_menu">
			<li> <a href="custom_account.php">帐号密码</a> </li>
			<li> <a href="custom_mobile.php">手机号码</a> </li>
			<li> <a href="custom_addresses.php">常用地址</a> </li>
			<li> <a href="custom_support.php">我的答疑</a> </li>
			<li> <a href="custom_orders_list.php">订单历史</a> </li>
			<?php if(!empty($_SESSION['session_hasActiveOrder'])) { ?>
			<li> <a href="orders_myactive.php">当前订单</a> </li>
			<?php } ?>
		</ul>
	</li>
	<li> <a href="logout.php">退出</a> </li>
<?php } else {?>
	<li> <a href="index.php">首页</a> </li>
	<li> <a href="map.php">外卖地图</a> </li>
	<li> <a href="lipinlist.php">礼品中心</a></li>
	<li> <a href="signup.php">注册</a> </li>
	<li> <a href="login.php">登录</a> </li>
<?php }?>
</ul>
