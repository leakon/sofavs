<?php 
include_once 'inc/config.php';
include_once 'inc/functions.php';
$cityId=$_SESSION['session_cityid'];
$cityList=getCityInfo();
$defaultCity;
//得到默认城市
if(empty($cityId)){
	$defaultCity=$cityList[0];
}else{
	foreach($cityList as $k =>$v){
		 if($v['ID']==$cityId){
		 	$defaultCity=$v;
		 }
	}
}
$streets=getStreetByRegionId(1);
//得到默认的城市的餐馆 
$defaultRestaurantList=getRestaurantByCityId($defaultCity['ID']);
//dump($defaultRestaurantList);

?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta content="zh" http-equiv="Content-Language">
<meta content="no" http-equiv="imagetoolbar">
<meta content="width=990" name="viewport">
<meta http-equiv="X-UA-Compatible" content="chrome=1">
<meta name="robots" content="index,follow">
<meta name="apple-itunes-app" content="app-id=501967712">
<title>订乐网 - 外卖地图</title>
<link rel="stylesheet" type="text/css" href="css/mapmain.css">
<link rel="stylesheet" type="text/css" href="css/mapmain.body.css">
<link rel="stylesheet" type="text/css" href="css/mappacked.css">
<script type="text/javascript" src="http://ditu.google.cn/maps/api/js?libraries=places&sensor=false&language=zh&region=CN"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/infoBox.js"></script>
<script type="text/javascript" src="js/keydragzoom_packed.js"></script>
<script type="text/javascript" src="js/map.js"></script>
</head>
<body id="restaurant_map" class="safari chrome non-ie windows">
	<div id="container" class="safari chrome non-ie windows">
		<div class="columns wide">
			<div class="inner_columns">
				<div class="left">
					<div id="content">
						<div id="map_toolbar">
							<a href="/index.php" id="back_home_btn" class="toolbar_btn"><span>首页</span></a>
							<a href="javascript:void(0)" id="location_selector_btn"
								class="toolbar_btn"> <span  class="triangle_outer">我的位置<label id="myCity">
									&nbsp;›&nbsp; <?php echo $defaultCity['Name'];?></label><label id="myLocation"></label></span>
							</a>
							<form id="map_building_pin_dropper"
								action=""
								data-type="building" data-building_id="38" style="display: none"></form>
							<form id="map_search"
								action=""
								data-fly="false">
								<input id="map_search_box" class="text ui-autocomplete-input"
									type="text" name="query" placeholder="" value=""
									autocomplete="off" role="textbox" aria-autocomplete="list"
									aria-haspopup="true">
							</form>
						</div>
						<div id="location_selector_toolbar" class="">
							<div class="left_bg" style="width: 960px;"></div>
							<div class="triangle" style="left: 175px; display: none;"></div>
							<div class="right_bg" style="width: 761px; display: none;"></div>
						</div>
						<div id="location_selector"
							style="height: 450.522px;" data-city="1"
							data-district="2" data-area="364" data-area_name="惠新里"
							data-building="38" data-query_building="38"
							data-building_name="对外经济贸易大学"
							data-url="/areas/addlocationhistory"
							data-click_latitude="39.98035" data-click_longitude="116.42693"
							class="sliding">
							<div id="location_selector_left">
								<div id="city_list">
									<?php 
									$cityIds=array();
									foreach($cityList as $k=>$v){
										$cityIds[]=$v['ID'];//得到城市的ＩＤ的列表
										?>
										<a id="city_item_<?php echo$v['ID'];?>" class="city_item <?php if($cityId==$v['ID']){echo 'selected';}?>"
										 data-id="<?php echo$v['ID'];?>" data-name="<?php echo $v['Name'];?>"
										data-latitude="<?php echo $v['Latitude'];?>" data-longitude="<?php echo $v['Longitude'];?>"><?php echo $v['Name'];?></a> 
										<?php
									}
									?>
								</div>
								<!-- 城市之下的 地区显示，该层默认隐藏 -->
								<div id="area_list_outer" style="display:none;">
									<?php 
										foreach($cityIds as $k =>$v){
											$theRegions=getRegionByCityId($v);
											//dump($theRegions);
											?>
											<div id="area_list_<?php echo $v;?>" class="area_list" data-district="<?php echo $v;?>"
												style="display: block;">
													<div class="area_list_per_letter">
														<div>
												<?php 
													 foreach($theRegions as $key=>$value){
													 	?>
													 	<a id="area_item_<?php echo $value['ID'];?>" data-id="<?php echo $value['ID'];?>"
														data-latitude="<?php echo $value['Latitude'];?>" data-longitude="<?php echo $value['Longitude'];?>"
														class="area_item" data-cityId="<?php echo $v;?>" data-name="<?php echo $value['Name'];?>"><?php echo $value['Name'];?></a>
													 	<?php
													 }									
												
												?>
													</div>
												</div>
											</div>
											<?php 
										}
											?>
									</div>
									<div id="area_list_outer" class="theStreetsDiv" style="display:none">
										<?php 
										foreach($cityIds as $k =>$v){
											$theRegions=getRegionByCityId($v);
													 foreach($theRegions as $key=>$value){
															$theRegionId=$value['ID'];
													 	?>
													 <div id="area_list_street_<?php echo $theRegionId?>" class="quyuclass area_list" style="display: block;">
															
													</div>
													 	<?php
													 }				
										}					
												
												?>
										
								</div>
							</div>
							<div id="location_selector_right">
								<div id="location_history_list_outer"
									class="shortcut_list_outer" style="">
									<h2>
										最近浏览的位置： <a
											href="javascript:void(0);"
											class="clear_all" id="clear_lastview">清空</a>
									</h2>
									<ol id="location_history_list" class="shortcut_list">
									<?php 
									if(!empty($_SESSION['lastview'])){
										foreach($_SESSION['lastview'] as $k =>$v){
											?>
											<li id="location_history_item_<?php echo $v['streetId'];?>" data-regionId="<?php echo $v['regionId'];?>" data-cityId="<?php echo $v['cityId'];?>"
											class="shortcut_list_item location_history_item"><?php echo $v['cityName'];?>
											&nbsp;›&nbsp; <?php echo $v['regionName'];?>&nbsp;›&nbsp; <?php echo $v['streetName'];?></li>
											<?php
										}
									}
									?>
									</ol>
								</div>
							</div>
							
						</div>
						<div id="map_canvas_outer" class="wide" style="height: 729px;">
							
							<div id="map_canvashaha" style="width:624px;height:650px;">
								
							</div>
							
							
							<div id="map_sidebar" class="" style="height: 729px;">
								<div id="list_container" style="height: 729px;">
									<div class="loading_list_hint" style="top: 354.5px;">搜索餐厅中...</div>
									<div class="list_outer" id="search_result_list_outer" style="">
										<h1 id="search_result_list_title" class="with_criteria">
											<span class="without_criteria_title">地图范围内的餐厅：</span> <span
												class="with_criteria_title">符合搜索条件的餐厅：</span>
										</h1>
										
										<div id="filter">
											<strong>筛选：</strong> <a id="is_open_btn"
												href="javascript:void(0)">&nbsp;营业中&nbsp;</a> <a
												id="minimum_order" 
												href="javascript:void(0)">&nbsp;起送金额&nbsp;</a>
										</div>
										
										<!-- 这个地方开始查询出该地区的所有的餐馆 -->
										<?php 
										if(empty($defaultRestaurantList)){
										?>
										<div class="no_search_result_hint">
											<strong>没有符合搜索条件的餐厅</strong>请移除部分条件
										</div>
										<div class="no_bounds_result_hint">
											<strong>地图上没有找到任何餐厅</strong>请尝试拖拽地图
										</div>
										<?php
										}
										else{
											?>
											<ul class="has_restaurant_icon" id="menu_restuarant">
											<?php 
											foreach($defaultRestaurantList as $key =>$value){
													$hotDishes=getTop3DishesByRestaurentId($value['ID']);
													$business=isBusiness($value['ID']);
													$minMoney=empty($value['MinMoney'])?'0':$value['MinMoney'];
												?>
												<li
												class="restaurant_summary search_result_item minimun_order_0" data-business="<?php echo $business?'1':'0';?>" data-minMoney="<?php echo $minMoney;?>"
												data-Name="<?php echo $value['Name']; ?>" data-restaurant_id="<?php echo $value['ID']?>" data-restaurant_uuid="<?php echo $value['UUID']?>"
												data-restaurant_lat="<?php echo $value['Latitude'];?>" data-restaurant_lng="<?php echo $value['Longitude'];?>" data-radius="<?php echo $value['Scope']?>"
												id="_restaurant_<?php echo $value['ID']?>"><a target="_blank" class="name"><?php echo $value['Name'];?></a><span
												class="added_icon"></span> <span class="warning"><?php echo $value['BusinessMemo']?></span>
												~ <span class="regular_dish">热门餐点：<?php foreach($hotDishes as $k =>$v){echo ($v['Name']."、");}?></span>
												~ <span class="opening_time"><?php echo $value['BusinessHour'];?></span>
												<div class="bottom_line">
													<span class="rating rating<?php echo $value['Rating']?>"></span> <span
														class="sale_icon"></span>
												</div></li>
												<?php
											}
											?>
											</ul>
											<?php											
										}
										?>
										<ul class="good"></ul>
										<ul class="normal"></ul>
										<ul class="other"></ul>
										<ul class="out_of_bounds_for_search"></ul>
									</div>
								</div>
								<div id="restaurant_detail" class="cart_hidden"
									style="height: 729px;">
									<div id="restaurant_detail_toolbar">
										<a id="back_to_list" href="javascript:void(0)"></a> <span
											id="restaurant_detail_name"></span>
									</div>
									<div class="loading_hint" style="top: 354.5px;">Loading...</div>
									<div id="restaurant_detail_info" class="info"
										style="height: 698.8181817531586px;"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- 尾部 -->
	</div>
	<input type="hidden" value="<?php echo $defaultCity['Latitude'];?>" id="defaultCityLat"/>
	<input type="hidden" value="<?php echo $defaultCity['Longitude'];?>" id="defaultCityLng"/>
</body>
</html>