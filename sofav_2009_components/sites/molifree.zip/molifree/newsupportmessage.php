<?php
require_once("inc/functions.php");
add_message();
if(isset($_SESSION['session_customid'])){
	header("Location: custom_support.php");
}
else {
	header("Location: index.php");
}
?>
