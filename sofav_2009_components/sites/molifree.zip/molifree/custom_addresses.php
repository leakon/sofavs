<?php
require_once 'inc/functions.php';
custom_addresses_update();
$addresses = get_custom_addresses();
include 'header_account.php';
?>
<link rel="stylesheet" type="text/css" media="screen" href="css/settings.addresses.css"/>
<script type="text/javascript">
document.title = "<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>/ 常用地址";
</script>

<div class="columns">
<div class="inner_columns">
<div class="left">
	<div id="content">
		<div id="settings_nav" class="tab_nav">
			<ul>
				<li>
					<a href="custom_account.php">帐号密码</a>
				</li>
				<li>
					<a href="custom_mobile.php">手机号码</a>
				</li>
				<li class="current">
					<a href="custom_addresses.php">常用地址</a>
				</li>
				<li>
					<a href="custom_support.php">我的答疑</a>
				</li>
				<li>
					<a href="custom_orders_list.php">订单历史</a>
				</li>
				<?php if(!empty($_SESSION['session_hasActiveOrder'])) { ?>
				<li>
					<a href="orders_myactive.php">当前订单</a>
				</li>
				<?php } ?>
			</ul>
		</div>
		<ul id="my_addresses">
			<?php foreach($addresses as $address) { ?>
			<li class="address">
				<div class="address_actions">
					<form method="post" action="custom_addresses.php" class="address_edit action">
						<input type="hidden" value="edit" name="do">
						<div>
							<input type="hidden" value="<?php echo $address['ID'];?>" name="addressid">
							<textarea name="address" class="text address_text"><?php echo $address['Address'];?></textarea>
							<input type="submit" id="edit_this_address" class="btn" value="保存">
						</div>
					</form>
					<form method="post" action="custom_addresses.php" class="address_delete action">
						<input type="hidden" value="delete" name="do">
						<div>
							<input type="hidden" value="<?php echo $address['ID'];?>" name="addressid">
							<input type="submit" value="删除" class="btn delete delete_address">
						</div>
					</form>
				</div>
			</li>
			<?php } ?>
		</ul>
		<div id="new_address">
			<div class="new_address_inner">
				<h3 class="desc"><label for="new_address_text">添加地址</label></h3>
				<form action="custom_addresses.php" method="post">
					<input type="hidden" value="add" name="do">
					<textarea id="new_address_text" class="text address_text" name="address"></textarea>
					<input type="submit" value="保存" class="btn" />
				</form>
			</div>
		</div>
	</div>
</div>
<div class="right">
	<div id="side">
		<div class="section">
			<div class="section-header">
				<h3 class="faq-header">
					常用地址
				</h3>
			</div>
			<p>
				经常在不同的地方订餐？<br/>没关系，<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>可以帮你记住每个地址。
			</p><br/>
		</div>
	</div>
</div>
</div>
</div>
<?php include 'footer.php'; ?>