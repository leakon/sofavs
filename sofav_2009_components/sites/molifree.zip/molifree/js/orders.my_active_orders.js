(function($){
$(function(){
	$('.order_actions .action_cancel').click(function(){
		if ($('body.ie7').html()) {
			// Next time remember to comment the reason
			return true;
		} else {
			return confirm("帮您取消这个订单？");
		}
	});
	if ($('body').attr('id')) {
		$('.z_switch').isSwitch();
	}
	
	function post_callback(data){
		var re = jQuery.parseJSON(data);
		if(re && re.type && re.msg){
			var msg = '<div class="flash_notification ' + re.type + '">' + re.msg + '</div>';
			$('#notifications').html(msg);
		}
	}
	
	$('.start_mobile_verify').click(function() {
		var _self = $(this);
		var code = _self.siblings('.text')[0].value;
		$.post('verify_mobile.php', {activationCode : code, returnmsg: 1}, post_callback);
	});
	
	$('.resend_mobie_verify_code').click(function() {
		var _self = $(this);
		var orderid = _self.siblings('.text').attr('orderid');
		$.post('resend_sms_code.php', {orderid : orderid, returnmsg: 1, from: orders}, post_callback);
	});
	
});
})(jQuery);
