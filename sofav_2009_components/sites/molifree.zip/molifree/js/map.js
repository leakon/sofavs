var theMap = null;//地图对象
var html='';//右侧餐馆信息 的 html存储对象
$(function() {
	initFilter();
	top_map_search();
	//最近浏览记录的清空事件
	$('#clear_lastview').click(function(){
		$.post('addLastView.php',{'m':'clearAll'},function(data){
			if(data=='yes'){
				$('#location_history_list').html('');
			}
		});
	});
	
	$('#other_result_list_hint').click(function(){
		$('#noResult_ul').show();
		$(this).slideUp();
	});
	//地图上不符合条件的餐厅
	$('#no_result_inMap_tip').click(function(){
		if($('#noResult_ul').css('display')=='none'){
			$('#noResult_ul').show();
			$('#other_result_list_hint').slideUp();
		}else{
			$('#noResult_ul').hide();
			$('#other_result_list_hint').slideDown();
		}
	});
	
	
	//右侧 餐馆列表添加点击事件
	addClickEventOnRestraurantList_menu();
	// 1、首先默认的显示地图的 地方，上来如果客户默认的城市是东莞，那么就可以，就是东莞，的第一个区域内的所有的餐馆
	// 得到 默认城市的lat和lng
	var lat = $('#defaultCityLat').val();
	var lng = $('#defaultCityLng').val();
	//显示地图
	//var latlng = new google.maps.LatLng(23.014366042, 113.746404165);
	theMap = showMap(lat, lng, "map_canvashaha");	
	//显示地图上 标记
	setMarkerOnMap();

	// 给city_list 下的a绑定事件
	$('#city_list').children('a').click(function() {
		$('#area_list_outer').show();
		var city = $(this);
		var cityId = city.attr('data-id');
		//默认城市的Id变化
		$('#current_city_id').val(cityId);
		$('#area_list_' + cityId).show().siblings().hide();
		
		$('#myCity').html('›&nbsp; '+$(this).html());
		 $('.theStreetsDiv').hide();
	});
	// 给具体的那个区域点击绑定事件
	$('.area_item').click(function() {
		$('#back_to_list').click();
		
		var region = $(this);//得到jquery对象，
		region.addClass('selected').siblings().removeClass('selected');//改变选中样式
		
		//设置锚点之前先判断该区域的 餐馆，然后 在右侧添加上
		var cityId=region.attr('data-cityId');
		var cityName=$('#city_item_'+cityId).attr('data-name');
		var regionId=region.attr('data-id');
		var regionName=region.attr('data-name');
		
		$('#myLocation').html("›&nbsp; "+regionName);
		
		//加载街道
		$.post('getStreet.php',{'regionId':regionId,'action':'get'},function(data){
			var theDiv= $('.theStreetsDiv');
			
			var theChildrenDiv= $('#area_list_street_'+regionId);
			theChildrenDiv.html('');
			$json=eval("("+data+")");
			$.each($json,function(i,item){//第一次循环
				var content_='<div class="area_list_per_letter" style="left: 0px;">'+
					'<h3>'+i+'</h3>'+
					'<div>';
				$.each(item,function(j,obj){//第二次循环
					content_+='<a id="area_item_street_the_'+obj.id+'" class="area_street" data-name="'+obj.Name+'" data-longitude="'+obj.lng+'" data-latitude="'+obj.lat+'" data-id="'+obj.id+'">'+obj.Name+'</a>';
				});//第二次循环--------结束
				content_+='</div>'+
				'</div>';
				theChildrenDiv.append(content_);
				theChildrenDiv.show().siblings().hide();
				theDiv.show(100);
			});
			//----------------------
			street_click(regionName,cityId,cityName,regionId);//给添加成功的 街道添加点击事件
			
			//----------------------
		});
		// alert(region.html());
		// 绑定地图事件，一定到一定的范围内

		// 扫描了全部的该地区的 餐馆显示出来，并且给他们添加点击事件，让他们有遮罩层

		// 动态显示右侧餐馆。
		//onDragEvt();//出发地图移动事件

	});

	// 控制 地图上面的地区选择
	var areaDiv = $('#location_selector');
	$('#location_selector_btn').click(function(){
//		var temp=$('#location_selector');
		if(areaDiv.css('display')=='none'){
			areaDiv.show();
		}else{
			areaDiv.hide();
		}
	});
	$('#location_selector').show();
	
});



//给街道点击添加 添加事件
function street_click(regionName,cityId,cityName,regionId){
	$('.area_street').click(function(){
//<a id="area_item_street_the_2" class="area_item" data-id="2" data-latitude="23.12862931832777" data-longitude="113.36265515663867" data-name="天府路">天府路</a>
		var streetId=$(this).attr('data-id');
		var streetName=$(this).attr('data-name');
		var streetLat=$(this).attr('data-latitude');
		var streetLng=$(this).attr('data-longitude');
//		alert(streetLat+"===="+streetLng);
		$('#myLocation').html("›&nbsp; "+regionName+"›&nbsp; "+streetName);
	//添加右侧的餐馆
		//首先移动地图,然后调用它的drag 事件
		var latlng = new google.maps.LatLng(parseFloat(streetLat), parseFloat(streetLng));
		theMap.setCenter(latlng);
		onDragEvt();
		$('#location_selector').hide();
		//添加到最近浏览的session中
		$.post('addLastView.php',{'m':'addtosession','cityId':cityId,'cityName':cityName,'regionId':regionId,'regionName':regionName,'streetId':streetId,'streetName':streetName},function(data){
			if(data=='ok'){
				var str='<li id="location_history_item_'+streetId+'"'+ ' data-regionId="'+regionId+'" data-cityId="'+cityId+'"'+
					'class="shortcut_list_item location_history_item">'+cityName+
					'&nbsp;›&nbsp; '+regionName+'&nbsp;›&nbsp; '+streetName+'</li>';
				$('#location_history_list').append($(str));
				
				$('#location_history_item_'+streetId).click(function(){
						$('#myLocation').html("›&nbsp; "+regionName+"›&nbsp; "+streetName);
					var latlngNew = new google.maps.LatLng(parseFloat(streetLat), parseFloat(streetLng));
					theMap.setCenter(latlngNew);
					onDragEvt();
					$('#location_selector').hide();
				});
			}
		});
	});
}
var markets=[];
/**
 * 给地图设置标记
 */
function setMarkerOnMap() {
	markets=[];
	var list = $('#menu_restuarant').children('li');
	$.each(list, function(i, item) {
		var theLi = $(item);
		var restaurantId=theLi.attr('data-restaurant_id');
		var name = theLi.attr('data-name');
		var lat = parseFloat(theLi.attr('data-restaurant_lat'));
		var lng = parseFloat(theLi.attr('data-restaurant_lng'));

		var latlng = new google.maps.LatLng(lat, lng);

		var marker = new google.maps.Marker({
			position : latlng,
			map : theMap,
			title : name,
			icon : 'images/map-pinMd-red.png',
			resId:restaurantId
		});
		markets[restaurantId]=marker;
		google.maps.event.addListener(marker, "click", markerClick);
	});
}


/**
 * 餐馆点击的时候触发,也就是说，点击上面的标记的时候出发该函数
 * 该函数主要功能：
 * 1、显示 提示窗口，（只显示一个）
 * 2、显示 圆形范围区域，(只显示一个)
 * 3、右侧加载该餐厅的信息
 * 4、点击其他地方，效果消失
 */
var infoWindowList=new Array();
var circleList=new Array();
function markerClick() {
	//遍历数组让该数组中的元素全部 去除效果
	/*
	if(infoWindowList.length>0){
		for(var i=0;i<infoWindowList.length;i++){
			infoWindowList[i].close();
		}
	}
	*/
	
	if(circleList.length>0){
		for(var i=0;i<circleList.length;i++){
			circleList[i].setMap(null);
		}
	}
	//设置提示窗口
	/*
	var bgTip = "images/glass_bubble_tiny_bg.png";
	var boxText = document.createElement("div");
	boxText.style.cssText = "border: 1px solid black; margin-top: 8px; background: yellow; padding: 5px;";
	boxText.innerHTML = this.title;
	var myOptions = {
			 content: boxText
			,disableAutoPan: false
			,maxWidth: 0
			,pixelOffset: new google.maps.Size(-140, 0)
			,zIndex: null
			,boxStyle: { 
			  background: "url('tipbox.gif') no-repeat"
			  ,opacity: 0.75
			  ,width: "80px"
			 }
			,closeBoxMargin: "10px 2px 2px 2px"
			,closeBoxURL: "http://www.google.com/intl/en_us/mapfiles/close.gif"
			,infoBoxClearance: new google.maps.Size(1, 1)
			,isHidden: true
			,pane: "floatPane"
			,enableEventPropagation: false
		};
	
	
	
	var infoWindow = new google.maps.InfoWindow(myOptions);

	infoWindow.open(theMap, this);
	// var content='<img src="images/glass_bubble_tiny_bg.png">';
	infoWindowList.push(infoWindow);
	*/
	//设置圆形====================
	var circle=new google.maps.Circle({
		 map: theMap,  
         center: this.position,  
         radius: 500,  
         strokeWeight: 0  ,
         fillColor:'#328be8'
	});  
	circleList.push(circle);//吧该元素放进去
	//发送ajax 请求
	
	var restaurantId=this.resId;//该餐馆的Id
	getRestaurantInfoString(restaurantId);
	$.each(markets,function(i,item){
		if(item){
			item.setIcon('images/map-pinMd-red.png');
		}
	});
	this.setIcon('images/map-pinMd-gold.png');
}

function getRestaurantInfoString(restaurantId){
	$.post('getRestaurant.php',{'m':'getRes','rid':restaurantId},function(data){
		var json=eval("("+data+")");
		if(json.success=="true"){
			//首先封装 所有的餐品 table
			var dishesStr='';
			
			$.each(json.restaurant.dishes,function(i,item){
				dishesStr+='<li id="regular_dish'+item.id+'"'+
				'class="dish dish_item regular_dish dish'+item.id+' normal"'+
		//		'data-referer="" data-price="5" data-name="水饺(小)" data-rev="4894541" data-id="4563741"'+
				'><span class="name">'+
					''+item.dishName+' <span class="annotation_group">'+
				'</span>'+
			'</span> <span class="price_outer"> <span class="price">'+item.price+'</span>'+
			'</span> <a class="cart_count"></a></li>';
			});
			//开始封装整个数据
			var str=''+
			'<div id="restaurant_detail_toolbar">'+
				'<a id="back_to_list" href="javascript:void(0)"></a> <span '+
					'id="restaurant_detail_name"> <a target="_blank"'+
					'href="restaurant.php?uuid='+json.restaurant.uuid+'">'+json.restaurant.name+'</a>'+
				'</span>'+
			'</div>'+
			'<div class="loading_hint" style="top: 158.5px;">Loading...</div>'+
			'<div id="restaurant_detail_info" class="info" style="height: 307px;">'+
					'<div class="sneak_basic">'+
						'<div class="meta">'+
								'<div class="sneak_warning_outer">'+
									'<span class="rating rating2"></span> <span class="sneak_warning">'+json.restaurant.BusinessMemo+'</span>'+
									'<a target="_blank" href="restaurant.php?uuid='+json.restaurant.uuid+'">进店看看 »</a>'+
								'</div>'+
								'<div class="sneak_actions">'+
									'<div id="alreadadded" style="display:'+(json.flag=="true"?'block':'none')+'"><span class="">已经加到首页</span>'+'<a id="rm_id_'+json.restaurant.id+'" class="" href="javascript:void(0);" rel="'+json.restaurant.id+'">移出首页</a></div>'+
									'<div id="havenotadd" style="display:'+(json.flag=="true"?'none':'block')+'"><span class="">尚未加到首页</span> <a id="add_id_'+json.restaurant.id+'" class="" href="javascript:void(0);" rel="'+json.restaurant.id+'">加到首页</a></div>'+ 
								'</div>'+
						'</div>'+
								'<div id="restaurant_basic_info">'+
									'<table class="restaurant_info_all">'+
										'<tbody>'+
											'<tr class="restaurant_info_item unknown">'+
												'<th>外卖时间</th>'+
												'<td>'+json.restaurant.BusinessHour+'</td>'+
											'</tr>'+
											'<tr class="restaurant_info_item unknown">'+
												'<th>起送金额</th>'+
												'<td>'+json.restaurant.MinMoney+'</td>'+
											'</tr>'+
											'<tr class="restaurant_info_item unknown">'+
												'<th>送餐范围</th>'+
												'<td>正常周边('+json.restaurant.scope+'m)</td>'+
											'</tr>'+
											'<tr>'+
												'<th>付款方式</th>'+
												'<td>现金支付</td>'+
											'</tr>'+
											'<tr class="section_list">'+
											'<th>餐品种类</th>'+
												'<td>'+json.restaurant.memo+'</td>'+
											'</tr>'+
										'</tbody>'+
									'</table>'+
								'</div>'+
						'</div>'+	
						'<div class="sneak_menu">'+
							'<ul class="right_restaurantInfo" data-uuid="5548d3"'+
								'data-rev="76795" data-deny_order="false" data-tel="82551490"'+
								'data-name="沙县营养小吃" data-id="10470">'+
								'<li class="dish dish_section"><a class="bm"> </a> <span'+
									'class="name">热门餐品</span></li>'+
								dishesStr+
							'</ul>'+
						'</div>'+
						'<div class="sneak_ending">'+
							'<a id="" href="restaurant.php?uuid='+json.restaurant.uuid+'" target="_blank">'+json.restaurant.name+'</a>'+
					   '</div>'+
			'</div>';
			if(html==''){
				html=$('#list_container').html();//存储改html
			}
			$('#list_container').html(str).show();//变换成该餐馆的信息
			//给新添加上去的餐馆的 返回按钮 添加事件
			$('#back_to_list').click(function(){
				$('#list_container').html(html);
				addClickEventOnRestraurantList_menu();
				initFilter();
			});
			//添加 收藏和 移除收藏 点击事件 
				//移除收藏
				$('#rm_id_'+restaurantId).click(function(){
						$.post('favrestaurantAddRemove.php',{'m':'remove','rid':restaurantId},function(data){
							if(data=="success"){
								$('#alreadadded').hide();
								$('#havenotadd').show().children().show();
							}
						});
				});
				$('#add_id_'+restaurantId).click(function(){
						$.post('favrestaurantAddRemove.php',{'m':'add','rid':restaurantId},function(data){
							if(data=="success"){
								$('#alreadadded').show().children().show();
								$('#havenotadd').hide();
							}
						});
					});
		}else{
			
		}
	});
	//封装字符串
	
//'</div>';
	
}
//点击右侧餐馆
function addClickEventOnRestraurantList_menu(){
	//给$menu 下的li 添加点击事件
	var $menu=$('#menu_restuarant');
	$menu.children('li').click(function(){
		var rid=$(this).attr('data-restaurant_id');
		getRestaurantInfoString(rid);
		//地图上面出先东西
		var lat= $(this).attr('data-restaurant_lat');
		var lng=$(this).attr('data-restaurant_lng');
		clickRestaurantOnMap(lat,lng);
		 OverRestaurantOnMap(rid);
	}).mouseover(function(){
	var rid=$(this).attr('data-restaurant_id');
		//getRestaurantInfoString(rid);
		//地图上面出先东西
		var lat= $(this).attr('data-restaurant_lat');
		var lng=$(this).attr('data-restaurant_lng');
		clickRestaurantOnMap(lat,lng);
		OverRestaurantOnMap(rid);
	});	
//	map-pinMd-gold.png
}
/**
 * 根据传递过来的rid ,在地图上出现圆圈
 * @param rid
 */
function clickRestaurantOnMap(lat,lng){
	if(circleList.length>0){
		for(var i=0;i<circleList.length;i++){
			circleList[i].setMap(null);
		}
	}//
	var position= new google.maps.LatLng(parseFloat(lat), parseFloat(lng));
	var circle=new google.maps.Circle({
		 map: theMap,  
        center: position,  
        radius: 500,  
        strokeWeight: 0  ,
        fillColor:'#328be8'
	});  
	circleList.push(circle);//吧该元素放进去
}
/**
 * 根据传递过来的rid ,在途图上设置锚点的颜色
 * @param rid
 */
function OverRestaurantOnMap(rid){
	$.each(markets,function(i,item){
		if(item){
			var the_resId=item.resId;
			if(the_resId==rid){
				item.setIcon('images/map-pinMd-gold.png');
			}else{
				item.setIcon('images/map-pinMd-red.png');
			}
		}
	});
//	var position= new google.maps.LatLng(parseFloat(lat), parseFloat(lng));
//	var circle=new google.maps.Circle({
//		 map: theMap,  
//        center: position,  
//        radius: 500,  
//        strokeWeight: 0  ,
//        fillColor:'#328be8'
//	});  
//	circleList.push(circle);//吧该元素放进去
}


function calculationDistance(lat1, lon1, lat2, lon2) {  
    var R = 6371;//地球半径 km  
    var dLat = (lat2 - lat1) * Math.PI / 180;  
    var dLon = (lon2 - lon1) * Math.PI / 180;  
    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +  
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *  
        Math.sin(dLon / 2) * Math.sin(dLon / 2);  
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));  
    var d = R * c;  
    return d;  
}  

function getDistance(distance) {  
    //大于1 保留两位小数  
    if (distance > 1) return distance.toFixed(2) + "km";  
    //小于1 表示不到1km，使用单位"m"  
    else if (distance <= 1) return Math.round(distance * 1000) + "m";  
}  
/**
 * 根据经纬度 显示地图，返回地图对象
 * @param lat
 * @param lng
 * @param element
 * @returns {google.maps.Map}
 */
function showMap(lat, lng, element) {
	// 加载地图的方法
	// 取得参数
	// var resName = $('#resName').val();
	// var scope = $('#resScope').val();
	// 设置经纬度
	 var latlng = new google.maps.LatLng(parseFloat(lat), parseFloat(lng));
	//var latlng = new google.maps.LatLng(23.014366042, 113.746404165);
	// 设置配置
	var myOptions = {
		zoom : 15,
		center : latlng,
		scaleControl : false, // 比例尺
		mapTypeControl : false,
		mapTypeId : google.maps.MapTypeId.ROADMAP
	};
	// 创建地图
	
	
	var map = new google.maps.Map(document.getElementById(element), myOptions);
	google.maps.event.addListener(map, "drag",onDragEvt);
	/*
	 * var marker = new google.maps.Marker( { position : latlng, map : map,
	 * title : resName, icon:'images/map-pinMd-red.png' });
	 */
	//map.enableKeyDragZoom();
	return map;
}
//给过滤 添加点击事件
function initFilter(){
	$('#is_open_btn').toggle(function(){//营业中点击的话
		$(this).css({'background-position':'0 -20px','color':'#FFF'});
		var $menu=$('#menu_restuarant');
		var objs= $menu.children('li');
	//	var count=objs.length;
		
//		for(var i=0;i<count;i++){
//			var item=$(objs[i]);
////			alert(item.attr('data-business'));
//			if(item.attr('data-business')=='0'){
//				item.hide();
//			}
//		}
		
		$.each(objs,function(i,item){
			if($(item).attr('data-business')=='0'){
				$(item).hide();
			}
		});
	},function(){
		var $menu=$('#menu_restuarant');
		var objs= $menu.children('li');
		$.each(objs,function(i,item){
			$(item).show();
		});
		$(this).css({'background-position':'0 0px','color':'#555555'});
	});
	
	//有起送资金的话
	$('#minimum_order').toggle(function(){
		$(this).css({'background-position':'0 -20px','color':'#FFF'});
		var $menu=$('#menu_restuarant');
		var objs= $menu.children('li');
		$.each(objs,function(i,item){
			if($(item).attr('data-minmoney')=='0'){
				$(item).hide();
			}
		});
	},function(){
		$(this).css({'background-position':'0 0px','color':'#555555'});
		var $menu=$('#menu_restuarant');
		var objs= $menu.children('li');
		$.each(objs,function(i,item){
			$(item).show();
		});
	});
}


/**
 * 拖拽地图的时候发生的事情
 */
$flag=true;
function onDragEvt(){
	$('#back_to_list').click();//返回按钮点击
	//营业中和起送自己边缘的
		$('#is_open_btn').css({'background-position':'0 0px','color':'#555555'});
		$('#minimum_order').css({'background-position':'0 0px','color':'#555555'});
	var $theMap=theMap;
	//得到容器
	var str="";
	var $menu=$('#menu_restuarant');
	if($flag){
		$flag=false;
		window.setTimeout(function(){
			 var maxX = $theMap.getBounds().getNorthEast().lng();   
			 var maxY = $theMap.getBounds().getNorthEast().lat();   
			 var minX = $theMap.getBounds().getSouthWest().lng();   
			 var minY = $theMap.getBounds().getSouthWest().lat();   
			 $.post('doSearchLatLng.php',{'action':'1','maxLng':maxX,'maxLat':maxY,'minLng':minX,'minLat':minY},function(data){
			
				var json=eval("("+data+")");
				if(json.success=='true'){				
					$.each(json.list,function(i,item){
						var resId=item.id;
						var name=item.name;
						var scope=item.scope;
						var resLat=item.lat;
						var resLng=item.lng;
						var hotDishes=item.hotDishes;
						var businessHour=item.businessHour;
						var memo=item.memo;
						var UUID=item.UUID;
						var rating=item.rating;
						var bus=item.business;
						var minMoney=item.minMoney;
						var dishNames='';
						var q=0;
						$.each(hotDishes,function(j,dish){
							if(q==0){
								dishNames+=dish.dishName;	
							}else{
								dishNames+='、'+dish.dishName;
							}
							q++;
						});
						 str+='<li id="_restaurant_'+resId+'" class="restaurant_summary search_result_item minimun_order_0" data-minmoney="'+minMoney+'" data-business="'+bus+'" data-radius="'+scope+'" data-restaurant_lng="'+resLng+'" data-restaurant_lat="'+resLat+'" data-restaurant_uuid="'+UUID+'" data-restaurant_id="'+resId+'" data-name="'+name+'">'+
							'<a class="name" target="_blank">'+name+'</a>'+
							'<span class="added_icon"></span>'+
							'<span class="warning">'+memo+'</span>'+
							'~'+
							'<span class="regular_dish">热门餐点：'+dishNames+'</span>'+
							'~'+
							'<span class="opening_time">'+businessHour+'</span>'+
							'<div class="bottom_line">'+
							'<span class="rating rating'+rating+'"></span>'+
							'<span class="sale_icon"></span>'+
							'</div>'+
							'</li>';
					});
					$menu.html(str);
					
					//给$menu 下的li 添加点击事件
					addClickEventOnRestraurantList_menu();
					
					//给全局变量html 存储刚刚动态生成的信息
					html=$('#list_container').html();
					//得到经纬度
//					var regionLat=parseFloat(region.attr('data-latitude')) ;
//					var regionLng=parseFloat(region.attr('data-longitude'));
					//隐藏掉“ 区域选择”
				//	areaDiv.hide();
					
					//设置地图中心
				//	theMap.setCenter( new google.maps.LatLng(regionLat, regionLng));
					
					//设置锚点，
					setMarkerOnMap();
				}else{//返回空
					$menu.html('');
				}
			});
			$flag=true;
		},1000);
	}
}
//map_search_box 上面搜索框，事件
//ui-state-hover 这个样式是鼠标移动上去之后，
function top_map_search() {
	$('#map_search_box').keyup(function(e) {
		var theSearchBox=$('#theSearchBox');//容器
		var theValue=$('#map_search_box').val();
		if(theValue==''){
			theSearchBox.hide();
			return ;
		}
		theSearchBox.show();
		var htmlString='';
		//  var realkey = String.fromCharCode(e.which);//字符  
	
		//Ajax 发送
		var cityId=$('#current_city_id').val();
		$.post('mapSearch.php',{'action':'map','theValue':theValue,'cityId':cityId},function(data){
			var json=eval("("+data+")");
			htmlString+='<li class="category_item_restaurant ui-menu-item" role="start">'+
				'<a class="ui-corner-all ui-state-hover" tabindex="-1">'+
				'<span class="category">餐厅</span>'+
				'<span class="desc">按关键词‘'+theValue+'’搜索餐厅</span>'+
				'</a>'+
			'</li>';
			$.each(json.restaurants,function(i,item){
				htmlString+='<li class="category_item_restaurant ui-menu-item" role="res" resId="'+item.id+'" lat="'+item.lat+'" lng="'+item.lng+'">'+
					'<a class="ui-corner-all" tabindex="-1">'+
					'<span class="category">餐厅</span>'+
					'<span class="desc">按关键词‘'+item.Name+'’搜索餐厅</span>'+
					'</a>'+
				'</li>';
			});
			htmlString+='<li class="category_item_restaurant ui-menu-item" role="region" regionName="'+theValue+'">'+
				'<a class="ui-corner-all" tabindex="-1">'+
				'<span class="category ui-state-hover">区域</span>'+
				'<span class="desc">按关键词‘'+theValue+'’搜索区域</span>'+
				'</a>'+
			'</li>';
			theSearchBox.html(htmlString);
			theSearchBox.children('li').mouseover(function(){
				$(this).find('a').addClass('ui-state-hover');
				$(this).siblings().find('a').removeClass('ui-state-hover');
			}).click(function(){//每一个Li 点击的时候
				var role=$(this).attr('role');
				if(role=="start"){//按关键字搜索  餐厅
					var cityId=$('#current_city_id').val();
					
					$.post('mapSearch.php',{'action':'start','cityId':cityId,'theValue':theValue},function(data){
						var json=eval("("+data+")");
						if (json.success == 'true') {
							// 得到容器
							var str = "";
							var $menu = $('#menu_restuarant');
							$.each(
											json.restaurant,
											function(i,
													item) {
												var resId = item.id;
												var name = item.name;
												var scope = item.scope;
												var resLat = item.lat;
												var resLng = item.lng;
												var hotDishes = item.hotDishes;
												var businessHour = item.businessHour;
												var memo = item.memo;
												var UUID = item.UUID;
												var rating = item.rating;
												var bus = item.business;
												var minMoney = item.minMoney;
												var dishNames = '';
												var q = 0;
												$
														.each(
																hotDishes,
																function(
																		j,
																		dish) {
																	if (q == 0) {
																		dishNames += dish.dishName;
																	} else {
																		dishNames += '、'
																				+ dish.dishName;
																	}
																	q++;
																});
												str += '<li id="_restaurant_'
														+ resId
														+ '" class="restaurant_summary search_result_item minimun_order_0" data-minmoney="'
														+ minMoney
														+ '" data-business="'
														+ bus
														+ '" data-radius="'
														+ scope
														+ '" data-restaurant_lng="'
														+ resLng
														+ '" data-restaurant_lat="'
														+ resLat
														+ '" data-restaurant_uuid="'
														+ UUID
														+ '" data-restaurant_id="'
														+ resId
														+ '" data-name="'
														+ name
														+ '">'
														+ '<a class="name" target="_blank">'
														+ name
														+ '</a>'
														+ '<span class="added_icon"></span>'
														+ '<span class="warning">'
														+ memo
														+ '</span>'
														+ '~'
														+ '<span class="regular_dish">热门餐点：'
														+ dishNames
														+ '</span>'
														+ '~'
														+ '<span class="opening_time">'
														+ businessHour
														+ '</span>'
														+ '<div class="bottom_line">'
														+ '<span class="rating rating'
														+ rating
														+ '"></span>'
														+ '<span class="sale_icon"></span>'
														+ '</div>'
														+ '</li>';
											});
							$menu.html(str);
							// 给$menu 下的li 添加点击事件
							addClickEventOnRestraurantList_menu();

							// 给全局变量html 存储刚刚动态生成的信息
							html = $('#list_container')
									.html();
							// 设置锚点，
							setMarkerOnMap();
							$('#no_search_result').hide();
						} else {// 返回空
							$('#menu_restuarant').html('');
							$('#no_search_result').show();
						}
					});
				}else if(role=="res"){
					$('#back_to_list').click();// 返回按钮点击
					var resId=$(this).attr("resId");
					$('#map_sidebar').addClass('loading_list');//增加 加载 的过程 显示的图片
					$.post('getRestaurant_map.php',{'resId':resId},function(data){
						$('#map_sidebar').removeClass('loading_list');//增加 加载 的过程 显示的图片
						var json=eval("("+data+")");
						if (json.success == 'true') {
							var idsArray=new Array();
							
							
							// 得到容器
							var str = "";
							var $menu = $('#menu_restuarant');
							$.each(
											json.list,
											function(i,
													item) {
												var resId = item.id;
												idsArray.push(resId);//放入数组
												var name = item.name;
												var scope = item.scope;
												var resLat = item.lat;
												var resLng = item.lng;
												var hotDishes = item.hotDishes;
												var businessHour = item.businessHour;
												var memo = item.memo;
												var UUID = item.UUID;
												var rating = item.rating;
												var bus = item.business;
												var minMoney = item.minMoney;
												var dishNames = '';
												var q = 0;
												$
														.each(
																hotDishes,
																function(
																		j,
																		dish) {
																	if (q == 0) {
																		dishNames += dish.dishName;
																	} else {
																		dishNames += '、'
																				+ dish.dishName;
																	}
																	q++;
																});
												str += '<li id="_restaurant_'
														+ resId
														+ '" class="restaurant_summary search_result_item minimun_order_0" data-minmoney="'
														+ minMoney
														+ '" data-business="'
														+ bus
														+ '" data-radius="'
														+ scope
														+ '" data-restaurant_lng="'
														+ resLng
														+ '" data-restaurant_lat="'
														+ resLat
														+ '" data-restaurant_uuid="'
														+ UUID
														+ '" data-restaurant_id="'
														+ resId
														+ '" data-name="'
														+ name
														+ '">'
														+ '<a class="name" target="_blank">'
														+ name
														+ '</a>'
														+ '<span class="added_icon"></span>'
														+ '<span class="warning">'
														+ memo
														+ '</span>'
														+ '~'
														+ '<span class="regular_dish">热门餐点：'
														+ dishNames
														+ '</span>'
														+ '~'
														+ '<span class="opening_time">'
														+ businessHour
														+ '</span>'
														+ '<div class="bottom_line">'
														+ '<span class="rating rating'
														+ rating
														+ '"></span>'
														+ '<span class="sale_icon"></span>'
														+ '</div>'
														+ '</li>';
											});
							$menu.html(str);
							// 给$menu 下的li 添加点击事件
							addClickEventOnRestraurantList_menu();

							// 给全局变量html 存储刚刚动态生成的信息
							html = $('#list_container')
									.html();
							// 设置锚点，
							setMarkerOnMap();
							
							//显示  没有搜索到的餐馆							
							getNoResultList(idsArray);
							$('#no_search_result').hide();//有符合搜索条件的餐厅请移除部分条件 

							
						} else {// 返回空
							$('#menu_restuarant').html('');
							$('#no_search_result').show();
						}
					});
					
//					var lat=$(this).attr('lat');
//					var lng=$(this).attr('lng');
//					theMap.setCenter( new  google.maps.LatLng(parseFloat(lat), parseFloat(lng)));
//					$('#no_search_result').hide();
//					onDragEvt();
					
				}else if(role=="region"){//按关键字搜索  
					$('#back_to_list').click();// 返回按钮点击
					var resId=$(this).attr("resId");
					$('#map_sidebar').addClass('loading_list');//增加 加载 的过程 显示的图片
					$.post('mapSearch.php',{'action':'end','theValue':theValue},function(data){
						$('#map_sidebar').removeClass('loading_list');//增加 加载 的过程 显示的图片
						var json=eval("("+data+")");
						if (json.success == 'true') {
							var idsArray=new Array();
							
							
							// 得到容器
							var str = "";
							var $menu = $('#menu_restuarant');
							$.each(
											json.restaurant,
											function(i,
													item) {
												var resId = item.id;
												idsArray.push(resId);//放入数组
												var name = item.name;
												var scope = item.scope;
												var resLat = item.lat;
												var resLng = item.lng;
												var hotDishes = item.hotDishes;
												var businessHour = item.businessHour;
												var memo = item.memo;
												var UUID = item.UUID;
												var rating = item.rating;
												var bus = item.business;
												var minMoney = item.minMoney;
												var dishNames = '';
												var q = 0;
												$
														.each(
																hotDishes,
																function(
																		j,
																		dish) {
																	if (q == 0) {
																		dishNames += dish.dishName;
																	} else {
																		dishNames += '、'
																				+ dish.dishName;
																	}
																	q++;
																});
												str += '<li id="_restaurant_'
														+ resId
														+ '" class="restaurant_summary search_result_item minimun_order_0" data-minmoney="'
														+ minMoney
														+ '" data-business="'
														+ bus
														+ '" data-radius="'
														+ scope
														+ '" data-restaurant_lng="'
														+ resLng
														+ '" data-restaurant_lat="'
														+ resLat
														+ '" data-restaurant_uuid="'
														+ UUID
														+ '" data-restaurant_id="'
														+ resId
														+ '" data-name="'
														+ name
														+ '">'
														+ '<a class="name" target="_blank">'
														+ name
														+ '</a>'
														+ '<span class="added_icon"></span>'
														+ '<span class="warning">'
														+ memo
														+ '</span>'
														+ '~'
														+ '<span class="regular_dish">热门餐点：'
														+ dishNames
														+ '</span>'
														+ '~'
														+ '<span class="opening_time">'
														+ businessHour
														+ '</span>'
														+ '<div class="bottom_line">'
														+ '<span class="rating rating'
														+ rating
														+ '"></span>'
														+ '<span class="sale_icon"></span>'
														+ '</div>'
														+ '</li>';
											});
							$menu.html(str);
							// 给$menu 下的li 添加点击事件
							addClickEventOnRestraurantList_menu();

							// 给全局变量html 存储刚刚动态生成的信息
							html = $('#list_container')
									.html();
							// 设置锚点，
							setMarkerOnMap();
							
							//显示  没有搜索到的餐馆							
							getNoResultList(idsArray);
							$('#no_search_result').hide();//有符合搜索条件的餐厅请移除部分条件 

							
						} else {// 返回空
							$('#menu_restuarant').html('');
							$('#no_search_result').show();
						}
					});
					
					
//					var regionName=$(this).attr('regionName');
//					$.post('mapSearch.php',{'action':'end','theValue':theValue},function(data){
//						var re=eval("("+data+")");
//						if(re.success=="true"){
//							var regionId=re.id;
//							$('#no_search_result').hide();
////							$('#area_item_'+regionId).click();
//							//显示  没有搜索到的餐馆							
//							getNoResultList();
//						}else{
//							$('#no_search_result').show();
//							 $('#menu_restuarant').children('li').hide();
//						}
//					});
				}
				//容器隐藏
				theSearchBox.hide();
			});
			
		});
	});
}
/**
 * 得到不在搜索范围内的参观的
 */
function getNoResultList(existList){
	/*
	 	<div style="display: block;" id="no_result" class="list_outer">
			<h1 style="height:20px;line-height:20px;">地图上不符合条件的餐厅：</h1>
			<div id="other_result_list_hint" style="display: block;height:20px;line-height:20px;">还有<span>199</span>家</div>
			<div style="display: block;" id="other_result_list">
				<ul class="good" ><li id="restaurant_7145" data-radius="500" data-restaurant_minimum_order="undefined" data-restaurant_uuid="cffa1e" data-restaurant_id="7145" class="restaurant_summary other_result_item minimun_order_unknown"><a href="/restaurant/cffa1e" class="name" target="_blank">一品三笑(东方广场店)</a><span class="added_icon"></span> <div class="bottom_line"><span class="rating rating3"></span> </div></li></ul>
			</div>
</div>
	 */
	//存在参观的 字符串
	var resIds='(';
	var flag=false;
	if(existList){
		var i=0;
		$.each(existList,function(i,item){
			flag=true;
			if(i==0){
				resIds+=item;
			}else{
				resIds+=","+item;
			}
			i++;
		});//循环结束
	}// if  结束 ，得到了resIds
	resIds+=')';
	if(!flag){//如果 没有id那么，就填充0,情况很少
		resIds="(0)";
	}
	//发送ajax 请求
	$.post('selectNotInList.php',{'action':'noResult','ids':resIds},function(data){
		var json=eval("("+data+")");
		$('#no_result_count').html(json.count);
		//得到容器
		var theUl =$('#noResult_ul');
		theUl.html('');
		//开始便利每一个元素
		$.each(json.list,function(i,item){//
//			开始封装字符串
			var theLi='<li id="restaurant_'+item.id+'" data-radius="'+item.scope+'" data-restaurant_minimum_order="undefined" data-restaurant_uuid="'+item.UUID+'" data-restaurant_id="'+item.id+'" class="restaurant_summary other_result_item minimun_order_unknown"><a href="restaurantinfo.php?rid='+item.id+'" class="name" target="_blank">'+item.name+'</a><span class="added_icon"></span> <div class="bottom_line"><span class="rating rating'+item.rating+'"></span></div></li>';
			theUl.append(theLi);
		});	
		theUl.hide();//隐藏 没有查询出的餐厅的列表
	});
	$('#no_result').show();//显示 改区域
}


