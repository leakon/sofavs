/*!
 * Name: counter.js
 **/
(function($){
$(function(){
function count(){
	var counter = $('#order_counter').html();
	if(counter!=null){
		time = counter.split(":")

		var hour = time[0];
		var minute = time[1];
		var second = time[2];
		hour = hour*1;
		minute = minute*1;
		//second = parseInt(second);
		second = second*1
		if(hour==12 && minute==0 && second==0){
			var time = hour+":"+"0"+minute+":"+"0"+second+"+";
			$('#order_counter').html(time);
			return;
		}
		if(second!=59){
			second++
		}else if(hour!=12 && minute!=59 && second==59){
			second = 0;
			minute++;
		}else if(hour!=12 && minute==59 && second==59){
			second = 0;
			minute = 0;
			hour++;
		}
		second = second + "";
		minute = minute + "";
		hour = hour + "";
		if(second.length==1){
			second = "0" + second;
		}
		if(minute.length==1){
			minute = "0" + minute;
		}
		if(hour.length==1){
			hour = "0" + hour;
		}
		var time = hour+":"+minute+":"+second;
		$('#order_counter').html(time);
		setTimeout(count,1000);
	}
	else return;
}
setTimeout(count,1000);

});
})(jQuery);
