/*!
 * Name: settings.js
 **/
(function($){
	//下面这两个函数其实并没有人使用它们，所以暂时不更改。
	function getSetting(name, callback) {
		function applyCallback(response) {
			if (typeof(callback)=='function') {
				callback(response);
			}
		}
		$.get('/settings/get',{'name':name}, applyCallback);
	}
	function setSetting(name, value, callback) {
		$.post('/settings/set',{'name':name,'value':value}, applyCallback);
	}
	$.extend({

	});
	//移除dismiss_hint并get自己的href，参看首页的广告大图的删除
	$.fn.isDismissButton = function() {
		return this.each(function() {
			var self = $(this);
			function dismiss(self) {
				return function() {
					//self.firstParent('.hint').remove();
					self.firstParent('.dismiss_hint').remove();
					var href = self.attr('href');
					if (href) {
						$.get(href);
					}
					return false;
				}
			}
			self.bind('click',dismiss(self));
		});
	};
	$(function() {
		$('.dismiss_button').isDismissButton();
		$('.delete_address').click(function(){
			var r = confirm("真的要删掉这个地址？");
			if(r == true) return true;
			else return false;
		});
	});
})(jQuery);
