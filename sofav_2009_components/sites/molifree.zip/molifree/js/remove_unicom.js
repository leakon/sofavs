/*!
 * Name: remove_unicome.js
 * Comment: JumboLuo 2012/1/12
 * 此脚本在发现本网页不是top则： 
 * 	如果发现id为pzi_container的元素则将其删除，并创建id为muhaha的隐藏div；
 *  如果没有发现id为pzi_container的元素，则每隔1秒钟做一次上述检查和删除工作，一直做10次
 * 也就是说本脚步的主要作用是：如果发现本网页不是top，则删除pzi_container元素。
 **/
function remove_unicom() {
	var do_count = 0;
	function do_remove() {
		do_count++;
		var pzi = top.document.getElementById('pzi_container');
		if (pzi) {
			pzi.parentNode.removeChild(pzi);
			var muhaha = top.document.createElement('div');
			muhaha.id = 'muhaha';
			muhaha.style.display = 'none';
			top.document.body.appendChild(muhaha);
		} else {
			if(do_count < 10) {
				setTimeout(do_remove, 1000);
			} else {
				var muhaha = top.document.createElement('div');
				muhaha.id = 'haha';
				muhaha.style.display = 'none';
				top.document.body.appendChild(muhaha);
			}
		}
	}
	if (top !== self) {
		do_remove();
	}
}
top.onload = remove_unicom;
