/*!
 * Name: application.index.slide.js
 **/
(function($) {
$(function() {
	$.fn.isHeroSlideShow = function(){
		var heroOuter = $(this);
		if (heroOuter.find('.hero').size() < 2) {
			return;
		}
		setInterval(toggle(heroOuter),5000);
		function toggle(heroOuter) {
			return function() {
				heroOuter.find('.hero_show').first().toHide(heroOuter);
			};
		}
	};
	$.fn.toHide = function(heroOuter) {
		var self = $(this);

		if (self.next('.hero').size() > 0) {
			self.next('.hero').toShow();
		} else {
			heroOuter.find('.hero').first().toShow();
		}

		self.css({'opacity':1}).animate({
			'opacity':0
		}, 300, function() {
			self.addClass('hero_hide').removeClass('hero_show');
		});
		return self;
	};
	$.fn.toShow = function() {
		var self = $(this);

		self.css({'opacity':0}).animate({
			'opacity':1
		}, 300, function() {
			self.addClass('hero_show').removeClass('hero_hide');
		});
		return self;
	};

	$('#hero_outer').isHeroSlideShow();
});	
})(jQuery);
