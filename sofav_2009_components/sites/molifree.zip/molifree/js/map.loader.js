(function($) {
$(function() {
	function getScript(src) {
		var script = document.createElement('script');
		script.type = 'text/javascript';
		script.src = src;
		document.body.appendChild(script);
	}
	var scriptSrc= $('#map_scripts').data('src');
	if (typeof(scriptSrc!= 'undefined')) {
		getScript($.trim(scriptSrc));
	}
});
})(jQuery)
