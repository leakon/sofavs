/*!
 * Name: notifications.js
 **/
(function($) {
	$.showNotification = function(type, message) {
		if (type != 'success' && type != 'info' && type != 'error') {
			return;
		}
		$('#notifications').html('<div class="flash_notification '
				+ type + '">' + message + '</div>').show();
	};
	$.fn.isNotification = function() {
		return this.each(function(){
			$('#notifications').show();
			var self = $(this);
			self.click(function(event) {
				if (!$(event.target).hasClass('flash_notification')) {
					return;
				}
				self.slideUp('fast', function(){self.remove()});
			});
		});
	}
	$(function() {
		$('.flash_notification').isNotification();
	});
})(jQuery);
