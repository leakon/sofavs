/*!
 * common.feedback_box.js
 **/
(function($){
$(function(){
	function request() {
		var _self = $(this);
		var timeline = _self.firstParent('.leihou-page-controls').siblings('.leihou-ask-answer-timeline');
		function callback(data) {
			timeline.append(data.html);
			if (data.json.nextPage) {
				_self.attr('href', data.json.nextPage);
			} else {
				_self.firstParent('.leihou-page-controls').remove();
			}
		}
		var url = _self.attr('href');
		$.getJH(url, callback);
		return false;
	}
	$('.leihou-page-controls a.more-button').click(request);

});
$('#ask_answer_content').isAskAnswerContent();
})(jQuery);
