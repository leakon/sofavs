var imgDiv =null;
$(function(){
	imgDiv = $("#show_img");
	// 鼠标移动上去 显示dish图片
	$('.dishes li').mouseover(
					function(e) {
						var path = $(this).attr("dishimg");
						var wi = $(this).attr("wi");
						var hi = $(this).attr("hi");
						
						if (path) {
							imgDiv.html(
									'<img src="' + path + '" width="' + wi
											+ '" height="' + hi + '"/>').css( {
								width : wi + "px",
								height : hi + "px"
							});
							mouse = new MouseEvent(e);
							leftpos = mouse.x;
							toppos = mouse.y;
							show_dish_img((leftpos + 30) + 'px', (toppos - 50)
									+ 'px');
						}
					})
			.mouseout(function() {// 鼠标离去事件
				imgDiv.hide();
			});
	
});
//用来显示dish的层
function show_dish_img(l, t) {
	imgDiv.css( {
		top : t,
		left : l
	}).show();
}
// 获取鼠标坐标函数
var MouseEvent = function(e) {
	this.x = e.pageX
	this.y = e.pageY
}