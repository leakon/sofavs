var oldAddress='';
$(function(){
	oldAddress=$('#address').val();
	
	//编辑以上地址
	
	$('#editAddress').click(function(){
		$('#lblAddress').hide();
		$('#address').val(oldAddress).show();
	});
	//添加新地址
	$('#addAddress').click(function(){
		$('#lblAddress').hide();
		$('#address').val('').show();
	});
	$('#btn_submit').click(function(){
		if($('#telphone').val()==''){
			alert('请输入手机号');
			return false;
		}
		if($('#address').val()==''){
			alert('请输您的地址');
			return false;
		}
		$('#the_form').submit();
	});
});