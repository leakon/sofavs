$(function() {
	$.fn.isMeican400HintIcon = function() {
		function doClick() {
			$('#meican_400_hint').modal({overlayClose:true, opacity: 70, maxWidth: 480, overlayCss: {background: "#fff"}});
			$.post('/settings/set',{'name':'meican400Hint','value':'hidden'})
			return false;
		};
		$(this).click(doClick);
	};
	$('.tel_q_icon').isMeican400HintIcon();
});
