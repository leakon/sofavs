/*!
 * Name: jquery.isCollapsibleMenu.js
 **/
(function($){
	$.fn.isCollapsibleMenu = function () {
		function A() {
			var B = [];
			$("#side .collapsible").each(function () {
				var C = $(this);
				var E = C.find("h2.sidebar_title").attr("id");
				if (E) {
					E = E.replace("_menu", "");
				} else {
					return true;
				}
				var D = C.hasClass("collapsed") ? "C" : "O";
				B.push(E + D);
			});
			$.cookie("menus", B.join("_"), {"path":"/", "expires":365});
		}

		return this.each(function () {
			var D = $(this);
			var B = D.find("h2.sidebar_title");
			function F(G) {
				$.ajax({
					type: "GET",
					url: G,
					dataType: "html",
					beforeSend: function () {
						D.addClass("loading");
					},
					success: function (H) {
						D.find(".sidebar_menu").remove();
						B.after(H);
						C();
						var callback = D.data('callback');
						if (typeof(callback)=='function') {
							callback();
						}
					},
					complete: function () {
						D.removeClass("loading");
					}
				});
			}
			function C() {
				var G = D.find(".sidebar_menu");
				D.find("#friends_view_all").fadeIn();
				G.slideDown(100, function () {
					D.removeClass("collapsed");
					A();
				});
			}
			function E() {
				var G = D.find(".sidebar_menu");
				D.find("a.xref").fadeOut(100);
				D.find("div#friends_view_all").fadeOut(100);
				G.slideUp(100, function () {
					D.addClass("collapsed");
					A();
				});
			}
			D.bind("expand", function () {C();});
			D.bind("collapse", function () {E();});
			B.click(function (H) {
				if (H.target.nodeName.toLowerCase() == "a") {
					return true;
				}
				var G = D.find("a.fetch_contents");
				if (D.hasClass("collapsed")) {
					D.find("a.xref").fadeIn(100);
					if (G.length) {
						F(G.attr("href"));
						G.remove();
					} else {
						C();
					}
				} else {
					E();
				}
			});
		});
	};
	$(function(){
		$('.collapsible').isCollapsibleMenu();
	});
})(jQuery);
