(function($){
	$.fn.parabola = function(t, targetX, targetY, topTargetY, onFinish) {//topTargetY<0
		if (topTargetY == null) {
			topTargetY = -80;
		}
		var item = $(this);
		var m = item.offset().left;
		var n = item.offset().top;
		var l = m;
		var h = n;
		var x = (targetX - m) / 10000;
		if ($('body.ie').size() > 0) {
			x = 3*x;
		}
		if ($('body.ie8').size() > 0) {
			x = 2*x;//actually 6*x
		}
		if ($('body.safari').size() > 0) {
			x = 2*x;
		}
		var	distance = Math.abs(m-targetX);
		var i = setInterval(function(){
			if (item) {
				var inf = false;
				if (distance > 0) {
					h = (((-2*topTargetY+(n-targetY))+Math.sqrt(topTargetY*topTargetY-4*topTargetY*(n-targetY)))/((m-targetX)*(m-targetX)))*(l-targetX)*(l-targetX) - ((-2*topTargetY+Math.sqrt(topTargetY*topTargetY-4*topTargetY*(n-targetY)))/(m-targetX))*(l-targetX) + targetY;
					l += x * t;
				} else {
					inf = true;
					h -= Math.abs(20*x*t);	
					l = targetX;
				}
				item.css({
					"left": l,	
					"top": h	
				});
				if ((m < targetX && l > targetX && h > (targetY-10)) || (m > targetX && l < targetX && h > (targetY-10)) ||(inf && h < targetY) ||Math.abs(h) > 3000 || Math.abs(l) > 3000) {
					clearInterval(i);
					item.remove();
					if (typeof(onFinish) == 'function') {
						onFinish();
					}
				}

			} else {
				
			}
		}, t/100);
	}
})(jQuery);
