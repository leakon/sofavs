<?php
require_once("inc/functions.php");
verify_email();
header('Location: index.php');

?>
