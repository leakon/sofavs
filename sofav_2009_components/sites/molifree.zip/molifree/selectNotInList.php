<?php
include_once 'inc/functions.php';
if($_POST['action']=='noResult'){
	$db=dao();
	$sql="select * from restaurant where Hide =0 and ID not in ".$_POST['ids'];
	$sqlCount="select count(*) as c from restaurant where Hide =0 and ID not in ".$_POST['ids'];
	$re=$db->query($sqlCount);
	$count=0;
	if($n=$re->fetch_assoc()){
		$count=$n['c'];
	}
	//echo $json;
	$reslut=$db->query($sql);
	echo $db->error;
	$i=0;
	$json="{'count':'".$count."','list':[";
	while($row=$reslut->fetch_assoc()){
		if($i==0){
			$json .= "{'id':$row[ID],'UUID':'$row[UUID]','businessHour':'$row[BusinessHour]','rating':'$row[Rating]','memo':'$row[BusinessMemo]','name':'$row[Name]','scope':'$row[Scope]','lat':'$row[Latitude]','lng':'$row[Longitude]'}";
		}else{
			$json .= ",{'id':$row[ID],'UUID':'$row[UUID]','businessHour':'$row[BusinessHour]','rating':'$row[Rating]','memo':'$row[BusinessMemo]','name':'$row[Name]','scope':'$row[Scope]','lat':'$row[Latitude]','lng':'$row[Longitude]'}";
		}
		$i++;
	}
	$json.="]}";
	$db->close();
	echo $json;
}
?>