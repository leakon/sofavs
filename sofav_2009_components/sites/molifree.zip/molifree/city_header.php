<?php
require_once("inc/functions.php");
?>
<div id="city_header" >
	/ <a class="toggle" href="javascript:void(0)">
		<?php echo $_SESSION['session_city']; ?>
	  </a>
		<ul class="header_menu" style="display:none">
			<?php echo get_city_list(); ?>
		</ul>
</div>
<?php if( $_SESSION['session_cityhint']!='0' ){ ?>
<div id="city_hint">
	不在<?php echo $_SESSION['session_city'];?>？请先选择城市
	<a rel="nofollow" href="settings.php?cityhint=close" id="city_hint_dismiss">
		<img alt="" src="images/city_hint_close.gif">
	</a>
</div>

<?php } ?>