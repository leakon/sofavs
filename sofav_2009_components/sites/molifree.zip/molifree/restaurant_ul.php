<?php
?>
<ul class="restaurant_list not_index">
<li id="restaurant1431" class="restaurant1431 restaurant rate3 no_discount" data-id="1431" data-name="鑫红碗(建外SOHO店)" data-tel="58691726/58691725" data-rev="108287" data-deny_order="false" itemscope itemtype="http://schema.org/Restaurant">
	<div class="meta rev108287 rate3 no_discount">
		<meta itemprop="menu" content="http://meican.com/restaurant/a9bd6d" />
		<meta itemprop="maps" content="http://meican.com/restaurant/a9bd6d/map" />
		<meta itemprop="telephone" content="4006166555 ext. 8811" />
		<a name="restaurant1431" class="bm">&nbsp;</a>
		<h1 class="name">
			<a class="value" href="/restaurant/a9bd6d" itemprop="name">
				鑫红碗(建外SOHO店)
			</a>
		</h1>
		
		<div class="tel">
			4006<span class="tel_divider"></span>166<span class="tel_divider"></span>555<span class="tel_ext">转</span>8811
			<a class="tel_q_icon" href="javascript:void(0)"></a>
		</div>
		
		<div class="actions">
			<a rel="nofollow" href="/favrestaurants/add?uuid=a9bd6d" id="add_id_1431" class="btn fav-add">加到首页</a>
			<a rel="nofollow" href="/favrestaurants/remove?id=1431" id="rm_id_1431" class="btn delete fav-remove">移出首页</a>
			<span class="timestamp">
				10天前更新
			</span>
		</div>
	</div>
	
	<div class="restaurant_rate rate3 no_discount">
		<span class="icon" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating"><meta itemprop="ratingValue" content="3"/><meta itemprop="bestRating" content="3"/><meta itemprop="worstRating" content="1"/><meta itemprop="ratingCount" content="278"/></span>
		<span class="words">建外SOHO西区14:00~17:00才可送餐 / 该餐厅多数情况能送外卖 / 起送金额 30元</span>
	</div>
	
	<ul class="dishes">
		<!--section-->
		<li class="dish dish489650 dish_rev2733129 is-section">
			<a class="bm" name="section489650">&nbsp;</a>
			<span class="name">精美凉菜</span>
			<a class="back_top" href="#top">TOP</a>
		</li>
		<!--dish-->
		<li id="dish489651" class="dish dish489651" data-id="489651" data-rev="2733130" data-name="香辣牛肉" data-price="18">
			<span class="name">香辣牛肉</span>
			<span class="price_outer">
				<span class="price">18</span>
			</span>
			<a class="cart_count"></a>
		</li>
		<li id="dish489652" class="dish dish489652" data-id="489652" data-rev="2733131" data-name="红油百叶" data-price="12">
			<span class="name">红油百叶</span>
			<span class="price_outer">
				<span class="price">12</span>
			</span>
			<a class="cart_count"></a>
		</li>
		
		
		<!--section-->
		<li class="dish dish489650 dish_rev2733129 is-section">
			<a class="bm" name="section489650">&nbsp;</a>
			<span class="name">精美凉菜</span>
			<a class="back_top" href="#top">TOP</a>
		</li>
		<!--dish-->
		<li id="dish489651" class="dish dish489651" data-id="489651" data-rev="2733130" data-name="香辣牛肉" data-price="18">
			<span class="name">香辣牛肉</span>
			<span class="price_outer">
				<span class="price">18</span>
			</span>
			<a class="cart_count"></a>
		</li>
		<li id="dish489652" class="dish dish489652" data-id="489652" data-rev="2733131" data-name="红油百叶" data-price="12">
			<span class="name">红油百叶</span>
			<span class="price_outer">
				<span class="price">12</span>
			</span>
			<a class="cart_count"></a>
		</li>
	</ul>
</li>
</ul>