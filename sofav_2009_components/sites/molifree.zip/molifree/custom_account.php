<?php
require_once 'inc/functions.php';
custom_account_update();
include 'header_account.php';
?>
<script type="text/javascript">
document.title = "<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> / 我的账号";
</script>
<div class="columns">
<div class="inner_columns">
<div class="left">
	<div id="content">
		<div id="settings_nav" class="tab_nav">
			<ul>
				<li class="current">
					<a href="custom_account.php">帐号密码</a>
				</li>
				<li>
					<a href="custom_mobile.php">手机号码</a>
				</li>
				<li>
					<a href="custom_addresses.php">常用地址</a>
				</li>
				<li>
					<a href="custom_support.php">我的答疑</a>
				</li>
				<li>
					<a href="custom_orders_list.php">订单历史</a>
				</li>
				<?php if(!empty($_SESSION['session_hasActiveOrder'])) { ?>
				<li>
					<a href="orders_myactive.php">当前订单</a>
				</li>
				<?php } ?>
			</ul>
		</div>
		<form class="account_form" action="custom_account.php" method="post">
			<table>
				<tr>
					<th>
						<label for="email">Email</label>
					</th>
					<td>
						<input <?php echo !empty($_SESSION['session_customEmailVerified']) ? 'disabled="disabled" ': '' ?>type="text" class="text<?php echo !empty($_SESSION['session_customEmailVerified']) ? ' disabled': '' ?>" id="email" name="email" value="<?php echo $_SESSION['session_customEmail'];?>"/>
						<div class="hint"<?php echo !empty($_SESSION['session_customEmailVerified']) ? ' style="display:none"': '' ?>>修改 email 地址后，需要重新验证邮箱</div>
					</td>
				</tr>
				<tr>
					<th>
						<label for="username">用户名</label>
					</th>
					<td>
						<input type="text" class="text" id="username" name="username" value="<?php echo $_SESSION['session_customUsername'];?>"/>
						<div class="hint">2-16 个字母，数字，汉字或下划线</div>
					</td>
				</tr>
				<tr>
					<th>
						<label for="password">新密码</label>
					</th>
					<td>
						<input type="password" class="text password" id="password" name="password" value="" autocomplete="off"/>
						<div class="hint">如果不想修改密码，请保持空白</div>
					</td>
				</tr>
				<tr>
					<th></th>
					<td>
						<input type="submit" class="btn" value="保存"/>
					</td>
				</tr>
			</table>
		</form>
	</div>
</div>
<div class="right">
	<div id="side">
		<div class="section">
			<div class="section-header">
				<h3 class="faq-header">帐号密码</h3>
			</div>
			<p>
				在这里您可以修改用户名或密码。<br/>是的，在<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>您只要输入一遍就可以修改密码。
			</p><br/>
		</div>
	</div>
</div>
</div>
</div>
<?php include 'footer.php'; ?>