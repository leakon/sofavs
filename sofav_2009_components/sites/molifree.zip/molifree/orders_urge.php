<?php
require_once("inc/functions.php");

orders_urge();
header('Location: orders_myactive.php');
?>
