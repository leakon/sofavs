<?php
require_once("inc/functions.php");

include 'header_min.php';
?>
<script type="text/javascript">
document.title = "<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> / 验证Email已经发送";
</script>
<div class="columns">
<div class="inner_columns">
<div class="left">
	<div id="content">
		<h1 id="page_title">已成功重发验证Email！</h1>
		<div id="verify_instruction">
			<h2 id="now_verify_email">下一步，请验证您的Email</h2>
			<p>我们发了一封验证邮件到<strong><?php echo $_POST['email']; ?></strong>，请到您的邮箱收信，并点击其中的链接验证您的邮箱。</p>
			<p id="to_mailbox"><a class="btn" target="_blank" href="<?php echo get_mail_url($_POST['email']); ?>">立即去邮箱激活您的帐号</a></p>
		</div>
	</div>
</div>
<div class="right">
	<div id="side">
		<h2>没有收到邮件？</h2>
		<p>可能被误判为垃圾邮件了，请到垃圾邮件箱找找看。</p>
	</div>
</div>
</div>
</div>
<?php
include 'footer.php';
?>