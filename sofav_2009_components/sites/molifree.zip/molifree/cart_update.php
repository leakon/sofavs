<?php
require_once("inc/functions.php");
cart_update();
?>
