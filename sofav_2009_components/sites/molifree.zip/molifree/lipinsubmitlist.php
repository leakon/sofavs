<?php 
include_once 'inc/functions.php';

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8">




<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link href="css/restanrantinfo.css" type="text/css" rel="stylesheet">
<link href="css/restanrantinfo.base.css" type="text/css"
	rel="stylesheet">

<style type="text/css">
bory {
	font-family: 'Microsoft YaHei' ! important;
}
</style>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ordersubmitout.js"></script>
<script type="text/javascript" src="js/jquery.noty.js"></script>
<!-- layouts -->
<script type="text/javascript" src="js/center.js"></script>
<!-- themes -->
<script type="text/javascript" src="js/default.js"></script>
<script type="text/javascript" src="js/commonTip.js"></script>
<script type="text/javascript" src="js/index.js"></script>

<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
	<meta content="zh" http-equiv="Content-Language"/>
	<meta content="no" http-equiv="imagetoolbar"/>
	<meta content="width=990" name="viewport"/>
	<meta http-equiv="X-UA-Compatible" content="chrome=1" />
	<meta name="robots" content="index,follow"/>
	<link rel="shortcut icon" href="favicon.ico"> 
	<title><?php echo $_SESSION['session_Setting_SITE_NAME']; ?> - 附近的外卖详细菜单</title>
	
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.footer.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.header.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.body.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/notifications.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/common.collapsible.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/common.billboard.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/hero_restaurant.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/restaurant_list.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/restaurant_list.dishes.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/hero_dishes.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/cart.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/application.index.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/application.index.toc.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/application.index.welcome.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/ask_answer.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/meican400hint.css"/>
	<style type="text/css">
		html {
			background: <?php echo empty($_SESSION['session_Setting_BG_COLOR']) ? "#F3F3F3" : $_SESSION['session_Setting_BG_COLOR']; ?>;
			<?php if (!empty($_SESSION['session_Setting_BG_IMAGE'])) { ?>
				background-image: url(<?php echo $_SESSION['session_Setting_BG_IMAGE']; ?>);
			<?php }?>
		}
		body {
			background: <?php echo empty($_SESSION['session_Setting_BG_COLOR']) ? "#F3F3F3" : $_SESSION['session_Setting_BG_COLOR']; ?>;
			<?php if (!empty($_SESSION['session_Setting_BG_IMAGE'])) { ?>
				background-image: url(<?php echo $_SESSION['session_Setting_BG_IMAGE']; ?>);
			<?php }?>
		}

		#site_stats strong {
			font-size:16px;		
			line-height:42px;
		}
		.columns .right {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		.columns .right a:hover {
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ievil .columns {
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ievil .columns .right {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ievil .columns .right a:hover {
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		
		#side .cart li.dish .name {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		    background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .name {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		    background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .price {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .cart_count {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		#side .cart li.dish .delete {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .delete:hover{
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		body.ie6 #side .cart li.dish .delete {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ie6 #side .cart li.dish .delete:hover {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		#cart_fix_hint {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#cart_outer.fixed {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#sidebar_search #profile_section.fixed {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		#side .cart li.restaurant .meta {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#DBEFF8" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		}
		.leihou-author {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		}
		.leihou-ask-answer-timeline {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#C3E3F3" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		}

		.flash_notification.error {
			background:<?php echo empty($_SESSION['session_Setting_ERROR_BG_COLOR']) ? "#F23030" : $_SESSION['session_Setting_ERROR_BG_COLOR']; ?>;
			color:<?php echo empty($_SESSION['session_Setting_ERROR_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_ERROR_TEXT_COLOR']; ?>;
		}
		.flash_notification.info {
			background:<?php echo empty($_SESSION['session_Setting_INFO_BG_COLOR']) ? "#FC9C0F" : $_SESSION['session_Setting_INFO_BG_COLOR']; ?>;
			color:<?php echo empty($_SESSION['session_Setting_INFO_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_INFO_TEXT_COLOR']; ?>;
		}
		.flash_notification.success {
			background:<?php echo empty($_SESSION['session_Setting_SUCCESS_BG_COLOR']) ? "#7ED10E" : $_SESSION['session_Setting_SUCCESS_BG_COLOR']; ?>;
			color:<?php echo empty($_SESSION['session_Setting_SUCCESS_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_SUCCESS_TEXT_COLOR']; ?>;
		}
				
	</style>
	<script src="js/remove_unicom.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.z.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/header_menu.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/lib.json2.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/settings.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/notifications.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/counter.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.cookie.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.isCollapsibleMenu.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.scrollto-min.js" type="text/javascript" charset="utf-8"></script>
	
	<script src="js/fav_restaurants.add_delete.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/hero_restaurant.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/application.index.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/application.index.slide.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/application.index.search.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.simplemodal.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/meican400hint.js" type="text/javascript" charset="utf-8"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8">
<title></title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link href="css/restanrantinfo.css" type="text/css" rel="stylesheet">
<link href="css/restanrantinfo.base.css" type="text/css"
	rel="stylesheet">
	


<style type="text/css">
.nodec {
	text-decoration: none;
}

.nodec:hover {
	text-decoration: none;
}
</style>

</head>
<body>
<div id="bookmark_top"><a href="#" name="top" rel="nofollow">&nbsp;</a></div>
<div id="prototypes"
	style="display: none"></div>

<div id="container" class="<?php echo get_client_browser_type(); ?>">
<div id="header-outer">
<div id="header">
<h3 class="offscreen">页首</h3>
<h1><a href="index.php" id="logo"> <img
	src="<?php echo empty($_SESSION['session_Setting_LOGO_IMAGE']) ? "images/logo.png" : $_SESSION['session_Setting_LOGO_IMAGE'];?>"
	alt="<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> - 附近的外卖详细菜单" />
</a></h1>

<?php include 'city_header.php'; ?> <?php include 'top_nav.php'; ?>

<div class="bookmark"></div>
</div>
</div>
</div>
<div class="zong">

<div class="zhong">
<div class="container">
<div class="constr">
<form method="post" action="doLipinConvert.php" id="the_form" >

<div class="well" style="padding-left:0px;padding-right:5px;">
<div class="constr_in"
	style="padding-left: 0px; padding-right: 3px;">

<div class="mt20 pb5"
	style="margin-top: 0px; margin-left: 12px;"><!-- 进度条 -->

<!-- 步骤描述 -->
<div class="f14 c4c"><span class="abs">进度：[第2/3步]</span>
<ul class="fix tr">
	<li class="float_three">1. 选择礼品</li>
	<li class="float_three cg b">2. 填写订单</li>
	<li class="float_three">3. 确认订单</li>
</ul>
</div>
</div>

<!-- 填单主体内容 -->
<div class="span4">
<div class="constr_bg" id="cenggaodu2" style="height: 393px;">
<div class="p20 rel z">
<h3 class="f15 fw db"
	style="color: green; font-family: 'Microsoft YaHei' ! important;">兑换信息
</h3>
<div id="first_contener" class="btd res_ord_fill_box"
	style="border-top-width: 1px; border-top-style: solid; border-top-color: rgb(204, 204, 204); border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: rgb(204, 204, 204); height: 209px;">
<div id="content_scroll" style="height: 249px;">
<div class="dingcanhengxian"><span class="dingcanbuhengxian"
	style="color: #000000; background: #fbfbfb;"><?php echo $_GET["pname"]?></span> <span
	class="co  dingcanyoubuxian" style="color: green; background: #fbfbfb;"><?php echo $_GET["pscore"]?>
X 1 </span></div>
<input type="hidden" name="lipinNames[]" value="<?php echo $_GET["pname"]?>"> 
<input type="hidden" name="lipinScores[]" value="<?php echo $_GET["pscore"]?>"> 
<input type="hidden" name="lipinIds[]" value="<?php echo $_GET["pid"]?>">
<input  type="hidden" name="lipinCounts[]" value="1">

</div>
<div class="fix pt10" style="float: right; margin-top: 28px;">
<div class="pl10 cg mt-1"><span class="g2" style="font-size: 18px;">合计：</span><?php echo $_GET["pscore"]?>积分</div>
<input type="hidden" name="lipinTotalScore" value="<?php echo $_GET["pscore"]?>"></div>
</div>
</div>
</div>
</div>
<div class="span7">
<div class="constr_bg" id="cenggaodu">
<div class="p20 rel z">
<h3 class="f15 fw db"
	style="color: green; font-family: 'Microsoft YaHei' ! important;">邮寄信息


</h3>
<div class="btd res_ord_fill_box" style="padding: 0px;">
<div id="right_contener" style="width: 470px; margin-top: 10px;">
<div class="control-group" style="width: 500px;"><span
	style="font-size: 16px;"> <span class="co">*</span><span
	style="font-size: 14px;"> 您的手机</span> </span> <input type="text"
	id="telphone" name="telphone" style="width: 250px;height:22px"
	onkeyup="this.value=this.value.replace(/\D/g,'')"  class="input-medium"
	value="<?php echo empty($defaultAddress['mobile'])?$_SESSION['session_customMobile']:$defaultAddress['mobile'];?>"> <span id="phone_tip"></span></div>
<div class="control-group" style="width: 500px;"><span
	style="font-size: 16px;"> <span class="co">*</span><span
	style="font-size: 14px;"> 详细地址</span> </span> 											
<textarea id="address" name="address"
	style="width: 295px; font-family: 微软雅黑;"></textarea>

</div>
<div class="control-group" style="width: 400px; margin-left: 10px;"><span
	style="font-size: 16px;"><span style="font-size: 14px;">特殊要求</span> </span>
<textarea style="width: 295px;" rows="5" name="notice"></textarea> <!--														<p style="margin-left:60px;" class="mt5">如果您有什么要求请在这里注明,如:<span style="color:red;">不吃辣、不吃香菜...</span></p>-->
</div>
</div>
<div id="resReqOther"><!-- 预订类型 --> <!-- 餐位要求 --></div>
<div id="resReqTable"><!-- 选择餐桌(由“餐位要求”数据决定) --></div>
<div class="btd res_ord_fill_box" style="width: 450px;">
<div class="tc mt20">
<button id="btn_submit" class="btn btn-small btn-success pull-right"><span
	class="btn-label" style="font-size: 12px; font-family: 微软雅黑;">同意并提交</span>
</button>
</div>
</div>


</div>
</div>
</div>
</div>

<input type="hidden" name="inOrOut" value="out"> <input type="hidden"
	name="the_restaurant_id" value=""></div>

</div>
</form>
</div>
</div>
</div>
</div>
</body>
</html>
