<?php
require_once("inc/functions.php");

if( isset($_GET['welcomehint']) && $_GET['welcomehint']=='close' ) {
	close_welcome_hint();
}
if( isset($_GET['cityhint']) && $_GET['cityhint']=='close' ) {
	close_city_hint();
}
if( isset($_GET['maphint']) && $_GET['maphint']=='close' ) {
	close_map_hint();
}

?>
