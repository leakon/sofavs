<?php
require_once("inc/functions.php");
$re = add_fav_restaurant();
?>
{"ret":<?php echo $re["ret"]; ?>,"saveStatus":<?php echo $re["saveStatus"]; ?>,"favRestaurantsCount":<?php echo $re["favRestaurantsCount"]; ?>}
