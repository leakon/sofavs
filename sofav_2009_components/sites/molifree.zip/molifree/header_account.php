<?php
require_once("inc/functions.php");
check_login();
?>
<!DOCTYPE html>
<html lang="zh">
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
	<meta content="zh" http-equiv="Content-Language"/>
	<meta content="no" http-equiv="imagetoolbar"/>
	<meta content="width=990" name="viewport"/>
	<meta http-equiv="X-UA-Compatible" content="chrome=1" />
	<meta name="robots" content="index,follow"/>
	<link rel="shortcut icon"href="favicon.ico"> 
	<title><?php echo $_SESSION['session_Setting_SITE_NAME']; ?></title>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.footer.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.header.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.body.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/notifications.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/common.tab_nav.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/account.form.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/settings.css"/>
	<style type="text/css">
		html {
			background: <?php echo empty($_SESSION['session_Setting_BG_COLOR']) ? "#F3F3F3" : $_SESSION['session_Setting_BG_COLOR']; ?>;
			<?php if (!empty($_SESSION['session_Setting_BG_IMAGE'])) { ?>
				background-image: url(<?php echo $_SESSION['session_Setting_BG_IMAGE']; ?>);
			<?php }?>
		}
		body {
			background: <?php echo empty($_SESSION['session_Setting_BG_COLOR']) ? "#F3F3F3" : $_SESSION['session_Setting_BG_COLOR']; ?>;
			<?php if (!empty($_SESSION['session_Setting_BG_IMAGE'])) { ?>
				background-image: url(<?php echo $_SESSION['session_Setting_BG_IMAGE']; ?>);
			<?php }?>
		}
		.columns .right {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		.columns .right a:hover {
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ievil .columns {
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ievil .columns .right {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ievil .columns .right a:hover {
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		
		#side .cart li.dish .name {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		    background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .name {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		    background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .price {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .cart_count {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		#side .cart li.dish .delete {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .delete:hover{
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		body.ie6 #side .cart li.dish .delete {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ie6 #side .cart li.dish .delete:hover {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		#cart_fix_hint {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#cart_outer.fixed {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#sidebar_search #profile_section.fixed {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		#side .cart li.restaurant .meta {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#DBEFF8" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		}
		.leihou-author {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		}
		.leihou-ask-answer-timeline {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#C3E3F3" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		}

		.flash_notification.error {
			background:<?php echo empty($_SESSION['session_Setting_ERROR_BG_COLOR']) ? "#F23030" : $_SESSION['session_Setting_ERROR_BG_COLOR']; ?>;
			color:<?php echo empty($_SESSION['session_Setting_ERROR_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_ERROR_TEXT_COLOR']; ?>;
		}
		.flash_notification.info {
			background:<?php echo empty($_SESSION['session_Setting_INFO_BG_COLOR']) ? "#FC9C0F" : $_SESSION['session_Setting_INFO_BG_COLOR']; ?>;
			color:<?php echo empty($_SESSION['session_Setting_INFO_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_INFO_TEXT_COLOR']; ?>;
		}
		.flash_notification.success {
			background:<?php echo empty($_SESSION['session_Setting_SUCCESS_BG_COLOR']) ? "#7ED10E" : $_SESSION['session_Setting_SUCCESS_BG_COLOR']; ?>;
			color:<?php echo empty($_SESSION['session_Setting_SUCCESS_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_SUCCESS_TEXT_COLOR']; ?>;
		}
	</style>
	<script src="js/remove_unicom.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.z.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/header_menu.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/lib.json2.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/settings.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/notifications.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/counter.js" type="text/javascript" charset="utf-8"></script>
	</head>
<body id="signup" class="<?php echo get_client_browser_type(); ?>">
<div id="prototypes" style="display:none">
</div>
<div id="container" class="<?php echo get_client_browser_type(); ?>">
	<div id="header-outer">
		<div id="header">
			<h3 class="offscreen">页首</h3>
			<h1>
				<a href="index.php" id="logo">
					<img src="<?php echo empty($_SESSION['session_Setting_LOGO_IMAGE']) ? "images/logo.png" : $_SESSION['session_Setting_LOGO_IMAGE'];?>" alt="<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> - 附近的外卖详细菜单"/>
				</a>
			</h1>
			<?php include 'city_header.php' ?>
			<?php include 'top_nav.php' ?>
			<div class="bookmark"></div>
		</div>
	</div>
	<div id="notifications"><?php echo last_notification(); ?></div>
