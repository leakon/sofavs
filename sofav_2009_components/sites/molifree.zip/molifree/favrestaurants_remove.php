<?php
require_once("inc/functions.php");
$re = remove_fav_restaurant();
?>
{"ret":<?php echo $re["ret"];?>,"favRestaurantsCount":<?php echo $re["favRestaurantsCount"];?>}