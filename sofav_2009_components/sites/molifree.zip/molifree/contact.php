<?php
require_once 'inc/functions.php';
include 'header_min.php';
?>
<link rel="stylesheet" type="text/css" media="screen" href="css/common.collapsible.css"/>
<link rel="stylesheet" type="text/css" media="screen" href="css/account.form.css"/>
<link rel="stylesheet" type="text/css" media="screen" href="css/ask_answer.css"/>
<link rel="stylesheet" type="text/css" media="screen" href="css/about.css"/>
<style>
	#contact_blocks {
		float:left;
		width:658px;
		margin-left:20px;
	}
	#about_feedback_content {
		float:right;
		margin-right:20px;
		width:210px;
		font-size:12px;
		color:#666;
	}
	#about_feedback_content h3.first {
		margin-top:0;
	}
	#user_contact,
	#press_contact,
	#restaurant_contact,
	#business_contact {
		border-left:10px solid #999;
		background:#f9f9f9;
		width:275px;
		padding:40px 20px 0;
		height:120px;
		margin-bottom:8px;
	}
	#contact_blocks strong {
		display:block;
		font-size:20px;
		margin-top:15px;
		color:#777;
	}
	#user_contact {
		border-left-color:#9de008;
		margin-right:10px;
	}
	#restaurant_contact {
		border-left-color:#f23070;
		float:right;
	}
	#press_contact {
		border-left-color:#ff900f;
	}
	#business_contact {
		border-left-color:#0f91cf;
		float:right;
	}
</style>
<script src="js/jquery.cookie.js" type="text/javascript" charset="utf-8"></script>
<script src="js/jquery.isCollapsibleMenu.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
document.title = "<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> / 联系<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>";
</script>

<div class="columns wide">
<div class="inner_columns">
<div class="left">
	<div id="content">
		<div id="about_feedback_title" class="title">
			<h2>联系<?php echo $_SESSION['session_Setting_SITE_NAME']; ?></h2>
		</div>
		<div id="contact_blocks">
			<div id="restaurant_contact">
				如果您来自餐厅，我们可以免费帮您把店铺加入<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>，请联系：
				<strong><?php echo empty($_SESSION['session_Setting_RESTAURANT_CONTACT_EMAIL']) && empty($_SESSION['session_Setting_RESTAURANT_CONTACT_PHONE']) ? "请在后台设置邮箱地址或电话" : $_SESSION['session_Setting_RESTAURANT_CONTACT_EMAIL'];?></strong>
				<strong><?php echo $_SESSION['session_Setting_RESTAURANT_CONTACT_PHONE'];?></strong>
			</div>
	
			<div id="user_contact">
				如果您是<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>用户，在使用过程中遇到任何问题，可以直接：
				<strong><a href="support.php">在线提交给我们</a></strong>
			</div>
			<div id="business_contact">
				如果您希望和<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>洽谈商业合作或其它商务事宜，请联系：
				<strong><?php echo empty($_SESSION['session_Setting_BUSINESS_CONTACT_EMAIL']) && empty($_SESSION['session_Setting_BUSINESS_CONTACT_PHONE']) ? "请在后台设置邮箱地址或电话" : $_SESSION['session_Setting_BUSINESS_CONTACT_EMAIL'];?></strong>
				<strong><?php echo $_SESSION['session_Setting_BUSINESS_CONTACT_PHONE'];?></strong>
			</div>
			<div id="press_contact">
				如果您来自媒体，需要了解<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>更进一步的信息，请联系：
				<strong><?php echo empty($_SESSION['session_Setting_PRESS_CONTACT_EMAIL']) && empty($_SESSION['session_Setting_PRESS_CONTACT_PHONE']) ? "请在后台设置邮箱地址或电话" : $_SESSION['session_Setting_PRESS_CONTACT_EMAIL'];?></strong>
				<strong><?php echo $_SESSION['session_Setting_PRESS_CONTACT_PHONE'];?></strong>
			</div>
		</div>
		<div id="about_feedback_content">
			<div id="about_us_side">
				<h3 class="first">关于我们</h3>
				放下一摞外卖单，打开<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>首页。<br/>是的，实际上您只需要这一页，定制属于您自己的丰富餐厅，点餐变得简单。
			</div>
	
			<div><h3>订单协助</h3>如果您的订单遇到问题需要协助，请拨打： 4000059427转 888 ，我们的客服人员会为您提供帮助（客服电话的工作时间是周一至周五10:00-19:00）</div>
			<div><h3>更有效地联络</h3>我们建议您通过左侧列出的在线反馈表单和特别准备的Email提交反馈，这样我们能够将反馈准确送达最能够帮您解决问题的人。</div>
		</div>
		<div class="clear"></div>
	</div>
</div>
</div>
</div>

<?php include 'footer.php' ?>
