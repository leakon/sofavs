<?php
include_once 'inc/functions.php';
if($_POST['lipin']=='lipin'){
	//{'lipin':'lipin','pageNo':pageNo,'pageSize':pageSize,'totalCount':totalCount}
	$pageNo=$_POST['pageNo'];
	$pageSize=$_POST['pageSize'];
	$totalCount=$_POST['totalCount'];
	$start=($pageNo-1)*$pageSize;
	$list= lipinList($start,$pageSize);
	$json="{'success':'ok','pageNo':'{$pageNo}','pageSize':'{$pageSize}','list':[";
	$index=0;
	foreach($list as $k=>$v){
		if($index==0){
			$json.="{'id':'{$v['lipinId']}','name':'{$v['name']}','imgPath':'{$v['imgPath']}','score':'{$v['score']}','lipinCount':'{$v['linpinCount']}','description':'{$v['description']}'}";
		}else{
			$json.=",{'id':'{$v['lipinId']}','name':'{$v['name']}','imgPath':'{$v['imgPath']}','score':'{$v['score']}','lipinCount':'{$v['linpinCount']}','description':'{$v['description']}'}";
		}
		$index++;
	}
	$json.="]}";
	echo $json;
}
?>