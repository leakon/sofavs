<?php
require_once 'inc/functions.php';
$re = get_restaurant();
$restaurant = $re['restaurant'];
$added = $re['added'];
$dishes = $re['dishes'];
$sections = $re['sections'];
$sectiontext = $re['sectiontext'];
$nearbys = get_nearby_restaurant($restaurant['Latitude'], $restaurant['Longitude']);
?>
<!DOCTYPE html>
<html lang="zh">
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
	<meta content="zh" http-equiv="Content-Language"/>
	<meta content="no" http-equiv="imagetoolbar"/>
	<meta content="width=990" name="viewport"/>
	<meta http-equiv="X-UA-Compatible" content="chrome=1" />
	<meta name="robots" content="index,follow"/>
	<meta name="description" content="<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>提供 <?php echo $restaurant['Name']; ?> 的详细外卖菜单、网上订餐服务、到店消费优惠服务。<?php echo $restaurant['City']; ?><?php echo $restaurant['Region']; ?>。<?php echo $restaurant['BusinessHour']; ?>送餐 / <?php echo $restaurant['BusinessMemo'];?>/起送金额<?php echo ($restaurant['MinMoney']+0);?>元 <?php echo $sectiontext; ?>"/>
	<meta name="keywords" content="<?php echo $restaurant['Name'];?>,<?php echo $restaurant['Telephone']; ?>,<?php echo $restaurant['Keyword']; ?>" />
	<title><?php echo $restaurant['Name'];?>_网上订餐_外卖菜单_到店优惠消费_<?php echo $_SESSION['session_Setting_SITE_NAME']; ?>_互联网上最全的外卖信息</title>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.footer.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.header.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/main.body.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/notifications.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/common.collapsible.css"/>

	<link rel="stylesheet" type="text/css" media="screen" href="css/restaurant_list.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/restaurant_list.dishes.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/hero_dishes.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/restaurants.show.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/restaurants.show.share_all.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/cart.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/ask_answer.css"/>
	<link rel="stylesheet" type="text/css" media="screen" href="css/meican400hint.css"/>
	<style type="text/css">
		html {
			background: <?php echo empty($_SESSION['session_Setting_BG_COLOR']) ? "#F3F3F3" : $_SESSION['session_Setting_BG_COLOR']; ?>;
			<?php if (!empty($_SESSION['session_Setting_BG_IMAGE'])) { ?>
				background-image: url(<?php echo $_SESSION['session_Setting_BG_IMAGE']; ?>);
			<?php }?>
		}
		body {
			background: <?php echo empty($_SESSION['session_Setting_BG_COLOR']) ? "#F3F3F3" : $_SESSION['session_Setting_BG_COLOR']; ?>;
			<?php if (!empty($_SESSION['session_Setting_BG_IMAGE'])) { ?>
				background-image: url(<?php echo $_SESSION['session_Setting_BG_IMAGE']; ?>);
			<?php }?>
		}
		.columns .right {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		.columns .right a:hover {
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ievil .columns {
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ievil .columns .right {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ievil .columns .right a:hover {
			background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		
		#side .cart li.dish .name {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		    background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .name {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		    background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .price {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .cart_count {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		#side .cart li.dish .delete {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#side .cart li.dish .delete:hover{
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		body.ie6 #side .cart li.dish .delete {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		body.ie6 #side .cart li.dish .delete:hover {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		#cart_fix_hint {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#cart_outer.fixed {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		
		#sidebar_search #profile_section.fixed {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
    		background-color: <?php echo empty($_SESSION['session_Setting_RIGHT_BG_COLOR']) ? "#0F91CF" : $_SESSION['session_Setting_RIGHT_BG_COLOR']; ?>;
		}
		#side .cart li.restaurant .meta {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#DBEFF8" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		}
		.leihou-author {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		}
		.leihou-ask-answer-timeline {
			color: <?php echo empty($_SESSION['session_Setting_RIGHT_TEXT_COLOR']) ? "#C3E3F3" : $_SESSION['session_Setting_RIGHT_TEXT_COLOR']; ?>;
		}

		.flash_notification.error {
			background:<?php echo empty($_SESSION['session_Setting_ERROR_BG_COLOR']) ? "#F23030" : $_SESSION['session_Setting_ERROR_BG_COLOR']; ?>;
			color:<?php echo empty($_SESSION['session_Setting_ERROR_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_ERROR_TEXT_COLOR']; ?>;
		}
		.flash_notification.info {
			background:<?php echo empty($_SESSION['session_Setting_INFO_BG_COLOR']) ? "#FC9C0F" : $_SESSION['session_Setting_INFO_BG_COLOR']; ?>;
			color:<?php echo empty($_SESSION['session_Setting_INFO_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_INFO_TEXT_COLOR']; ?>;
		}
		.flash_notification.success {
			background:<?php echo empty($_SESSION['session_Setting_SUCCESS_BG_COLOR']) ? "#7ED10E" : $_SESSION['session_Setting_SUCCESS_BG_COLOR']; ?>;
			color:<?php echo empty($_SESSION['session_Setting_SUCCESS_TEXT_COLOR']) ? "#FFFFFF" : $_SESSION['session_Setting_SUCCESS_TEXT_COLOR']; ?>;
		}
	</style>
	<script src="js/remove_unicom.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.z.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/header_menu.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/lib.json2.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/settings.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/notifications.js" type="text/javascript" charset="utf-8"></script>

	<script src="js/counter.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.map.async.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.cookie.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.isCollapsibleMenu.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/cart.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/fav_restaurants.add_delete.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/restaurants.show.map.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/restaurants.show.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.simplemodal.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/meican400hint.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/map.loader.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/common.feedback_box.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/restaurant.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/index.js" type="text/javascript" charset="utf-8"></script>
</head>

<body id="restaurant" class="<?php echo get_client_browser_type(); ?>">
	<div id="prototypes" style="display:none">
	</div>
	
	<div id="container" class="<?php echo get_client_browser_type(); ?>">
		<div id="header-outer">
			<div id="header">
				<h3 class="offscreen">页首</h3>
				<h1>
					<a href="index.php" id="logo">
						<img src="images/logo.png" alt="<?php echo $_SESSION['session_Setting_SITE_NAME']; ?> - 附近的外卖详细菜单"/>
					</a>
				</h1>
				
				<?php include 'city_header.php'; ?>
								
				<?php include 'top_nav.php'; ?>
				
				<div class="bookmark"></div>
			</div>
		</div>
	</div><!--container-->
	
	<div id="notifications">
	</div>
	<div class="columns">
		<div class="inner_columns">
			<div class="left">
				<div id="content">
					<!--
					<div itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="breadcrumb">
						<a href="index.php" itemprop="url">
							<span itemprop="title">首页</span>
						</a>
						&rsaquo;
						<div itemprop="child" itemscope itemtype="http://data-vocabulary.org/Breadcrumb">
							<a href="citylist.php?cityid=<?php echo  $restaurant['CityId']; ?>" itemprop="url">
								<span itemprop="title"><?php echo $restaurant['City'] ?>餐馆</span>
							</a>
							&rsaquo;
							<div itemprop="child" itemscope itemtype="http://data-vocabulary.org/Breadcrumb">
								<a href="regionlist.php?regionid=<?php echo $restaurant['RegionID']; ?>" itemprop="url">
									<span itemprop="title"><?php echo $restaurant['Region']; ?></span>
								</a>
							</div>
						</div>
					</div>
					
					<!-- 餐馆的ul开始 -->

<ul class="restaurant_list not_index">
<li id="restaurant<?php echo $restaurant['ID']; ?>" class="restaurant<?php echo $restaurant['ID']; ?> restaurant rate<?php echo $restaurant['Rating']; ?> no_discount" data-id="<?php echo $restaurant['ID']; ?>" data-name="<?php echo $restaurant['Name']; ?>" data-tel="<?php echo $restaurant['Telephone']; ?>"  data-takeout="<?php echo $restaurant['Takeout']; ?>" data-deny_order="false" itemscope itemtype="http://schema.org/Restaurant">
	<div class="meta rate<?php echo $restaurant['Rating']; ?> no_discount <?php echo empty($added) ? "" : "added";?>">
		<meta itemprop="menu" content="restaurant.php?uuid=<?php echo $restaurant['UUID']; ?>" />
		<meta itemprop="maps" content="restaurant.php?uuid=<?php echo $restaurant['UUID']; ?>" />
		<meta itemprop="telephone" content="<?php echo $restaurant['Telephone']; ?>" />
		<a name="restaurant<?php echo $restaurant['ID']; ?>" class="bm">&nbsp;</a>
		<h1 class="name">
			<a class="value" href="restaurant.php?uuid=<?php echo $restaurant['UUID']; ?>" itemprop="name">
				<?php echo $restaurant['Name']; ?>
			</a>
		</h1>
		
		<div class="tel">
			<?php echo $restaurant['Telephone']; ?>
			<!-- <a class="tel_q_icon" href="javascript:void(0)"></a> -->
		</div>
		
		<div class="actions">
			<a rel="nofollow" href="favrestaurants_add.php?id=<?php echo $restaurant['ID'];?>" id="add_id_<?php echo $restaurant['ID'];?>" class="btn fav-add">加到首页</a>
			<a rel="nofollow" href="favrestaurants_remove.php?id=<?php echo $restaurant['ID'];?>" id="rm_id_<?php echo $restaurant['ID'];?>" class="btn delete fav-remove">移出首页</a>
			<span class="timestamp">
				<?php echo get_last_update_text($restaurant['LastUpdate']); ?>前更新
			</span>
		</div>
	</div>
	
	<div class="restaurant_rate rate<?php $restaurant['Rating']; ?> no_discount">
		<span class="icon" itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
			<meta itemprop="ratingValue" content="<?php $restaurant['Rating']; ?>"/>
			<meta itemprop="bestRating" content="3"/>
			<meta itemprop="worstRating" content="1"/>
		</span>
		<span class="words">送餐时间：<?php echo $restaurant['BusinessHour']; ?> 
		/ <?php echo $restaurant['BusinessMemo']; ?> 
		/ 起送金额<?php echo ($restaurant['MinMoney']+0); ?>元
		<?php echo ($restaurant['Takeout']=='支持' ? '' : ' / 该餐厅不支持送餐上门'); ?>
		</span>
	</div>
	
	<ul class="dishes">
	<?php
	$current_section = '';
	foreach($dishes as $dish) {
		 if($dish['Section']!=$current_section) {
		 	$current_section = $dish['Section'];
	?>
			<li class="dish is-section">
				<a class="bm" name="section<?php echo $dish['SectionID']; ?>">&nbsp;</a>
				<span class="name"><?php echo $dish['Section']; ?></span>
				<a class="back_top" href="#top">TOP</a>
			</li>
		<?php }
			//添加图片
		 	$imgInfo=getDishImgByDishId($dish['ID']);
			$path=empty($imgInfo['imgPath'])?'dishimg/nopic.gif':$imgInfo['imgPath'];
		?>
			<li id="dish<?php echo $dish['ID'];  ?>" class="dish dish<?php echo $dish['ID'];?>" dishimg="<?php echo $path;?>" data-id="<?php echo $dish['ID'];  ?>" data-name="<?php echo $dish['Name'];  ?>" data-price="<?php echo ($dish['Price']+0);  ?>">
				<span class="name"><?php echo $dish['Name']; ?></span>
				<span class="price_outer">
					<span class="price"><?php echo ($dish['Price']+0); ?></span>
				</span>
				<a class="cart_count"></a>
			</li>
	<?php } ?>
	</ul>
</li>
</ul>
					<!-- 餐馆的ul结束-->

					
				</div><!-- content -->
			</div><!-- left -->
			
			<div class="right">
				<div id="side">
					<!--餐厅基本信息-->
					<div id="restaurant_basic_info">
						<h2>餐厅基本信息 </h2>
						<table class="restaurant_info_all">
							<tr class="restaurant_info_item">
								<th>外卖时间</th>
								<td><?php echo (isset($restaurant['BusinessHour']) ? $restaurant['BusinessHour'] : '-' );?></td>
							</tr>
							<tr class="restaurant_info_item unknown">
								<th>送餐费用</th>
								<td><?php echo (isset($restaurant['Fee']) ? ($restaurant['Fee']+0).'元' : '-' );?></td>
							</tr>
							<tr class="restaurant_info_item">
								<th>起送金额</th>
								<td><?php echo (isset($restaurant['MinMoney']) ? ($restaurant['MinMoney']+0).'元' : '-' );?></td>
							</tr>
							<tr class="restaurant_info_item">
								<th>送餐范围</th>
								<td>正常周边(<?php echo (isset($restaurant['Scope']) ? $restaurant['Scope'] : '500' );?>米)</td>
							</tr>
							<tr class="restaurant_info_item">
								<th>送餐上门</th>
								<td><?php echo $restaurant['Takeout'];?></td>
							</tr>
							<tr class="restaurant_info_item">
								<th>到店消费</th>
								<td><?php echo ($restaurant['DiscountIn']+0==0 || $restaurant['DiscountIn']+0==10) ? "-" : ($restaurant['DiscountIn']+0)."折";?></td>
							</tr>
							<tr class="restaurant_info_item">
								<th>优惠信息</th>
								<td>
									<?php echo $restaurant['SaleAd'];?>
								</td>
							</tr>
						</table>
					</div><!--restaurant_basic_info-->
					
					<!--在线订餐-->
					<a name="cart" class="bm">&nbsp;</a>
					<div id="cart_inflater">
						<div id="cart_outer" class="noncollapsible empty denied noorder">
							<h2 class="sidebar_title">
								<span>在线订餐</span>
							</h2>
							<ul class="cart" id="cart_unique"><li></li></ul>
							<div id="cart_empty_hint">
								(点击左侧的餐品，然后这里下单，外卖自动上门啦)
							</div>
							<div id="order_controls">
								<a id="cart_clear" class="btn" href="javascript:void(0)" rel="nofollow">清空</a>
								<a id="cart_submit" class="btn" href="orders_create.php" rel="nofollow">送餐上门</a>
								<a id="in_submit" class="btn" href="orders_in.php" rel="nofollow">到店消费</a>
								<a id="cart_view" class="btn" href="orders_myactive.php" rel="nofollow">查看订单</a>
							</div>
							<div style="display:none" id="cart_json"><?php echo get_cart_json() ?></div>
						</div>
						<div id="cart_fix_hint" style="display:none;">
							<a href="#cart" rel="nofollow">&uarr; 查看您的点餐单</a>
						</div>
					</div>
					
					
					<div class="cart_encourage">
						<h3>还是不太敢在线订餐？</h3>
						<p>别担心，你的订单会立刻得到处理，外卖进度还会实时反馈给你。很多人已经用上瘾了，你也试一次吧。</p>
					</div>
					
					<!--地图-->
					<div id="map_box">
						<h2 class="sidebar_title"><span>地图</span></h2>
						<div class="sidebar_menu">
							<div id="map_canvas"></div>
						</div>
						<form style="display:none">
							<input type="hidden" id="center_latitude" value="<?php echo $restaurant['Latitude']; ?>"/>
							<input type="hidden" id="center_longitude" value="<?php echo $restaurant['Longitude']; ?>"/>
							<input type="hidden" id="restaurant_radius" value="<?php echo empty($restaurant['Scope']) ? "500" : ($restaurant['Scope']+0); ?>"/>
						</form>
					</div>
					
					<!-- 附近还有 -->
					<h3 id="nearby_restaurants_title">附近还有这些外卖：</h3>
					<ul id="nearby_restaurants">
					<?php foreach($nearbys as $nearby) { ?>
						<li><a target="_blank" title="<?php echo $nearby['Name']; ?>的外卖菜单" href="restaurant.php?uuid=<?php echo $nearby['UUID']; ?>"><?php echo $nearby['Name']; ?></a></li>
					<?php } ?>
					</ul>
					
					<!-- 答疑
					<div id="feedback_box" class="collapsible last">
						<h2 id="askanswer_menu" class="sidebar_title"><span>对这家餐厅有疑问?</span></h2>
						<div class="sidebar_menu">
							<div class="leihou-ask-answer-form">
								<form class="support_form leihou-post-form" action="/support/newsupportmessage" method="post">
									<input type="hidden" value="1431" name="restaurantId" />
									<div class="leihou-post-content">
										<textarea id="ask_answer_content" class="text content leihou-status-box" name="content"></textarea>
									</div>
									<div id="email_input">
										<div>
											<label for="ask_answer_email">您的Email：</label>
										</div>
										<div class="ask_answer_email">
											<input type="text" id="ask_answer_email"class="text content leihou-status-box" name="email" />
										</div>
									</div>
									<div class="leihou-post-controls">
										<input style="height:22px" type="submit" value="好了，提交" class="btn" />
									</div>
								</form>
							</div>
							<ul>
							</ul>
							<div class="leihou-page-controls">
								<a class="more-button" href="/support/getmoresupportmessage?limit=10&from=10" rel="nofollow">下10条</a>
							</div>
						</div>
					</div>
					 -->
					<!--400电话疑问（在点电话后面的问号时显示）-->
					<div id="meican_400_hint" style="display:none;">
						<h2>对 4006-166-555 有疑问？</h2>
						<h3>Q: 谁会接听电话？</h3>
						<p>A: 您的电话将由餐厅直接接听，和您以往电话订餐的体验完全一致。</p>
						<h3>Q: 电话费如何计算？</h3>
						<p>A: 无论你在哪座城市，电话均为正常市话，请放心。</p>
					</div>
					
				</div><!--side-->
			</div><!--right-->
		</div><!--inner_columns-->
	</div><!--columns-->
	
	<div id="footer-outer">
		<div id="footer" class="round">
			<h3 class="offscreen">页尾</h3> <div id="copyright"><span>&copy;&nbsp;2012 <?php echo $_SESSION['session_Setting_SITE_NAME']; ?></span></div>
			<ul>
				<li><a href="help.php">用户帮助</a></li>
				<li><a href="contact.php">联系<?php echo $_SESSION['session_Setting_SITE_NAME']; ?></a></li>
				<li><a href="corps/about.php">企业订餐</a></li>
				<li><a href="about_us.php">关于我们</a></li>
			</ul>
		</div>
	</div>
</div>
<div id="show_img" style="top:1px;left:1px;position:absolute;display:none;"><div id="zhanwei_shang"></div><div id="zhanwei_left"></div><img src=""></div>
<div id="map_scripts" data-src="http://maps.google.com/maps/api/js?libraries=places&sensor=false&language=zh&region=CN&callback=googleMapsDidLoad"></div>
</body>
</html>