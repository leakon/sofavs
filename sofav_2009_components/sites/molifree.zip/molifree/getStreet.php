<?php
include_once 'inc/functions.php';
if($_POST['action']=='get'){
	$list=getStreetByRegionId($_POST['regionId']);
	$i=0;
	$j= json_encode($list);
	echo $j;
}