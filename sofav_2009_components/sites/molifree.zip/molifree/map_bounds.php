<?php
header('Content-type: application/json;charset=utf-8');
header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
header('Expires: Thu, 01 Dec 1994 16:00:00 GMT');//一个过去的时间
header('Pragma: no-cache');
require_once("inc/functions.php");

echo map_bounds();

?>
