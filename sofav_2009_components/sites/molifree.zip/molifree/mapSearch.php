<?php
include_once 'inc/functions.php';
if($_POST['action']=='map'){
	$theValue=$_POST['theValue'];//传递过来的值
	if(empty($theValue)){
		echo '{"restaurants":[]}';
		return ;
	}
	$sql="select * from restaurant where CityId=".$_POST['cityId'];
	
	$db=dao();
	$result=$db->query($sql);
	echo $db->error;
	$resJson='{"restaurants":[';
	$index=0;
	while($row=$result->fetch_assoc()){
		$resLength= mb_strlen ($row['Name'],'utf-8');
		$valueLenth=mb_strlen ($theValue,'utf-8');
		$flag=true;
		if($resLength>=$valueLenth){//数据库中长度>=传递字符长度
			for($i=0;$i<$valueLenth;$i++){
				$res= mb_substr($row['Name'],$i*3 ,3);//逐步取得参观名称的每个字符
				$val= mb_substr($theValue,$i ,1);//逐步取得 传递过来的 字符的 每个字符
				$firstRes=getfirstchar(utf8Substr($res,0,1));  //分别取出他们的 首字母
				$firstValue=getfirstchar(utf8Substr($val,0,1));
				if($firstRes!=$firstValue){//首字母不相同，就变成false，不通过
					$flag=false;
				}else{
					$flag=true;
				}
			}
		}else{//数据库中长度<传递字符长度
			for($i=0;$i<$resLength;$i++){
				$res= mb_substr($row['Name'],$i ,1);//逐步取得参观名称的每个字符
				$val= mb_substr($theValue,$i ,1);//逐步取得 传递过来的 字符的 每个字符
				$firstRes=getfirstchar(utf8Substr($res,0,1));  //分别取出他们的 首字母
				$firstValue=getfirstchar(utf8Substr($val,0,1));
				if($firstRes!=$firstValue){//首字母不相同，就变成false，不通过
					$flag=false;
				}else{
					$flag=true;
				}
			}
		}
		if($flag){//首字符都匹配的情况下
			//开始封装数据
			if($index==0){
				$resJson.="{'id':".$row['ID'].",'Name':'".$row['Name']."','lat':'".$row['Latitude']."','lng':'".$row['Longitude']."'}";
			}else{
				$resJson.=",{'id':".$row['ID'].",'Name':'".$row['Name']."','lat':'".$row['Latitude']."','lng':'".$row['Longitude']."'}";
			}
			$index++;
		}
	}
	$resJson.="]}";
	$db->close();
	echo $resJson;	
}elseif($_POST['action']=='start'){
	$theValue=$_POST['theValue'];
	$cityId=$_POST['cityId'];//城市的Id 
	$db=dao();
	$sql="select * from restaurant where  Name like '%".trim($theValue)."%' or City like '%".trim($theValue)."%' or Region like '%".trim($theValue)."%'";
	$result=$db->query($sql);
	$flag=false;
	
	$json='{"restaurant":[';
	$i=0;
	while($row=$result->fetch_assoc()){
		$flag=true;
		$dishes=getTop3DishesByRestaurentId($row['ID']);
		$theHotDish="";//热门 餐品
		$j=0;
		foreach ( $dishes as $key => $value ) {
			if($j==0){
				$theHotDish.="{'dishName':'".$value['Name']."'}";
			}else{
				$theHotDish.=",{'dishName':'".$value['Name']."'}";
			}
			$j++;
		}
		$business=isBusiness($row['ID'])?'1':'0';
		$minMoney=empty($row['MinMoney'])?'0':$row['MinMoney'];
		//封装餐馆信息
		if ($i == 0) {
			$json .= "{'id':{$row['ID']},'minMoney':'{$minMoney}','UUID':'{$row['UUID']}','businessHour':'{$row['BusinessHour']}','rating':'{$row['Rating']}','memo':'{$row['BusinessMemo']}','name':'{$row['Name']}','scope':'{$row['Scope']}','lat':'{$row['Latitude']}','lng':'{$row['Longitude']}','business':'{$business}','hotDishes':[$theHotDish]}";
		} else {
			$json .= ",{'id':{$row['ID']},'minMoney':'{$minMoney}','UUID':'{$row['UUID']}','businessHour':'{$row['BusinessHour']}','rating':'{$row['Rating']}','memo':'{$row['BusinessMemo']}','name':'{$row['Name']}','scope':'{$row['Scope']}','lat':'{$row['Latitude']}','lng':'{$row['Longitude']}','business':'{$business}','hotDishes':[$theHotDish]}";
		}
		$i++;
	}
	if($flag){
		$json.='],"success":"true"';
	}else{
			$json.='],"success":"false"';
	}
	$json.='}';
	echo $json;
	$db->close();
}elseif ($_POST['action']=='end'){
//	$db=dao();
//	$sql="select ID from  region where City like '%".$_POST['theValue']."%' or Name like '%".$_POST['theValue']."%'";
//	$result=$db->query($sql);
//	if($row=$result->fetch_assoc()){
//			echo "{'success':'true','id':".$row['ID']."}";
//	}else{
//		echo "{'success':'false'}";
//	}
//	$db->close();

	$theValue=$_POST['theValue'];
	$db=dao();
	$sql="select * from restaurant where Region like '%".trim($theValue)."%'";
	
	$result=$db->query($sql);
	$flag=false;
	$json='{"restaurant":[';
	$i=0;
	while($row=$result->fetch_assoc()){
		$flag=true;
		$dishes=getTop3DishesByRestaurentId($row['ID']);
		$theHotDish="";//热门 餐品
		$j=0;
		foreach ( $dishes as $key => $value ) {
			if($j==0){
				$theHotDish.="{'dishName':'".$value['Name']."'}";
			}else{
				$theHotDish.=",{'dishName':'".$value['Name']."'}";
			}
			$j++;
		}
		$business=isBusiness($row['ID'])?'1':'0';
		$minMoney=empty($row['MinMoney'])?'0':$row['MinMoney'];
		//封装餐馆信息
		if ($i == 0) {
			$json .= "{'id':{$row['ID']},'minMoney':'{$minMoney}','UUID':'{$row['UUID']}','businessHour':'{$row['BusinessHour']}','rating':'{$row['Rating']}','memo':'{$row['BusinessMemo']}','name':'{$row['Name']}','scope':'{$row['Scope']}','lat':'{$row['Latitude']}','lng':'{$row['Longitude']}','business':'{$business}','hotDishes':[$theHotDish]}";
		} else {
			$json .= ",{'id':{$row['ID']},'minMoney':'{$minMoney}','UUID':'{$row['UUID']}','businessHour':'{$row['BusinessHour']}','rating':'{$row['Rating']}','memo':'{$row['BusinessMemo']}','name':'{$row['Name']}','scope':'{$row['Scope']}','lat':'{$row['Latitude']}','lng':'{$row['Longitude']}','business':'{$business}','hotDishes':[$theHotDish]}";
		}
		$i++;
	}
	if($flag){
		$json.='],"success":"true"';
	}else{
			$json.='],"success":"false"';
	}
	$json.='}';
	echo $json;
	$db->close();
}
?>