<?php
include_once 'inc/config.php';
include_once 'inc/functions.php';
$method = $_POST ['m'];
if (! empty ( $method )) {
	$restaurantId = $_POST ['rid'];
	$flag=isExistInFav($restaurantId);
	$r  = getRestarauntAllInfoById ( $restaurantId );
	$dishes = getDishInfoListByRid ( $restaurantId );
	
	$dishesStr = '';
	$i = 0;
	foreach ( $dishes as $k => $v ) {
		if ($i == 0) {
			$dishesStr .= "{'id':".$v['ID'].",'dishName':'".$v['Name']."','price':'".$v['Price']."'}";
		} else {
			$dishesStr .= ",{'id':".$v['ID'].",'dishName':'".$v['Name']."','price':'".$v['Price']."'}";
		}
		$i ++;
	}
	
	$result = '{"success":"true","flag":"'.($flag?"true":"false").'","restaurant":{"name":"' . $r ['Name'] . '","uuid":"'.$r['UUID'].'","id":"' . $r ['ID'] . '","memo":"' . $r ['Memo'] . '","scope":"' . $r ['Scope'] . '","BusinessHour":"' . $r ['BusinessHour'] . '","BusinessMemo":"' . $r ['BusinessMemo'] . '","MinMoney":"' . $r ['MinMoney'] . '","dishes":[' . $dishesStr . ']}}';
	echo $result;
}