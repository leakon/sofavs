<?php
include_once 'inc/functions.php';
if($_POST['action']=='1'){
	//获取参数
	$maxLng=$_POST['maxLng'];
	$maxLat=$_POST['maxLat'];
	$minLng=$_POST['minLng'];
	$minLat=$_POST['minLat'];

	$list = getRestaurantByBounds($maxLng, $maxLat, $minLng, $minLat);
	if (empty ( $list )) { // 如果是空的话
		echo '{"success":"false"}';
		return;
	}
	$json = '{"success":"true","list":[';
	$i = 0;

	foreach ( $list as $k => $v ) {
		/*循环封装 热门餐品**/
		$hotDishes = getTop3DishesByRestaurentId ($v['ID']);
		$theHotDish="";
		$j=0;
		foreach ( $hotDishes as $key => $value ) {
			if($j==0){
				$theHotDish.="{'dishName':'".$value['Name']."'}";
			}else{
				$theHotDish.=",{'dishName':'".$value['Name']."'}";
			}
			$j++;
		}
		$business=isBusiness($v['ID'])?'1':'0';
		$minMoney=empty($v['MinMoney'])?'0':$v['MinMoney'];
		//封装餐馆信息
		if ($i == 0) {
			$json .= "{'id':{$v['ID']},'minMoney':'{$minMoney}','UUID':'{$v['UUID']}','businessHour':'{$v['BusinessHour']}','rating':'{$v['Rating']}','memo':'{$v['BusinessMemo']}','name':'{$v['Name']}','scope':'{$v['Scope']}','lat':'{$v['Latitude']}','lng':'{$v['Longitude']}','business':'{$business}','hotDishes':[$theHotDish]}";
		} else {
			$json .= ",{'id':{$v['ID']},'minMoney':'{$minMoney}','UUID':'{$v['UUID']}','businessHour':'{$v['BusinessHour']}','rating':'{$v['Rating']}','memo':'{$v['BusinessMemo']}','name':'{$v['Name']}','scope':'{$v['Scope']}','lat':'{$v['Latitude']}','lng':'{$v['Longitude']}','business':'{$business}','hotDishes':[$theHotDish]}";
		}
		$i++;
	}
	$json .= ']}';
	echo $json;
}
?>