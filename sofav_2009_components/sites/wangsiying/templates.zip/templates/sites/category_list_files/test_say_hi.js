(function() {
//    alert('test_say_hi');
})();