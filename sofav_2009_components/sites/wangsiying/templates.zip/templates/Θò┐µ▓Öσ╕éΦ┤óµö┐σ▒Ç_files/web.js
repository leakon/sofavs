// JavaScript Document
// JavaScript Document
var tabs={
	change:function(ItemNo,countNum,changeItemNo,channgeClass){			
		for(i=1;i<=countNum;i++){
			if(changeItemNo==i){
				this.getObject("table_"+ItemNo+i).style.display = "";
				if(channgeClass){					
						this.getObject("td_"+ItemNo+i).className = channgeClass.c1;
				}
				
				if(this.getObject("morehref_"+ItemNo)){
					this.getObject("morehref_"+ItemNo).href=this.getObject("tablehref_"+ItemNo+i).href;
					//alert(this.getObject("tablehref_"+ItemNo+i).href);
				}
			}else{
				this.getObject("table_"+ItemNo+i).style.display = "none";
				if(channgeClass){					
					this.getObject("td_"+ItemNo+i).className = channgeClass.c2;
				}
			}
		}
	},
	getObject:function(objectId){
		if(document.getElementById && document.getElementById(objectId)){
			 return document.getElementById(objectId);
		}else if (document.all && document.all(objectId)){
			return document.all(objectId);
		}else if (document.layers && document.layers[objectId]){
			return document.layers[objectId];
		}else{
			return false;
		}
	}
};