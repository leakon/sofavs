based on jQuery-File-Upload-8.8.2
all dependent files is saved to local
