Contents of Kendo UI zip file distribution:

/examples - Kendo UI quick start demos
/js - Kendo UI minified javascript files
/source - Kendo UI complete source code
/styles - Kendo UI minified css styles
