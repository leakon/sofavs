<?php
 global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
}
?>
		</div><!-- / #main -->
	</div><!-- / #inner-wrap -->
	
	<div id="footer">
		<div class="widgets">
            
				<div class="column">
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer: Column 1') ) : ?> <?php endif; ?>
				</div><!-- / .column -->
				
				<div class="column">
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer: Column 2') ) : ?> <?php endif; ?>
				</div><!-- / .column -->
				
				<div class="column">
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer: Column 3') ) : ?> <?php endif; ?>
				</div><!-- / .column -->
				
				<div class="column last">
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer: Column 4') ) : ?> <?php endif; ?>
				</div><!-- / .column -->
				
				<div class="cleaner">&nbsp;</div>
            </div>
            <div class="copyright">
				<div class="left"><p class="copy"><?php _e('Copyright', 'wpzoom'); ?> &copy; <?php echo date("Y",time()); ?> <?php bloginfo('name'); ?>. <?php _e('All Rights Reserved', 'wpzoom'); ?>.</p></div>
				<div class="right"><p class="wpzoom"><a href="http://www.wpzoom.com" target="_blank" title="Portfolio Themes"><img src="<?php bloginfo('template_directory'); ?>/images/wpzoom.png" alt="WPZOOM" /></a> <a href="http://www.wpzoom.com" target="_blank"><?php _e('Portfolio Theme', 'wpzoom'); ?></a> <?php _e('by', 'wpzoom'); ?></p></div>

            </div>
		 
	</div><!-- / #footer -->
</div><!-- / #wrapper -->

<?php if ($wpzoom_misc_analytics != '' && $wpzoom_misc_analytics_select == 'Yes')
{
  echo stripslashes($wpzoom_misc_analytics);
} ?> 

<script type="text/javascript">
jQuery(document).ready(function() {
	
	<?php if (is_home() && $wpzoom_featured_posts_show == 'Yes') { ?>
	jQuery('#slides').css({ display : 'block' });
	jQuery("#slides").slides({
		play: <?php if ($wpzoom_slideshow_auto == 'Yes') { echo "$wpzoom_slideshow_speed"; }  if ($wpzoom_slideshow_auto == 'No') { ?>0<?php } ?>,
		width: 910,
		generatePagination: false,
 		pause: 1000,
 		effect: '<?php if ($wpzoom_slideshow_effect == 'Slide') { ?>slide<?php } else { ?>fade<?php } ?>',
 		autoHeight: true,
		hoverPause: true
	});	
	<?php } ?>
	
	<?php if (get_post_type() == 'portfolio') { ?>
	jQuery('#portfolio-slider').css({ display : 'block' });
	jQuery("#portfolio-slider").slides({
		play: 0,
		width: 630,
		generatePagination: false,
 		pause: 1000,
 		effect: 'slide',
 		autoHeight: true,
		hoverPause: true
	});	
	<?php } ?>
 
});
</script>

<?php wp_footer(); ?>
</body>
</html>