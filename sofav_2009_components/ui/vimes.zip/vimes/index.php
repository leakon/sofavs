<?php
global $options;

foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
}
?>

<?php get_header(); ?>
	
<?php 
	if ($wpzoom_featured_posts_show == 'Yes' && is_home() && $paged < 2) { 
		include(TEMPLATEPATH . '/wpzoom_featured_posts.php'); 
	} // Show the Featured Slider ?>
	
<?php if ($wpzoom_intro == 'Yes') { ?>
	<div id="heading">
		<?php if ($wpzoom_intro_url != '') { echo "<a href=".$wpzoom_intro_url." class=\"action\"><span>".$wpzoom_intro_btn."</span></a>"; } ?>
		<h2><?php echo $wpzoom_intro_title; ?></h2>
		<p><?php echo stripslashes($wpzoom_intro_content); ?></p>
		<div class="clear"></div>
	</div><!-- / #welcome -->
<?php } ?>
  

<?php if ($wpzoom_portfolio == 'Yes') { ?>
	<div id="portfolio">
		<?php if ($wpzoom_portfolio_title != '') { ?><h3 class="title"><a href="<?php bloginfo('url'); ?>/portfolio/"><?php _e('View all projects', 'wpzoom'); ?> &rarr;</a><span><?php echo $wpzoom_portfolio_title; ?></span></h3><?php } ?>
		
		<ul>
			<?php $query = new WP_Query(); 
				$query->query('post_type=portfolio&posts_per_page='.$wpzoom_portfolio_items.''); 
				if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
				$terms = get_the_terms( get_the_ID(), 'skill-type' );  ?> 
		
			<li>
				<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php printf(__('Permanent Link to %s', 'wpzoom'), get_the_title()); ?>">   
					<?php unset($img); if ( current_theme_supports( 'post-thumbnails' ) && has_post_thumbnail() ) {
					$thumbURL = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), '' );
					$img = $thumbURL[0];  }
					else  {
						if (!$img) { $img = catch_that_image($post->ID);  }
						}  
					if ($img){ $img = wpzoom_wpmu($img); ?>
					<img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $img ?>&amp;w=285&amp;h=190&amp;zc=1" alt="<?php the_title(); ?>"/><?php } ?>
					<span class="ext">
						<span class="p"><?php _e('View project', 'wpzoom'); ?></span>
					</span>
				</a>
				
				<div class="meta">
					<h3><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php printf(__('Permanent Link to %s', 'wpzoom'), get_the_title()); ?>">  <?php the_title(); ?></a></h3>
					<?php if (is_array($terms)) { foreach ($terms as $term) :  ?>
					<?php echo $term->name; ?> 
					<?php endforeach; } ?>
				</div>
			</li>
			<?php endwhile; endif; ?>
				
			<?php wp_reset_query(); ?>
		</ul>
	</div><!-- / #portfolio -->
	<div class="clear"></div>
<?php } ?>


<div class="home_widgets">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage Widgets') ) : ?> <?php endif; ?>
</div>

<?php get_footer(); ?>
