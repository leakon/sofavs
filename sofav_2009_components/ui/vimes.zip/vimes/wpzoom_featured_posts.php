<div id="featured">
	 <div id="slides">
	 
		<a class="prev browse">prev</a>
		<a class="next browse">next</a>

		<?php $loop = new WP_Query( array( 'post_type' => 'slideshow', 'posts_per_page' => $wpzoom_featured_posts_posts ) ); ?>
		
		<div class="slides_container">
		<?php while ( $loop->have_posts() ) : $loop->the_post();  ?>

			<div class="slide">
				<?php  
					$url = get_post_meta(get_the_ID(), 'wpzoom_slideshow_url', true);

					unset($img); 
					if ( current_theme_supports( 'post-thumbnails' ) && has_post_thumbnail() ) {
					$thumbURL = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), '' );
					$img = $thumbURL[0]; }
					if ($img) { $img = wpzoom_wpmu($img);  ?>
					<?php if ($url != '') { ?><a href="<?php echo $url; ?>" rel="bookmark" title="<?php the_title(); ?>"><?php } ?><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $img ?>&amp;w=910&amp;h=350&amp;zc=1" alt="<?php the_title(); ?>" width="910" height="350" /><?php if ($url != '') { ?></a><?php } ?>
					<?php }  ?>
			</div> 
		<?php endwhile; ?>
		</div>
	</div>
 
 </div>

<?php wp_reset_query(); ?>