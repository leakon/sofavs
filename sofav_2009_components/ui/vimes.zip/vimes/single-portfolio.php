<?php 
	$overview = get_post_meta(get_the_ID(), 'wpzoom_portfolio_overview', true);
	$client = get_post_meta(get_the_ID(), 'wpzoom_portfolio_client', true);
	$services = get_post_meta(get_the_ID(), 'wpzoom_portfolio_services', true);

	$image1 = get_post_meta(get_the_ID(), 'wpzoom_upload_image', true);
	$image2 = get_post_meta(get_the_ID(), 'wpzoom_upload_image2', true);
	$image3 = get_post_meta(get_the_ID(), 'wpzoom_upload_image3', true);
	$image4 = get_post_meta(get_the_ID(), 'wpzoom_upload_image4', true);
	$image5 = get_post_meta(get_the_ID(), 'wpzoom_upload_image5', true);
?>

<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div id="heading">
	
	<h1><?php the_title(); ?></h1>

</div><!-- /#welcome -->

<div id="content">
	<div class="post_content">
		
		<?php if(get_post_meta(get_the_ID(), 'wpzoom_portfolio_enable_slider', true) == 'yes') : ?>

		<div id="portfolio-slider" class="clearfix">
		
			<div id="portfolio_nav">
				<a class="prev"></a>
				<a class="next"></a>
			</div><!-- / #portfolio_nav-->
			
			<div class="slides_container">
				<?php  
						$height = getimagesize($image1);
						$height = $height[1];
					 ?>
				<?php if($image1 != '') {  $image1 = wpzoom_wpmu($image1); ?><div><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $image1; ?>&amp;w=630&amp;h=<?php echo $height; ?>&amp;zc=1" alt="<?php the_title(); ?>" width="630" height="<?php echo $height; ?>" />  </div> <?php } ?>
				<?php if($image2 != '') {  $image2 = wpzoom_wpmu($image2); ?><div><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $image2; ?>&amp;w=630&amp;zc=1" alt="<?php the_title(); ?>" width="630"  />  </div> <?php } ?>
				<?php if($image3 != '') {  $image3 = wpzoom_wpmu($image3); ?><div><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $image3; ?>&amp;w=630&amp;zc=1" alt="<?php the_title(); ?>" width="630"  />  </div> <?php } ?>
				<?php if($image4 != '') {  $image4 = wpzoom_wpmu($image4); ?><div><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $image4; ?>&amp;w=630&amp;zc=1" alt="<?php the_title(); ?>" width="630"  />  </div> <?php } ?>
				<?php if($image5 != '') {  $image5 = wpzoom_wpmu($image5); ?><div><img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $image5; ?>&amp;w=630&amp;zc=1" alt="<?php the_title(); ?>" width="630"  />  </div> <?php } ?>
				
			</div><!-- /.slides_container -->
			
		</div><!-- /#portfolio-slider -->
		
		<?php endif; ?>
		
		<div class="entry">
			<?php the_content(); ?>
			
			<?php edit_post_link( __('Edit', 'wpzoom'), '', ''); ?>
		 
		</div><!-- /.entry -->
		
	</div><!-- /.post_content -->

	<div class="aside">
		<h3 class="title">
			<?php if($overview != '') { ?><span><?php _e('Overview', 'wpzoom'); ?></span><?php } ?>
			
			<div class="single-nav">
				<?php
				$previous_post = get_previous_post();
				$next_post = get_next_post();
				?>
				<?php if ($previous_post != NULL) { ?> <a href="<?php echo get_permalink($previous_post->ID); ?>" class="prev_project" title="<?php _e('Previous project', 'wpzoom'); ?>"></a> <?php } ?>
				
				<?php if ($next_post != NULL) { ?> <a href="<?php echo get_permalink($next_post->ID); ?>" class="next_project" title="<?php _e('Next Project', 'wpzoom'); ?>"></a> <?php } ?>
					 
			</div>
			<div class="clear"></div>
		</h3>
			
		<?php if($overview != '') { echo nl2br ($overview); } ?>
					
		<?php if($client != '') { ?>
			<h4><?php _e('Client', 'wpzoom'); ?></h4>
			 <?php echo $client; ?>
		<?php } ?>
		
		<?php if($services != '') { ?>
			<h4><?php _e('Services', 'wpzoom'); ?></h4>
			 <?php echo nl2br($services); ?> 
		<?php } ?>
			
	</div><!-- /.aside-->

	<div class="clear"></div>
</div><!-- /#content -->

<?php endwhile; endif; ?>
            
<?php get_footer(); ?>