<?php
/*
Template Name: Portfolio
*/
global $options;
foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
}
?>

<?php get_header(); ?>
	
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div id="heading">
	
	<h2><?php the_title(); ?></h2>

</div><!-- / #welcome -->

<ul id="portfolio-tags" >
	<li class="active"><a class="all" data-value="all" href="#"><?php _e('All', 'wpzoom'); ?></a></li>
	<?php wp_list_categories(array('title_li' => '', 'taxonomy' => 'skill-type', 'walker' => new Walker_Category_Filter())); ?>
</ul>
		  
<?php endwhile; endif; ?>
 
<div class="clear"></div>
 
<div id="portfolio">
	<ul id="portfolio-items" >
		<?php $query = new WP_Query(); $count = 1;
			$query->query('post_type=portfolio&posts_per_page=99'); ?>
			<?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post();
				  $terms = get_the_terms( get_the_ID(), 'skill-type' );  ?> 
		<li data-id="id-<?php echo $count; ?>" class="<?php foreach ($terms as $term) { echo strtolower(preg_replace('/\s+/', '-', $term->name)). ' '; } ?>" >
			<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php printf(__('Permanent Link to %s', 'wpzoom'), get_the_title()); ?>">   
				<?php unset($img); if ( current_theme_supports( 'post-thumbnails' ) && has_post_thumbnail() ) {
					$thumbURL = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), '' );
					$img = $thumbURL[0];  }
					 else {
						unset($img);
						if ($wpzoom_cf_use == 'Yes')   {  $img = get_post_meta($post->ID, $wpzoom_cf_photo, true);   }
					else  {
						if (!$img) { $img = catch_that_image($post->ID);  }
						} }
					if ($img){ $img = wpzoom_wpmu($img); ?>
					<img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $img ?>&amp;w=285&amp;h=190&amp;zc=1" alt="<?php the_title(); ?>"/><?php } ?>
				<span class="ext">
					<span class="p"><?php _e('View Project', 'wpzoom'); ?></span>
				</span>
			</a>
			<div class="meta">
				<h3><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php printf(__('Permanent Link to %s', 'wpzoom'), get_the_title()); ?>">  <?php the_title(); ?></a></h3>
				<?php if (is_array($terms)) { foreach ($terms as $term) :  ?>
				<?php echo $term->name; ?> 
				<?php endforeach; } ?>
			</div>
		</li>
		 <?php $count++; ?>
		<?php endwhile; endif; ?>
			
		<?php wp_reset_query(); ?>
		<div class="clear"></div>
	</ul>
</div><!-- / #portfolio -->

<div class="clear"></div>

<?php get_footer(); ?> 