<?php 

/*-----------------------------------------------------------------------------------*/
/* WPZOOM Custom Widgets															 */
/*-----------------------------------------------------------------------------------*/



/*----------------------------------*/
/* WPZOOM: Social Widget			*/
/*----------------------------------*/

function connectWithMe($args) {

  extract($args);
	$settings = get_option( 'widget_social_connect' );
  
  echo $before_widget;
  echo "$before_title"."$settings[title]"."$after_title";
?>
		<ul class="social">
			<?php if ($settings[ 'email' ] != '') echo"<li><a class=\"email\" href=\"mailto:$settings[email]\" title=\"$settings[email_name]\"></a></li>"; ?>
			<?php if ($settings[ 'twitter' ] != '') echo"<li><a class=\"twitter\" href=\"$settings[twitter]\" title=\"$settings[twitter_name]\"></a></li>"; ?>
			<?php if ($settings[ 'facebook' ] != '') echo"<li><a class=\"facebook\" href=\"$settings[facebook]\" title=\"$settings[facebook_name]\"></a></li>"; ?>
			<?php if ($settings[ 'flickr' ] != '') echo"<li><a class=\"flickr\" href=\"$settings[flickr]\" title=\"$settings[flickr_name]\"></a></li>"; ?>
			<?php if ($settings[ 'dribbble' ] != '') echo"<li><a class=\"dribbble\" href=\"$settings[dribbble]\" title=\"$settings[dribbble_name]\"></a></li>"; ?>
			<?php if ($settings[ 'youtube' ] != '') echo"<li><a class=\"youtube\" href=\"$settings[youtube]\" title=\"$settings[youtube_name]\"></a></li>"; ?>
			<?php if ($settings[ 'vimeo' ] != '') echo"<li><a class=\"vimeo\" href=\"$settings[vimeo]\" title=\"$settings[vimeo_name]\"></a></li>"; ?>
  		</ul>
		<div class="cleaner">&nbsp;</div>
<?php
  echo $after_widget;

}

function connectWithMe_admin() {
	$settings = get_option( 'widget_social_connect' );
	
	if( isset( $_POST[ 'update_social_connect' ] ) ) {
    $settings[ 'title' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_title' ] ) );
    
	$settings[ 'email' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_email' ] ) );
    $settings[ 'email_name' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_email_name' ] ) );
     
    $settings[ 'twitter' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_twitter' ] ) );
    $settings[ 'twitter_name' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_twitter_name' ] ) );
      
    $settings[ 'facebook' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_facebook' ] ) );
    $settings[ 'facebook_name' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_facebook_name' ] ) );
     
    $settings[ 'flickr' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_flickr' ] ) );
    $settings[ 'flickr_name' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_flickr_name' ] ) );
      
	$settings[ 'dribbble' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_dribbble' ] ) );
    $settings[ 'dribbble_name' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_dribbble_name' ] ) );
      
    $settings[ 'youtube' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_youtube' ] ) );
    $settings[ 'youtube_name' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_youtube_name' ] ) );
     
	$settings[ 'vimeo' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_vimeo' ] ) );
    $settings[ 'vimeo_name' ] = strip_tags( stripslashes( $_POST[ 'widget_social_connect_vimeo_name' ] ) );
     
	update_option( 'widget_social_connect', $settings );
	}

?>
	<p>
		<label for="widget_social_connect_title">Widget Title</label><br />
		<input type="text" id="widget_social_connect_title" name="widget_social_connect_title" value="<?php echo $settings['title']; ?>" size="35" /><br />
		
		 
		<p>
		<img style="float: left; margin-right: 3px;" src="<?php echo bloginfo('template_directory') ?>/images/icons/social_widget/email.png" />
		<label for="widget_social_connect_email"><strong>E-mail</strong></label> <br/>
		<input type="text" id="widget_social_connect_email" name="widget_social_connect_email" value="<?php echo $settings['email']; ?>" size="30" />
		</p>
		<p style="margin-left:34px;">
  		<label for="widget_social_connect_email">Title</label><br />
		<input type="text" id="widget_social_connect_email_name" name="widget_social_connect_email_name" value="<?php echo $settings['email_name']; ?>" size="30" /><br />
 		</p>
		
		<p>
		<img style="float: left; margin-right: 3px;" src="<?php echo bloginfo('template_directory') ?>/images/icons/social_widget/twitter.png" />
		<label for="widget_social_connect_twitter"><strong>Twitter</strong> Full URL</label> 
		<input type="text" id="widget_social_connect_twitter" name="widget_social_connect_twitter" value="<?php echo $settings['twitter']; ?>" size="30" />
		</p>
		<p style="margin-left:34px;">
  		<label for="widget_social_connect_twitter">Title</label><br />
		<input type="text" id="widget_social_connect_twitter_name" name="widget_social_connect_twitter_name" value="<?php echo $settings['twitter_name']; ?>" size="30" /><br />
 		</p>
		
		 
		<p>
		<img style="float: left; margin-right: 3px;" src="<?php echo bloginfo('template_directory') ?>/images/icons/social_widget/facebook.png" />
		<label for="widget_social_connect_facebook"><strong>Facebook</strong> Full URL</label> 
		<input type="text" id="widget_social_connect_facebook" name="widget_social_connect_facebook" value="<?php echo $settings['facebook']; ?>" size="30" />
		</p>
		<p style="margin-left:34px;">
  		<label for="widget_social_connect_facebook">Title</label><br />
		<input type="text" id="widget_social_connect_facebook_name" name="widget_social_connect_facebook_name" value="<?php echo $settings['facebook_name']; ?>" size="30" /><br />
 		</p>
		
 		
		<p>
		<img style="float: left; margin-right: 3px;" src="<?php echo bloginfo('template_directory') ?>/images/icons/social_widget/flickr.png" />
		<label for="widget_social_connect_flickr"><strong>Flickr</strong> Full URL</label> 
		<input type="text" id="widget_social_connect_flickr" name="widget_social_connect_flickr" value="<?php echo $settings['flickr']; ?>" size="30" />
		</p>
		<p style="margin-left:34px;">
  		<label for="widget_social_connect_flickr">Title</label><br />
		<input type="text" id="widget_social_connect_flickr_name" name="widget_social_connect_flickr_name" value="<?php echo $settings['flickr_name']; ?>" size="30" /><br />
 		</p>
		
		
		<p>
		<img style="float: left; margin-right: 3px;" src="<?php echo bloginfo('template_directory') ?>/images/icons/social_widget/dribbble.png" />
		<label for="widget_social_connect_dribbble"><strong>Dribbble</strong> Full URL</label> 
		<input type="text" id="widget_social_connect_dribbble" name="widget_social_connect_dribbble" value="<?php echo $settings['dribbble']; ?>" size="30" />
		</p>
		<p style="margin-left:34px;">
  		<label for="widget_social_connect_dribbble">Title</label><br />
		<input type="text" id="widget_social_connect_dribbble_name" name="widget_social_connect_dribbble_name" value="<?php echo $settings['dribbble_name']; ?>" size="30" /><br />
 		</p>
		
		
		<p>
		<img style="float: left; margin-right: 3px;" src="<?php echo bloginfo('template_directory') ?>/images/icons/social_widget/youtube.png" />
		<label for="widget_social_connect_youtube"><strong>Youtube</strong> Full URL</label> 
		<input type="text" id="widget_social_connect_youtube" name="widget_social_connect_youtube" value="<?php echo $settings['youtube']; ?>" size="30" />
		</p>
		<p style="margin-left:34px;">
  		<label for="widget_social_connect_youtube">Title</label><br />
		<input type="text" id="widget_social_connect_youtube_name" name="widget_social_connect_youtube_name" value="<?php echo $settings['youtube_name']; ?>" size="30" /><br />
 		</p>
 		
		<p>
		<img style="float: left; margin-right: 3px;" src="<?php echo bloginfo('template_directory') ?>/images/icons/social_widget/vimeo.png" />
		<label for="widget_social_connect_vimeo"><strong>Vimeo</strong> Full URL</label> 
		<input type="text" id="widget_social_connect_vimeo" name="widget_social_connect_vimeo" value="<?php echo $settings['vimeo']; ?>" size="30" />
		</p>
		<p style="margin-left:34px;">
  		<label for="widget_social_connect_vimeo">Title</label><br />
		<input type="text" id="widget_social_connect_youtube_vimeo" name="widget_social_connect_vimeo_name" value="<?php echo $settings['vimeo_name']; ?>" size="30" /><br />
 		</p>
		
 
	</p>
	<input type="hidden" id="update_social_connect" name="update_social_connect" value="1" />
<?php }

 
 
  
/*------------------------------------------*/
/* WPZOOM: Recent Posts           */
/*------------------------------------------*/
  
function recent_news($args) {
  
  extract($args);
  $settings = get_option( 'widget_recent_news' );  
  $number = $settings[ 'number' ];
  
  echo $before_widget;
  echo "$before_title"."$settings[title]"."$after_title";
  
?>
<ul class="news_widget">
  <?php
    $recent = new WP_Query( 'caller_get_posts=1&showposts=' . $number );
    while( $recent->have_posts() ) : $recent->the_post(); 
      global $post; global $wp_query;
  ?>
	<li>
		<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>">
		<?php unset($img); 
			if ( current_theme_supports( 'post-thumbnails' ) && has_post_thumbnail() ) {
			$thumbURL = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), '' );
				$img = $thumbURL[0]; }
				else {
					unset($img);
					if ($wpzoom_cf_use == 'Yes') { $img = get_post_meta($post->ID, $wpzoom_cf_photo, true); }
				else {
					if (!$img)  { $img = catch_that_image($post->ID); } }
				}
				if ($img) { $img = wpzoom_wpmu($img);?>
			<img src="<?php bloginfo('template_directory'); ?>/scripts/timthumb.php?src=<?php echo $img ?>&amp;w=65&amp;h=50&amp;zc=1" alt="<?php the_title(); ?>" /> 
			<?php } ?>
 		</a>
		<div class="date">
		  <span class="day"><?php the_time('d'); ?></span>
		  <span class="month"><?php the_time('M'); ?></span>
		</div>
		<a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a>
		<span class="meta"><?php the_time('F j, Y \a\t G:i'); ?></span> 
 
  </li>
   
  <?php
    endwhile;
  ?>
</ul>
  
<?php
echo $after_widget;
}

function recent_news_admin() {
  
  $settings = get_option( 'widget_recent_news' );

  if( isset( $_POST[ 'update_recent_news' ] ) ) {
    $settings[ 'title' ] = strip_tags( stripslashes( $_POST[ 'widget_recent_news_title' ] ) );
    $settings[ 'number' ] = strip_tags( stripslashes( $_POST[ 'widget_recent_news_number' ] ) );
    update_option( 'widget_recent_news', $settings );
  }
?>
  <p>
    <label for="widget_recent_news_title">Title</label><br />
    <input type="text" id="widget_recent_news_title" name="widget_recent_news_title" value="<?php echo $settings['title']; ?>" size="40" /><br />
    
    
    <label for="widget_recent_news_number">How many items would you like to display?</label><br />
    <select id="widget_recent_news_number" name="widget_recent_news_number">
      <?php
        $settings = get_option( 'widget_recent_news' );  
        $number = $settings[ 'number' ];
        
        $numbers = array( "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" );
        foreach ($numbers as $num ) {
          $option = '<option value="' . $num . '" ' . ( $number == $num? " selected=\"selected\"" : "") . '>';
            $option .= $num;
          $option .= '</option>';
          echo $option;
        }
      ?>
    </select>
  </p>
    <input type="hidden" id="update_recent_news" name="update_recent_news" value="1" />

<?php  }
 
/*------------------------------------------*/
/* WPZOOM: Recent Comments (with gravatar)	*/
/*------------------------------------------*/


function dp_recent_comments($no_comments = 10, $comment_len = 75) { 
    global $wpdb; 
	
	$request = "SELECT * FROM $wpdb->comments";
	$request .= " JOIN $wpdb->posts ON ID = comment_post_ID";
	$request .= " WHERE comment_approved = '1' AND post_status = 'publish' AND post_password ='' AND comment_type = ''"; 
	$request .= " ORDER BY comment_date DESC LIMIT $no_comments"; 
		
	$comments = $wpdb->get_results($request);
		
	if ($comments) { 
		foreach ($comments as $comment) { 
			ob_start();
			?>
				<li>
					 <?php echo get_avatar($comment,$size='40' ); ?> 
					<a href="<?php echo get_permalink( $comment->comment_post_ID ) . '#comment-' . $comment->comment_ID; ?>"><?php echo dp_get_author($comment); ?>:</a>
					<?php echo strip_tags(substr(apply_filters('get_comment_text', $comment->comment_content), 0, $comment_len)); ?>
 				</li>
			<?php
			ob_end_flush();
		} 
	} else { 
		echo "<li>No comments</li>";
	}
}

function dp_get_author($comment) {
	$author = "";

	if ( empty($comment->comment_author) )
		$author = __('Anonymous');
	else
		$author = $comment->comment_author;
		
	return $author;
}



function recent_comments($args) {

	extract($args);
	$settings = get_option( 'widget_recent_comments' );  
	$number = $settings[ 'number' ];
	
  echo $before_widget;
  echo "$before_title"."$settings[title]"."$after_title";
 
 
?>
	<ul>
	<?php dp_recent_comments($settings['number_comments']); ?>
	</ul>
	
 <?php
  echo $after_widget;
}

function recent_comments_admin() {
	
	$settings = get_option( 'widget_recent_comments' );
	 
	if( isset( $_POST[ 'update_recent_comments' ] ) ) {
			$settings[ 'title' ] = strip_tags( stripslashes( $_POST[ 'widget_recent_comments_title' ] ) );
			$settings[ 'number_comments' ] = strip_tags( stripslashes( $_POST[ 'widget_recent_comments_number_comments' ] ) );
			update_option( 'widget_recent_comments', $settings );
		}
	
	 
?>	
	<p>
		<label for="widget_recent_comments_title_comments">Title</label><br />
		<input type="text" id="widget_recent_comments_title" name="widget_recent_comments_title" value="<?php echo $settings['title']; ?>" />
	</p>
	
	<p>
		<label for="widget_recent_comments_number_comments">Number of comments</label><br />
		<input type="text" id="widget_recent_comments_number_comments" name="widget_recent_comments_number_comments" value="<?php echo $settings['number_comments']; ?>" />
	</p>
	
<input type="hidden" id="update_recent_comments" name="update_recent_comments" value="1" />
<?php }


/*----------------------------------------------------------------------------------*/
/*  WPZOOM: Flickr Widget	
/*	 			
/*  Plugin URI: http://kovshenin.com/wordpress/plugins/quick-flickr-widget/
/*  Author: Konstantin Kovshenin
/*  Modified by WPZOOM
/*
/*----------------------------------------------------------------------------------*/

$flickr_api_key = "d348e6e1216a46f2a4c9e28f93d75a48"; // You can use your own if you like

function widget_quickflickr($args) {
	extract($args);

	$options = get_option("widget_quickflickr");
	if( $options == false ) {
		$options["title"] = "Flickr Photos";
		$options["rss"] = "";
		$options["items"] = 3;
		$options["target"] = "";
		$options["username"] = "";
		$options["user_id"] = "";
		$options["error"] = "";
	}

	$title = $options["title"];
	$items = $options["items"];
	$view = "_s";
	$before_item = "<li>";
	$after_item = "</li>";
	$before_flickr_widget = "<ul class=\"gallery\">";
	$after_flickr_widget = "</ul>";
	$more_title = $options["more_title"];
	$target = $options["target"];
	$username = $options["username"];
	$user_id = $options["user_id"];
	$error = $options["error"];
	$rss = $options["rss"];
	$tester = 0;

	if (empty($error))
	{
		$target = ($target == "checked") ? "target=\"_blank\"" : "";

		$flickrformat = "php";

		if (empty($items) || $items < 1 || $items > 20) $items = 3;

		// Screen name or RSS in $username?
		if (!ereg("http://api.flickr.com/services/feeds", $username))
			$url = "http://api.flickr.com/services/feeds/photos_public.gne?id=".urlencode($user_id)."&format=".$flickrformat."&lang=en-us".$tags;
		else
			$url = $username."&format=".$flickrformat.$tags;

      eval("?>". file_get_contents($url) . "<?");
			$photos = $feed;

			if ($photos)
			{
			 $out .= $before_flickr_widget;

        foreach($photos["items"] as $key => $value)
				{
				  $tester++;

					if (--$items < 0) break;

					$photo_title = $value["title"];
					$photo_link = $value["url"];
					ereg("<img[^>]* src=\"([^\"]*)\"[^>]*>", $value["description"], $regs);
					$photo_url = $regs[1];

					//$photo_url = $value["media"]["m"];
					$photo_medium_url = str_replace("_m.jpg", ".jpg", $photo_url);
					$photo_url = str_replace("_m.jpg", "$view.jpg", $photo_url);

					if ($tester == 3)
					{
					  $before_item = '<li class="last">';
					  $tester = 0;
          }
          else
          {
            $before_item = '<li>';
          }

//					$photo_title = ($show_titles) ? "<div class=\"qflickr-title\">$photo_title</div>" : "";
					$out .= $before_item . "<a $target href=\"$photo_link\"><img class=\"flickr_photo\" alt=\"$photo_title\" title=\"$photo_title\" src=\"$photo_url\" /></a>" . $after_item;

				}
				$flickr_home = $photos["url"];
				$out .= $after_flickr_widget;
			}
			else
			{
				$out = "Something went wrong with the Flickr feed! Please check your configuration and make sure that the Flickr username or RSS feed exists";
			}

		?>
<!-- Quick Flickr start -->
	<?php echo $before_widget; ?>
		<?php if(!empty($title)) { $title = apply_filters('localization', $title); echo $before_title . $title . $after_title; } ?>
		<?php echo $out ?>
		<?php if (!empty($more_title) && !$javascript) echo "<a href=\"" . strip_tags($flickr_home) . "\">$more_title</a>"; ?>
	<?php echo $after_widget; ?>
<!-- Quick Flickr end -->
	<?php
	}
	else // error
	{
		$out = $error;
	}
}

function widget_quickflickr_control() {
	$options = $newoptions = get_option("widget_quickflickr");
	if( $options == false ) {
		$newoptions["title"] = "Flickr Gallery";
		$newoptions["error"] = "Your Quick Flickr Widget needs to be configured";
	}
	if ( $_POST["flickr-submit"] ) {
		$newoptions["title"] = strip_tags(stripslashes($_POST["flickr-title"]));
		$newoptions["items"] = strip_tags(stripslashes($_POST["rss-items"]));
		$newoptions["more_title"] = strip_tags(stripslashes($_POST["flickr-more-title"]));
		$newoptions["target"] = strip_tags(stripslashes($_POST["flickr-target"]));
		$newoptions["username"] = strip_tags(stripslashes($_POST["flickr-username"]));

		if (!empty($newoptions["username"]) && $newoptions["username"] != $options["username"])
		{
			if (!ereg("http://api.flickr.com/services/feeds", $newoptions["username"])) // Not a feed
			{
				global $flickr_api_key;
				$str = @file_get_contents("http://api.flickr.com/services/rest/?method=flickr.people.findByUsername&api_key=".$flickr_api_key."&username=".urlencode($newoptions["username"])."&format=rest");
				ereg("<rsp stat=\\\"([A-Za-z]+)\\\"", $str, $regs); $findByUsername["stat"] = $regs[1];

				if ($findByUsername["stat"] == "ok")
				{
					ereg("<username>(.+)</username>", $str, $regs);
					$findByUsername["username"] = $regs[1];

					ereg("<user id=\\\"(.+)\\\" nsid=\\\"(.+)\\\">", $str, $regs);
					$findByUsername["user"]["id"] = $regs[1];
					$findByUsername["user"]["nsid"] = $regs[2];

					$flickr_id = $findByUsername["user"]["nsid"];
					$newoptions["error"] = "";
				}
				else
				{
					$flickr_id = "";
					$newoptions["username"] = ""; // reset

					ereg("<err code=\\\"(.+)\\\" msg=\\\"(.+)\\\"", $str, $regs);
					$findByUsername["message"] = $regs[2] . "(" . $regs[1] . ")";

					$newoptions["error"] = "Flickr API call failed! (findByUsername returned: ".$findByUsername["message"].")";
				}
				$newoptions["user_id"] = $flickr_id;
			}
			else
			{
				$newoptions["error"] = "";
			}
		}
		elseif (empty($newoptions["username"]))
			$newoptions["error"] = "Flickr RSS or Screen name empty. Please reconfigure.";
	}
	if ( $options != $newoptions ) {
		$options = $newoptions;
		update_option("widget_quickflickr", $options);
	}
	$title = wp_specialchars($options["title"]);
	$items = wp_specialchars($options["items"]);
	if ( empty($items) || $items < 1 ) $items = 3;

	$more_title = wp_specialchars($options["more_title"]);

	$target = wp_specialchars($options["target"]);
	$flickr_username = wp_specialchars($options["username"]);

	?>
	<p><label for="flickr-title"><?php _e("Title:"); ?> <input class="widefat" id="flickr-title" name="flickr-title" type="text" value="<?php echo $title; ?>" /></label></p>
	<p><label for="flickr-username"><?php _e("Flickr RSS URL or Screen name:"); ?> <input class="widefat" id="flickr-username" name="flickr-username" type="text" value="<?php echo $flickr_username; ?>" /></label></p>
	<p><label for="flickr-items"><?php _e("How many items?"); ?> <select class="widefat" id="rss-items" name="rss-items"><?php for ( $i = 1; $i <= 20; ++$i ) echo "<option value=\"$i\" ".($items==$i ? "selected=\"selected\"" : "").">$i</option>"; ?></select></label></p>
	<p><label for="flickr-more-title"><?php _e("More link anchor text:"); ?> <input class="widefat" id="flickr-more-title" name="flickr-more-title" type="text" value="<?php echo $more_title; ?>" /></label></p>
	<p><label for="flickr-target"><input id="flickr-target" name="flickr-target" type="checkbox" value="checked" <?php echo $target; ?> /> <?php _e("Target: _blank"); ?></label></p>
	<input type="hidden" id="flickr-submit" name="flickr-submit" value="1" />
	<?php
}

register_sidebar_widget( 'WPZOOM: Recent News', 'recent_news' );
register_widget_control( 'WPZOOM: Recent News', 'recent_news_admin', 300, 200 );

register_sidebar_widget( 'WPZOOM: Recent Comments', 'recent_comments' );
register_widget_control( 'WPZOOM: Recent Comments', 'recent_comments_admin', 300, 200 );

register_sidebar_widget( 'WPZOOM: Social Widget', 'connectWithMe' );
register_widget_control( 'WPZOOM: Social Widget', 'connectWithMe_admin', 300, 200 );

register_widget_control( 'WPZOOM: Flickr Widget', "widget_quickflickr_control");
register_sidebar_widget( 'WPZOOM: Flickr Widget', "widget_quickflickr");