<?php
define('SCRIPTPATH','/phpChart_Lite/');
define('DEBUG', true);





/******** DO NOT MODIFY ***********/
require_once('phpChart.php');     
/**********************************/
?>
