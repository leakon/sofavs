FancyUpload - Swiff meets Ajax
========================

**Swiff** meets **Ajax** for powerful and elegant uploads.
FancyUpload is a file-input replacement which features an unobtrusive, multiple-file selection
menu and queued upload with an animated progress bar. It is easy to setup, is server independent,
completely styleable via CSS and XHTML and uses [MooTools][] to work in all modern browsers.

### Keywords: {#keywords}

- MooTools
- FancyUpload
- Fileinput
- Uploader
- Swiff
- FileReference
- ExternalInterface