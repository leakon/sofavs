<?php
class Tyrant 
{
	
}
?>