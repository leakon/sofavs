<?php
class DataType
{
	
}
?>