<?php
global $php;
$php->plugin->require_plugin('adodb');
?>