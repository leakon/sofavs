<?php
function smarty_modifier_howLongAgo($string)
{
	return Swoole_tools::howLongAgo($string);
}
?>
