<?php
require LIBPATH.'/system/Cache.php';
$cache = new Cache(CACHE_URL);