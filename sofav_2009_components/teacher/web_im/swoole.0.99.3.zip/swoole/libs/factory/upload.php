<?php
require LIBPATH.'/system/Upload.php';
$upload = new Upload(UPLOAD_DIR);