<?php
global $php;
$user = new Auth($php->db,LOGIN_TABLE);
?>