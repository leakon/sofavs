<?php
$field2form = array('int'=>'text',
					'varchar'=>'text',
					'mediumtext'=>'textarea',
					'text'=>'textarea');
?>