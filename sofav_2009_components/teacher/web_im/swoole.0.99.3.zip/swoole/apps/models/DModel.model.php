<?php
class DModel extends Model
{
	var $table = 'system_models';
}
?>