<?php
$handle = array(
    'test'=>'test',
    'hello'=>'hello',
);
?>